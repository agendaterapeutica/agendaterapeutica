'use client';
import { useSyncAgenda } from '@/hooks/use-sync-agenda';

export default function HomePage() {
  const { agenda, updateAgenda, loading } = useSyncAgenda();

  if (loading) return <p className="text-center p-4">Carregando agenda...</p>;

  const adicionarConsulta = () => {
    const novaConsulta = {
      id: Date.now(),
      terapeuta: 'João',
      paciente: 'Ana',
      horario: '10:00'
    };
    updateAgenda({
      ...agenda,
      consultas: [...agenda.consultas, novaConsulta]
    });
  };

  return (
    <main className="max-w-xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Agenda Terapêutica</h1>
      <button onClick={adicionarConsulta} className="bg-blue-500 text-white px-4 py-2 rounded mb-4">
        Adicionar Consulta
      </button>
      <ul className="space-y-2">
        {agenda.consultas.map((c: any) => (
          <li key={c.id} className="border p-2 rounded shadow">
            <strong>{c.terapeuta}</strong> com <strong>{c.paciente}</strong> às <strong>{c.horario}</strong>
          </li>
        ))}
      </ul>
    </main>
  );
}