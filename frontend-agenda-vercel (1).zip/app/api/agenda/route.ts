import { promises as fs } from 'fs';
import path from 'path';
import { NextResponse } from 'next/server';
import { commitAgendaUpdate } from '@/lib/github';

const dataPath = path.join(process.cwd(), 'data', 'agenda.json');

export async function GET() {
  try {
    const data = await fs.readFile(dataPath, 'utf-8');
    return NextResponse.json(JSON.parse(data));
  } catch (error) {
    return new NextResponse('Erro ao ler os dados', { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const newData = await request.json();
    const content = JSON.stringify(newData, null, 2);
    await fs.writeFile(dataPath, content);

    if (process.env.GITHUB_TOKEN) {
      await commitAgendaUpdate(content);
    }

    return new NextResponse('Dados salvos com sucesso');
  } catch (error) {
    console.error(error);
    return new NextResponse('Erro ao salvar os dados', { status: 500 });
  }
}