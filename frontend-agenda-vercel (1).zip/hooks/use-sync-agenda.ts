'use client';
import { useEffect, useState } from 'react';

const channel = typeof window !== 'undefined' ? new BroadcastChannel('agenda-sync') : null;

export function useSyncAgenda() {
  const [agenda, setAgenda] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/agenda')
      .then(res => res.json())
      .then(data => {
        setAgenda(data);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    if (!channel) return;
    channel.onmessage = (e) => setAgenda(e.data);
  }, []);

  const updateAgenda = async (newAgenda: any) => {
    setAgenda(newAgenda);
    channel?.postMessage(newAgenda);
    await fetch('/api/agenda', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newAgenda)
    });
  };

  return { agenda, updateAgenda, loading };
}