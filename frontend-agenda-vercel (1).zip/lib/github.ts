import { Octokit } from 'octokit';

const octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });
const owner = 'SEU_USUARIO_GITHUB';
const repo = 'SEU_REPOSITORIO';
const filePath = 'data/agenda.json';

export async function commitAgendaUpdate(content: string) {
  const { data: refData } = await octokit.rest.git.getRef({ owner, repo, ref: 'heads/main' });
  const latestCommitSha = refData.object.sha;
  const { data: commitData } = await octokit.rest.git.getCommit({ owner, repo, commit_sha: latestCommitSha });
  const { data: blobData } = await octokit.rest.git.createBlob({ owner, repo, content, encoding: 'utf-8' });
  const { data: treeData } = await octokit.rest.git.createTree({
    owner,
    repo,
    base_tree: commitData.tree.sha,
    tree: [{ path: filePath, mode: '100644', type: 'blob', sha: blobData.sha }]
  });
  const { data: newCommit } = await octokit.rest.git.createCommit({
    owner,
    repo,
    message: 'Atualiza agenda.json automaticamente',
    tree: treeData.sha,
    parents: [latestCommitSha]
  });
  await octokit.rest.git.updateRef({ owner, repo, ref: 'heads/main', sha: newCommit.sha });
}