"use client"

import { Button } from "@/components/ui/button"
import { Printer } from "lucide-react"
import { useCallback } from "react"

interface PrintButtonProps {
  className?: string
}

export function PrintButton({ className }: PrintButtonProps) {
  const handlePrint = useCallback(() => {
    // Adicionar classe para estilização de impressão
    document.body.classList.add("printing")

    // Imprimir a página
    window.print()

    // Remover classe após a impressão
    setTimeout(() => {
      document.body.classList.remove("printing")
    }, 500)
  }, [])

  return (
    <Button
      variant="outline"
      size="sm"
      className={`flex items-center gap-2 ${className} no-print`}
      onClick={handlePrint}
    >
      <Printer className="h-4 w-4" />
      Imprimir
    </Button>
  )
}
