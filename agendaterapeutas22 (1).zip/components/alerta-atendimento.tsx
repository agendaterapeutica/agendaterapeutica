"use client"

import { useEffect, useState, useRef } from "react"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Bell, Calendar, User, Users } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export function AlertaAtendimento() {
  const { toast } = useToast()
  const [proximosAtendimentos, setProximosAtendimentos] = useState<any[]>([])
  const [atendimentoAtual, setAtendimentoAtual] = useState<any | null>(null)
  const [isAlertOpen, setIsAlertOpen] = useState(false)
  const [alertasExibidos, setAlertasExibidos] = useState<string[]>([])
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const checkTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const isInitializedRef = useRef(false)

  // Criar elemento de áudio uma vez
  useEffect(() => {
    audioRef.current = new Audio("/notification.mp3")
    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current = null
      }

      // Limpar timeout ao desmontar
      if (checkTimeoutRef.current) {
        clearTimeout(checkTimeoutRef.current)
      }
    }
  }, [])

  // Função para verificar próximos atendimentos
  const verificarProximosAtendimentos = () => {
    try {
      // Verificar se os alertas estão ativos
      const alertasAtivos = localStorage.getItem("alertasAtivos") !== "false"
      if (!alertasAtivos) return

      // Obter tempo de antecedência configurado (em minutos)
      const tempoAntecedencia = Number.parseInt(localStorage.getItem("tempoAlerta") || "15", 10)

      // Obter agendamentos do localStorage
      const storedAgendamentos = localStorage.getItem("agendamentos")
      if (!storedAgendamentos) return

      const agendamentos = JSON.parse(storedAgendamentos)

      // Obter email do terapeuta logado
      const userEmail = sessionStorage.getItem("userEmail")
      if (!userEmail) return

      // Obter lista de terapeutas
      const storedTerapeutas = localStorage.getItem("terapeutas")
      if (!storedTerapeutas) return

      const terapeutas = JSON.parse(storedTerapeutas)

      // Encontrar o terapeuta logado
      const terapeutaLogado = terapeutas.find((t: any) => t.email === userEmail)
      if (!terapeutaLogado) return

      // Obter pacientes
      const storedPacientes = localStorage.getItem("pacientes")
      if (!storedPacientes) return

      const pacientes = JSON.parse(storedPacientes)

      // Obter data e hora atual
      const agora = new Date()
      const diaSemanaAtual = agora.getDay() // 0 = Domingo, 1 = Segunda, ...

      // Converter para o formato do nosso array (Segunda = 0, Terça = 1, ...)
      const diasSemana = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
      const diaAtual = diasSemana[diaSemanaAtual === 0 ? 6 : diaSemanaAtual - 1]

      // Hora atual em minutos desde o início do dia
      const horaAtual = agora.getHours()
      const minutoAtual = agora.getMinutes()
      const tempoAtualEmMinutos = horaAtual * 60 + minutoAtual

      // Filtrar agendamentos do terapeuta logado para o dia atual
      const agendamentosDoDia = agendamentos.filter((a: any) => {
        return a.terapeutaId === terapeutaLogado.id && a.dia === diaAtual
      })

      // Verificar quais agendamentos estão próximos com base na antecedência configurada
      const proximosAgendamentos = agendamentosDoDia.filter((a: any) => {
        const [hora, minuto] = a.horario.split(":").map(Number)
        const tempoAgendamentoEmMinutos = hora * 60 + minuto

        // Calcular diferença em minutos
        const diferencaEmMinutos = tempoAgendamentoEmMinutos - tempoAtualEmMinutos

        // Retornar agendamentos que estão dentro do tempo de antecedência configurado
        return diferencaEmMinutos >= 0 && diferencaEmMinutos <= tempoAntecedencia
      })

      // Adicionar informações do paciente aos agendamentos
      const agendamentosComPaciente = proximosAgendamentos.map((a: any) => {
        if (a.tipo === "individual") {
          const paciente = pacientes.find((p: any) => p.id === a.pacienteId)
          return { ...a, paciente }
        } else if (a.tipo === "grupo" && a.pacienteIds) {
          const pacientesDoGrupo = a.pacienteIds
            .map((id: string) => pacientes.find((p: any) => p.id === id))
            .filter(Boolean)
          return { ...a, pacientesDoGrupo }
        }
        return a
      })

      // Atualizar estado com os próximos atendimentos
      setProximosAtendimentos(agendamentosComPaciente)

      // Verificar se há novos alertas para exibir
      const novosAlertas = agendamentosComPaciente.filter(
        (a: any) => !alertasExibidos.includes(`${a.id}-${a.dia}-${a.horario}`),
      )

      if (novosAlertas.length > 0) {
        // Exibir o primeiro alerta novo
        setAtendimentoAtual(novosAlertas[0])
        setIsAlertOpen(true)

        // Tocar som de notificação
        if (audioRef.current) {
          audioRef.current.play().catch((err) => console.error("Erro ao tocar áudio:", err))
        }

        // Vibrar o dispositivo se suportado
        if (navigator.vibrate) {
          navigator.vibrate([200, 100, 200])
        }

        // Marcar este alerta como exibido
        setAlertasExibidos((prev) => [
          ...prev,
          `${novosAlertas[0].id}-${novosAlertas[0].dia}-${novosAlertas[0].horario}`,
        ])
      }
    } catch (error) {
      console.error("Erro ao verificar próximos atendimentos:", error)
    }
  }

  // Verificar atendimentos a cada minuto - modificado para evitar o erro flushSync
  useEffect(() => {
    if (isInitializedRef.current) return

    // Inicializar o componente
    isInitializedRef.current = true

    // Verificar imediatamente ao montar o componente, mas com um pequeno atraso
    const initialCheck = setTimeout(() => {
      verificarProximosAtendimentos()

      // Configurar intervalo para verificar a cada minuto
      const intervalo = setInterval(() => {
        verificarProximosAtendimentos()
      }, 60000)

      // Limpar intervalo ao desmontar
      return () => clearInterval(intervalo)
    }, 100)

    // Limpar o timeout inicial se o componente for desmontado antes
    return () => clearTimeout(initialCheck)
  }, [])

  // Função para formatar a mensagem de alerta
  const formatarMensagemAlerta = (atendimento: any) => {
    if (!atendimento) return null

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="bg-muted p-2 rounded-full">
            {atendimento.tipo === "individual" ? (
              <User className="h-5 w-5 text-primary" />
            ) : atendimento.tipo === "grupo" ? (
              <Users className="h-5 w-5 text-agenda-green" />
            ) : (
              <Calendar className="h-5 w-5 text-agenda-purple" />
            )}
          </div>
          <div>
            <p className="font-medium">
              {atendimento.tipo === "individual"
                ? "Atendimento Individual"
                : atendimento.tipo === "grupo"
                  ? "Atendimento em Grupo"
                  : "Reunião"}
            </p>
            <p className="text-sm text-muted-foreground">Hoje às {atendimento.horario}</p>
          </div>
        </div>

        {atendimento.tipo === "individual" && atendimento.paciente && (
          <div className="flex items-center gap-3 bg-muted/30 p-3 rounded-md">
            <Avatar className="h-10 w-10">
              <AvatarImage src={atendimento.paciente.foto} alt={atendimento.paciente.nome} />
              <AvatarFallback>{atendimento.paciente.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{atendimento.paciente.nome}</p>
              <p className="text-sm text-muted-foreground">{atendimento.paciente.telefone}</p>
            </div>
          </div>
        )}

        {atendimento.tipo === "grupo" && atendimento.pacientesDoGrupo && (
          <div className="space-y-2">
            <p className="font-medium">Pacientes no grupo:</p>
            <div className="flex flex-wrap gap-2">
              {atendimento.pacientesDoGrupo.map((paciente: any) => (
                <Badge key={paciente.id} variant="outline" className="flex items-center gap-1 py-1 px-2">
                  <Avatar className="h-5 w-5 mr-1">
                    <AvatarImage src={paciente.foto} alt={paciente.nome} />
                    <AvatarFallback>{paciente.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  {paciente.nome}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {atendimento.tipo === "reuniao" && atendimento.comentario && (
          <div className="bg-muted/30 p-3 rounded-md">
            <p className="font-medium">Assunto:</p>
            <p className="text-sm">{atendimento.comentario}</p>
          </div>
        )}
      </div>
    )
  }

  return (
    <>
      <AlertDialog open={isAlertOpen} onOpenChange={setIsAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-amber-500" />
              Lembrete de Atendimento
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              {atendimentoAtual && formatarMensagemAlerta(atendimentoAtual)}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction>Entendi</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Elemento de áudio para notificação */}
      <audio src="/notification.mp3" preload="auto" className="hidden" />
    </>
  )
}
