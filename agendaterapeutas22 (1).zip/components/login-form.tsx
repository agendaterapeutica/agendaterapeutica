"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { mockTerapeutas } from "@/lib/mock-data"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [terapeutas, setTerapeutas] = useState<any[]>([])
  const router = useRouter()
  const { toast } = useToast()

  // Carregar terapeutas do localStorage
  useEffect(() => {
    try {
      const storedTerapeutas = localStorage.getItem("terapeutas")
      if (storedTerapeutas) {
        setTerapeutas(JSON.parse(storedTerapeutas))
      } else {
        // Se não houver terapeutas no localStorage, usar os mocks
        setTerapeutas(mockTerapeutas)
        // E salvar no localStorage para uso futuro
        localStorage.setItem("terapeutas", JSON.stringify(mockTerapeutas))
      }
    } catch (error) {
      console.error("Erro ao carregar terapeutas do localStorage:", error)
      setTerapeutas(mockTerapeutas)
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    // Verificar credenciais nos terapeutas cadastrados
    const user = terapeutas.find((t) => t.email === email && t.senha === password)

    if (user) {
      // Login bem-sucedido
      try {
        // Armazenar dados no sessionStorage
        sessionStorage.setItem("userRole", user.role || "funcionario")
        sessionStorage.setItem("userEmail", user.email)

        // Definir flag para forçar refresh na primeira visita
        localStorage.setItem("needsFirstLoadRefresh", "true")

        toast({
          title: "Login realizado com sucesso",
          description: "Bem-vindo ao sistema de agendamento",
        })

        // Redirecionamento para a página de agenda
        router.push("/agenda")
      } catch (error) {
        console.error("Erro ao armazenar dados de sessão:", error)
        setError("Ocorreu um erro ao processar o login. Tente novamente.")
        setIsLoading(false)
      }
    } else {
      // Credenciais inválidas
      setError("Email ou senha incorretos. Por favor, verifique suas credenciais.")
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Login</CardTitle>
        <CardDescription>Entre com suas credenciais para acessar o sistema</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu.email@exemplo.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && (
            <Alert variant="destructive" className="py-2">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Entrando..." : "Entrar"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
