"use client"

import { createContext, useContext, useEffect, useState, useRef, type ReactNode } from "react"
import { useRouter, usePathname } from "next/navigation"

type UserRole = "admin" | "funcionario" | null
type User = {
  email: string | null
  role: UserRole
  id?: string | null
  nome?: string | null
  foto?: string | null
}

interface AuthContextType {
  user: User
  logout: () => void
  isAdmin: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User>({ email: null, role: null })
  const router = useRouter()
  const pathname = usePathname()
  const isInitializedRef = useRef(false)

  // Efeito para carregar o estado de autenticação
  useEffect(() => {
    if (isInitializedRef.current) return

    // Usar setTimeout para evitar o erro flushSync
    const timer = setTimeout(() => {
      try {
        // Tentar obter dados do sessionStorage
        const storedRole = sessionStorage.getItem("userRole") as UserRole
        const storedEmail = sessionStorage.getItem("userEmail")

        if (storedRole && storedEmail) {
          // Buscar informações adicionais do usuário
          const terapeutasStr = localStorage.getItem("terapeutas") || "[]"
          const terapeutas = JSON.parse(terapeutasStr)
          const terapeuta = terapeutas.find((t: any) => t.email === storedEmail)

          // Atualizar o estado do usuário
          setUser({
            email: storedEmail,
            role: storedRole,
            id: terapeuta?.id || null,
            nome: terapeuta?.nome || null,
            foto: terapeuta?.foto || null,
          })

          // Marcar como inicializado apenas após definir o usuário
          isInitializedRef.current = true
        } else if (pathname !== "/" && pathname !== "/login") {
          // Redirecionar para login se não estiver autenticado
          router.push("/")
        }
      } catch (error) {
        console.error("Erro ao carregar estado de autenticação:", error)
      }
    }, 100) // Aumentar o timeout para garantir que o sessionStorage esteja disponível

    return () => clearTimeout(timer)
  }, [pathname, router])

  useEffect(() => {
    // Disparar um evento quando o usuário for carregado
    if (user.email) {
      window.dispatchEvent(new Event("userLoaded"))
    }
  }, [user.email])

  const logout = () => {
    try {
      // Limpar dados de autenticação
      sessionStorage.removeItem("userRole")
      sessionStorage.removeItem("userEmail")
      setUser({ email: null, role: null })
      router.push("/")
    } catch (error) {
      console.error("Erro ao fazer logout:", error)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        logout,
        isAdmin: user.role === "admin",
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider")
  }
  return context
}
