"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ImageUpload } from "@/components/image-upload"
import { format, parse } from "date-fns"

interface PacienteFormProps {
  paciente: any
  onSave: (paciente: any) => void
}

export function PacienteForm({ paciente, onSave }: PacienteFormProps) {
  // Formatar a data para exibição se existir
  const dataFormatada = paciente.dataNascimento ? format(new Date(paciente.dataNascimento), "dd/MM/yyyy") : ""

  const [formData, setFormData] = useState({
    ...paciente,
    dataNascimentoFormatada: dataFormatada,
  })

  const handleChange = (field: string, value: any) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    let dataNascimento = null

    // Converter a data formatada para ISO string
    if (formData.dataNascimentoFormatada) {
      try {
        // Parse da data no formato DD/MM/YYYY
        const parsedDate = parse(formData.dataNascimentoFormatada, "dd/MM/yyyy", new Date())
        dataNascimento = parsedDate.toISOString()
      } catch (error) {
        console.error("Erro ao converter data:", error)
      }
    }

    onSave({
      ...formData,
      dataNascimento,
    })
  }

  // Função para formatar a entrada de data enquanto o usuário digita
  const handleDateInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "") // Remove tudo que não é dígito

    if (value.length > 0) {
      // Formatar como DD/MM/YYYY
      if (value.length <= 2) {
        // Apenas dia
      } else if (value.length <= 4) {
        // Dia e mês
        value = value.substring(0, 2) + "/" + value.substring(2)
      } else {
        // Dia, mês e ano
        value = value.substring(0, 2) + "/" + value.substring(2, 4) + "/" + value.substring(4, 8)
      }
    }

    handleChange("dataNascimentoFormatada", value)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex flex-col items-center mb-4">
        <ImageUpload
          currentImage={formData.foto}
          onImageChange={(url) => handleChange("foto", url)}
          name={formData.nome}
        />
        <p className="text-xs text-muted-foreground mt-2">Clique na imagem para alterar</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="nome">Nome</Label>
        <Input
          id="nome"
          value={formData.nome}
          onChange={(e) => handleChange("nome", e.target.value)}
          className="border-agenda-blue/30 focus-visible:ring-agenda-blue"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="dataNascimento">Data de Nascimento (DD/MM/AAAA)</Label>
        <Input
          id="dataNascimento"
          value={formData.dataNascimentoFormatada}
          onChange={handleDateInput}
          placeholder="DD/MM/AAAA"
          maxLength={10}
          className="border-agenda-blue/30 focus-visible:ring-agenda-blue"
        />
        <p className="text-xs text-muted-foreground">Exemplo: 01/01/2000</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => handleChange("email", e.target.value)}
          className="border-agenda-blue/30 focus-visible:ring-agenda-blue"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="telefone">Telefone</Label>
        <Input
          id="telefone"
          value={formData.telefone}
          onChange={(e) => handleChange("telefone", e.target.value)}
          className="border-agenda-blue/30 focus-visible:ring-agenda-blue"
          required
        />
      </div>

      <div className="pt-4 flex justify-end">
        <Button type="submit" className="bg-agenda-blue hover:bg-agenda-blue-dark">
          {formData.id.startsWith("new-") ? "Criar" : "Atualizar"}
        </Button>
      </div>
    </form>
  )
}
