"use client"

import * as React from "react"
import { X } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Command, CommandGroup, CommandItem } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface MultiSelectProps {
  options: { label: string; value: string }[]
  selected: string[]
  onChange: (selected: string[]) => void
  placeholder?: string
  className?: string
}

export function MultiSelect({
  options,
  selected = [], // Valor padrão para evitar undefined
  onChange,
  placeholder = "Selecione itens...",
  className,
}: MultiSelectProps) {
  const [open, setOpen] = React.useState(false)

  // Garantir que selected seja sempre um array
  const safeSelected = Array.isArray(selected) ? selected : []

  const handleUnselect = (item: string) => {
    onChange(safeSelected.filter((i) => i !== item))
  }

  const handleSelect = (value: string) => {
    if (safeSelected.includes(value)) {
      onChange(safeSelected.filter((item) => item !== value))
    } else {
      onChange([...safeSelected, value])
    }
    // Não fechamos o popover para permitir múltiplas seleções
  }

  // Filtrar opções que já foram selecionadas
  const availableOptions = options.filter((option) => !safeSelected.includes(option.value))

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn("w-full justify-between", className)}
        >
          {safeSelected.length > 0 ? (
            <div className="flex flex-wrap gap-1 overflow-hidden">
              {safeSelected.map((value) => {
                const option = options.find((o) => o.value === value)
                return (
                  <Badge key={value} variant="secondary" className="mr-1">
                    {option?.label}
                  </Badge>
                )
              })}
            </div>
          ) : (
            <span className="text-muted-foreground">{placeholder}</span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0" align="start">
        <Command>
          <CommandGroup className="max-h-64 overflow-auto">
            {options.length === 0 ? (
              <p className="py-2 px-4 text-sm text-muted-foreground">Nenhuma opção disponível</p>
            ) : (
              options.map((option) => {
                const isSelected = safeSelected.includes(option.value)
                return (
                  <CommandItem
                    key={option.value}
                    value={option.value}
                    onSelect={() => handleSelect(option.value)}
                    className="flex items-center justify-between"
                  >
                    <span>{option.label}</span>
                    {isSelected && <span className="ml-2">✓</span>}
                  </CommandItem>
                )
              })
            )}
          </CommandGroup>
        </Command>
      </PopoverContent>

      {/* Exibir badges selecionadas abaixo do popover */}
      {safeSelected.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {safeSelected.map((value) => {
            const option = options.find((o) => o.value === value)
            return (
              <Badge key={value} variant="secondary" className="flex items-center gap-1 p-1">
                {option?.label}
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                    handleUnselect(value)
                  }}
                  className="ml-1 rounded-full hover:bg-muted"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )
          })}
        </div>
      )}
    </Popover>
  )
}
