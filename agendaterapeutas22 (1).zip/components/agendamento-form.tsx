"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Users, User, Calendar, Star, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"

// Modificar a interface AgendamentoFormProps para incluir a lista de terapeutas disponíveis
interface AgendamentoFormProps {
  agendamento: any
  onSave: (agendamento: any) => void
  readOnly?: boolean
  conflitos?: any[] // Adicionar esta propriedade
  terapeutasDisponiveis?: any[] // Adicionar esta propriedade para o tipo especial
}

// Atualizar a função AgendamentoForm para incluir o parâmetro terapeutasDisponiveis
export function AgendamentoForm({
  agendamento,
  onSave,
  readOnly = false,
  conflitos = [],
  terapeutasDisponiveis = [],
}: AgendamentoFormProps) {
  const [formData, setFormData] = useState({
    ...agendamento,
    pacienteIds: agendamento.pacienteIds || (agendamento.pacienteId ? [agendamento.pacienteId] : []),
    comentario: agendamento.comentario || "",
    terapeutaIds: agendamento.terapeutaIds || [agendamento.terapeutaId].filter(Boolean),
  })
  const [pacientes, setPacientes] = useState<any[]>([])
  const [terapeutas, setTerapeutas] = useState<any[]>([])

  // Carregar pacientes e terapeutas do localStorage
  useEffect(() => {
    try {
      // Carregar pacientes
      const storedPacientes = localStorage.getItem("pacientes")
      if (storedPacientes) {
        setPacientes(JSON.parse(storedPacientes))
      } else {
        // Fallback para dados mockados
        import("@/lib/mock-data").then(({ mockPacientes }) => {
          setPacientes(mockPacientes)
        })
      }

      // Carregar terapeutas se não foram fornecidos
      if (terapeutasDisponiveis.length === 0) {
        const storedTerapeutas = localStorage.getItem("terapeutas")
        if (storedTerapeutas) {
          setTerapeutas(JSON.parse(storedTerapeutas))
        } else {
          // Fallback para dados mockados
          import("@/lib/mock-data").then(({ mockTerapeutas }) => {
            setTerapeutas(mockTerapeutas)
          })
        }
      } else {
        setTerapeutas(terapeutasDisponiveis)
      }
    } catch (error) {
      console.error("Erro ao carregar dados do localStorage:", error)
      // Fallback para dados mockados em caso de erro
      import("@/lib/mock-data").then(({ mockPacientes, mockTerapeutas }) => {
        setPacientes(mockPacientes)
        setTerapeutas(terapeutasDisponiveis.length > 0 ? terapeutasDisponiveis : mockTerapeutas)
      })
    }
  }, [terapeutasDisponiveis])

  const handleChange = (field: string, value: any) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Preparar o objeto de agendamento com base no tipo
    let agendamentoFinal = { ...formData }

    if (formData.tipo === "individual" && formData.pacienteIds.length > 0) {
      // Para agendamento individual, usar apenas o primeiro paciente
      agendamentoFinal = {
        ...formData,
        pacienteId: formData.pacienteIds[0],
      }
    } else if (formData.tipo === "especial") {
      // Para agendamento especial, garantir que temos pelo menos um paciente e um terapeuta
      if (formData.pacienteIds.length === 0 || formData.terapeutaIds.length === 0) {
        alert("Selecione pelo menos um paciente e um terapeuta para o agendamento especial")
        return
      }

      // Manter o terapeutaId original para compatibilidade e adicionar o array de terapeutaIds
      agendamentoFinal = {
        ...formData,
        pacienteId: formData.pacienteIds[0], // Usar o primeiro paciente como pacienteId principal
        terapeutaId: formData.terapeutaIds[0], // Manter o primeiro terapeuta como terapeutaId principal
      }
    }

    onSave(agendamentoFinal)
  }

  const handleAddPaciente = (pacienteId: string) => {
    if (!formData.pacienteIds.includes(pacienteId)) {
      setFormData({
        ...formData,
        pacienteIds: [...formData.pacienteIds, pacienteId],
      })
    }
  }

  const handleRemovePaciente = (pacienteId: string) => {
    setFormData({
      ...formData,
      pacienteIds: formData.pacienteIds.filter((id: string) => id !== pacienteId),
    })
  }

  // Função para adicionar terapeuta ao agendamento especial
  const handleAddTerapeuta = (terapeutaId: string) => {
    if (!formData.terapeutaIds.includes(terapeutaId)) {
      setFormData({
        ...formData,
        terapeutaIds: [...formData.terapeutaIds, terapeutaId],
      })
    }
  }

  // Função para remover terapeuta do agendamento especial
  const handleRemoveTerapeuta = (terapeutaId: string) => {
    setFormData({
      ...formData,
      terapeutaIds: formData.terapeutaIds.filter((id: string) => id !== terapeutaId),
    })
  }

  // Atualizar o tipo de formulário para refletir a mudança na interface
  useEffect(() => {
    // Se mudar de grupo para individual e houver mais de um paciente
    if (formData.tipo === "individual" && formData.pacienteIds.length > 1) {
      setFormData({
        ...formData,
        pacienteIds: [formData.pacienteIds[0]],
      })
    }

    // Se mudar de especial para outro tipo, limpar a lista de terapeutas adicionais
    if (formData.tipo !== "especial" && formData.terapeutaIds.length > 1) {
      setFormData({
        ...formData,
        terapeutaIds: formData.terapeutaIds.slice(0, 1),
      })
    }
  }, [formData.tipo, formData.pacienteIds, formData.terapeutaIds, formData])

  // Obter lista de pacientes selecionados
  const selectedPacientes = pacientes.filter((p) => formData.pacienteIds.includes(p.id))

  // Obter lista de pacientes não selecionados
  const availablePacientes = pacientes.filter((p) => !formData.pacienteIds.includes(p.id))

  // Obter lista de terapeutas selecionados
  const selectedTerapeutas = terapeutas.filter((t) => formData.terapeutaIds.includes(t.id))

  // Obter lista de terapeutas não selecionados
  const availableTerapeutas = terapeutas.filter((t) => !formData.terapeutaIds.includes(t.id))

  // Ícones por tipo de atendimento
  const tipoAgendamentoIcon = {
    individual: <User className="h-5 w-5 text-agenda-blue" />,
    grupo: <Users className="h-5 w-5 text-agenda-green" />,
    reuniao: <Calendar className="h-5 w-5 text-agenda-purple" />,
    especial: <Star className="h-5 w-5 text-amber-500" />,
  }

  return (
    <form onSubmit={handleSubmit} className="agendamento-form">
      {/* Manter todo o conteúdo existente do formulário */}
      <div className="agendamento-form-grid">
        <div className="agendamento-form-full">
          <Label>Tipo de Agendamento</Label>
          <RadioGroup
            value={formData.tipo || "individual"}
            onValueChange={(value) => handleChange("tipo", value)}
            disabled={readOnly}
            className="flex flex-wrap gap-2 mt-2"
          >
            <div className="flex items-center space-x-2 border rounded-md p-2 hover:bg-muted/20">
              <RadioGroupItem value="individual" id="individual" />
              <Label htmlFor="individual" className="flex items-center gap-2 cursor-pointer">
                <User className="h-4 w-4 text-agenda-blue" />
                Individual
              </Label>
            </div>
            <div className="flex items-center space-x-2 border rounded-md p-2 hover:bg-muted/20">
              <RadioGroupItem value="grupo" id="grupo" />
              <Label htmlFor="grupo" className="flex items-center gap-2 cursor-pointer">
                <Users className="h-4 w-4 text-agenda-green" />
                Grupo
              </Label>
            </div>
            <div className="flex items-center space-x-2 border rounded-md p-2 hover:bg-muted/20">
              <RadioGroupItem value="reuniao" id="reuniao" />
              <Label htmlFor="reuniao" className="flex items-center gap-2 cursor-pointer">
                <Calendar className="h-4 w-4 text-agenda-purple" />
                Reunião
              </Label>
            </div>
            <div className="flex items-center space-x-2 border rounded-md p-2 hover:bg-muted/20">
              <RadioGroupItem value="especial" id="especial" />
              <Label htmlFor="especial" className="flex items-center gap-2 cursor-pointer">
                <Star className="h-4 w-4 text-amber-500" />
                Especial
              </Label>
            </div>
          </RadioGroup>
        </div>

        {/* Campo de comentário para reuniões */}
        {formData.tipo === "reuniao" && (
          <div className="agendamento-form-full">
            <Label htmlFor="comentario">Comentário da Reunião</Label>
            <Textarea
              id="comentario"
              value={formData.comentario}
              onChange={(e) => handleChange("comentario", e.target.value)}
              placeholder="Descreva o assunto da reunião"
              disabled={readOnly}
              className="min-h-[80px] mt-2"
            />
          </div>
        )}

        {/* Campo de comentário para atendimento especial */}
        {formData.tipo === "especial" && (
          <div className="agendamento-form-full">
            <Label htmlFor="comentario">Descrição do Atendimento Especial</Label>
            <Textarea
              id="comentario"
              value={formData.comentario}
              onChange={(e) => handleChange("comentario", e.target.value)}
              placeholder="Descreva o atendimento especial e por que requer múltiplos terapeutas"
              disabled={readOnly}
              className="min-h-[80px] mt-2"
            />
          </div>
        )}

        {/* Seleção de pacientes */}
        {formData.tipo === "individual" || formData.tipo === "especial" ? (
          <div className="agendamento-form-full">
            <Label htmlFor="paciente">Paciente</Label>
            <Select
              value={formData.pacienteIds[0] || ""}
              onValueChange={(value) => setFormData({ ...formData, pacienteIds: [value] })}
              disabled={readOnly}
            >
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Selecione um paciente" />
              </SelectTrigger>
              <SelectContent>
                {pacientes.map((paciente) => (
                  <SelectItem key={paciente.id} value={paciente.id}>
                    {paciente.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ) : (
          formData.tipo === "grupo" && (
            <div className="agendamento-form-full">
              <Label>Pacientes (Múltipla seleção)</Label>

              {/* Lista de pacientes selecionados */}
              <div className="border rounded-md p-2 bg-muted/10 min-h-20 mt-2">
                {selectedPacientes.length === 0 ? (
                  <p className="text-muted-foreground text-center py-2">Nenhum paciente selecionado</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {selectedPacientes.map((paciente) => (
                      <Badge key={paciente.id} variant="secondary" className="flex items-center gap-1 p-1">
                        <Avatar className="h-5 w-5 mr-1">
                          <AvatarImage src={paciente.foto} alt={paciente.nome} />
                          <AvatarFallback>{paciente.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        {paciente.nome}
                        {!readOnly && (
                          <button
                            type="button"
                            onClick={() => handleRemovePaciente(paciente.id)}
                            className="ml-1 rounded-full hover:bg-muted"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="12"
                              height="12"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M18 6 6 18" />
                              <path d="m6 6 12 12" />
                            </svg>
                          </button>
                        )}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Seleção de novos pacientes */}
              {!readOnly && (
                <Select
                  value=""
                  onValueChange={handleAddPaciente}
                  disabled={readOnly || availablePacientes.length === 0}
                  className="mt-2"
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Adicionar paciente" />
                  </SelectTrigger>
                  <SelectContent>
                    {availablePacientes.map((paciente) => (
                      <SelectItem key={paciente.id} value={paciente.id}>
                        {paciente.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          )
        )}

        {/* Seleção de terapeutas para atendimento especial */}
        {formData.tipo === "especial" && (
          <div className="agendamento-form-full mt-4">
            <Label>Terapeutas (Múltipla seleção)</Label>
            <div className="border rounded-md p-2 bg-amber-50 min-h-20 mt-2">
              {selectedTerapeutas.length === 0 ? (
                <p className="text-muted-foreground text-center py-2">Nenhum terapeuta selecionado</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {selectedTerapeutas.map((terapeuta) => (
                    <Badge
                      key={terapeuta.id}
                      variant="outline"
                      className="flex items-center gap-1 p-1 bg-amber-100 text-amber-800 border-amber-300"
                    >
                      <Avatar className="h-5 w-5 mr-1">
                        <AvatarImage src={terapeuta.foto} alt={terapeuta.nome} />
                        <AvatarFallback>{terapeuta.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      {terapeuta.nome}
                      {!readOnly && (
                        <button
                          type="button"
                          onClick={() => handleRemoveTerapeuta(terapeuta.id)}
                          className="ml-1 rounded-full hover:bg-amber-200"
                        >
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M18 6 6 18" />
                            <path d="m6 6 12 12" />
                          </svg>
                        </button>
                      )}
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            {/* Seleção de novos terapeutas */}
            {!readOnly && (
              <Select
                value=""
                onValueChange={handleAddTerapeuta}
                disabled={readOnly || availableTerapeutas.length === 0}
                className="mt-2"
              >
                <SelectTrigger>
                  <SelectValue placeholder="Adicionar terapeuta" />
                </SelectTrigger>
                <SelectContent>
                  {availableTerapeutas.map((terapeuta) => (
                    <SelectItem key={terapeuta.id} value={terapeuta.id}>
                      {terapeuta.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {/* Informação sobre atendimento especial */}
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-md">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium">Atendimento Especial</p>
                  <p className="mt-1">
                    Este tipo de agendamento permite que múltiplos terapeutas atendam um único paciente simultaneamente.
                    O agendamento será registrado na agenda de todos os terapeutas selecionados.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Seção de conflitos - corrigido para estar dentro do formulário */}
      {conflitos.length > 0 && formData.tipo !== "especial" && (
        <div className="agendamento-form-full mt-4 p-3 border border-red-300 bg-red-50 rounded-md">
          <h3 className="text-red-600 font-medium mb-2 flex items-center gap-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="lucide lucide-alert-triangle"
            >
              <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path>
              <path d="M12 9v4"></path>
              <path d="M12 17h.01"></path>
            </svg>
            Conflitos detectados
          </h3>
          <div className="space-y-2 text-sm">
            {conflitos.map((conflito, index) => {
              const paciente = conflito.pacienteNome || "Paciente não identificado"
              const terapeuta = conflito.terapeutaNome || "Terapeuta não identificado"
              const terapeutaAtual = conflito.terapeutaAtualNome || "Terapeuta atual"
              const horario = `${conflito.dia} às ${conflito.horario}`

              return (
                <div key={index} className="p-2 bg-white border border-red-200 rounded flex items-start gap-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-x text-red-500 mt-0.5"
                  >
                    <path d="M18 6 6 18"></path>
                    <path d="m6 6 12 12"></path>
                  </svg>
                  <div>
                    <p>
                      <span className="font-medium">Paciente:</span> {paciente}
                    </p>
                    <p>
                      <span className="font-medium">Terapeuta atual:</span> {terapeutaAtual}
                    </p>
                    <p>
                      <span className="font-medium">Terapeuta com conflito:</span> {terapeuta}
                    </p>
                    <p>
                      <span className="font-medium">Horário:</span> {horario}
                    </p>
                  </div>
                </div>
              )
            })}
            <p className="text-red-600 text-xs mt-2">
              Por favor, altere o horário ou o paciente para resolver os conflitos acima.
            </p>
          </div>
        </div>
      )}

      <div className="pt-4 flex justify-end">
        <div className="flex gap-2 ml-auto">
          {!readOnly && (
            <>
              <Button type="button" variant="outline" onClick={() => onSave({ cancelled: true })}>
                Cancelar
              </Button>
              <Button type="submit">{formData.id.startsWith("new-") ? "Criar" : "Atualizar"}</Button>
            </>
          )}
        </div>
      </div>
    </form>
  )
}
