"use client"

import { Button } from "@/components/ui/button"
import { LogOut, Menu } from "lucide-react"
import { useState, useEffect } from "react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Sidebar } from "@/components/sidebar"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function Header() {
  const [userEmail, setUserEmail] = useState<string | null>(null)
  const [userRole, setUserRole] = useState<string | null>(null)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [userFoto, setUserFoto] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Carregar dados do usuário
    try {
      const email = sessionStorage.getItem("userEmail")
      const role = sessionStorage.getItem("userRole")
      setUserEmail(email)
      setUserRole(role)

      // Carregar foto do usuário logado
      if (email) {
        // Buscar terapeutas do localStorage
        const storedTerapeutas = localStorage.getItem("terapeutas")
        if (storedTerapeutas) {
          const terapeutas = JSON.parse(storedTerapeutas)
          // Encontrar o terapeuta com o email correspondente
          const terapeuta = terapeutas.find((t: any) => t.email === email)
          if (terapeuta && terapeuta.foto) {
            setUserFoto(terapeuta.foto)
          }
        }
      }
    } catch (error) {
      console.error("Erro ao carregar dados do usuário:", error)
    }
  }, [])

  const handleLogout = () => {
    try {
      // Limpar dados de autenticação
      sessionStorage.removeItem("userRole")
      sessionStorage.removeItem("userEmail")
      router.push("/")
    } catch (error) {
      console.error("Erro ao fazer logout:", error)
    }
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-background px-4 md:px-6">
      <div className="flex items-center gap-2 md:gap-4">
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Abrir menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[240px] p-0">
            <Sidebar isMobile onNavItemClick={() => setIsMobileMenuOpen(false)} />
          </SheetContent>
        </Sheet>
        <h1 className="text-lg font-semibold md:text-xl">Agenda de Terapeutas</h1>
      </div>
      <div className="flex items-center gap-2">
        <div className="hidden md:block">
          <p className="text-sm font-medium">{userEmail}</p>
          <p className="text-xs text-muted-foreground">{userRole === "admin" ? "Administrador" : "Funcionário"}</p>
        </div>
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarImage src={userFoto || "/placeholder.svg?height=32&width=32"} alt="Foto do usuário" />
            <AvatarFallback>{userEmail?.substring(0, 2).toUpperCase() || "?"}</AvatarFallback>
          </Avatar>
          <Button variant="ghost" size="icon" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
            <span className="sr-only">Sair</span>
          </Button>
        </div>
      </div>
    </header>
  )
}
