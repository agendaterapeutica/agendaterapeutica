"\"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar } from "lucide-react"
import { format, parseISO } from "date-fns"
import { ptBR } from "date-fns/locale"

interface PacientesListProps {
  pacientes: any[]
  isLoading: boolean
  onEdit: (paciente: any) => void
  onDelete: (pacienteId: string) => void
}

export function PacientesList({ pacientes, isLoading, onEdit, onDelete }: PacientesListProps) {
  // Função para formatar a data de nascimento
  const formatarDataNascimento = (data: string | null | undefined) => {
    if (!data) return "Não informada"
    try {
      return format(parseISO(data), "dd/MM/yyyy", { locale: ptBR })
    } catch (error) {
      console.error("Erro ao formatar data:", error, data)
      return "Data inválida"
    }
  }

  return (
    <>
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="flex flex-col items-center gap-2">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-agenda-blue border-t-transparent"></div>
            <p className="text-muted-foreground">Carregando pacientes...</p>
          </div>
        </div>
      ) : pacientes.length === 0 ? (
        <div className="text-center p-8 text-muted-foreground">Nenhum paciente encontrado.</div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {pacientes.map((paciente) => (
            <Card key={paciente.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4 border-2 border-agenda-blue-light">
                    <AvatarImage src={paciente.foto} alt={paciente.nome} />
                    <AvatarFallback className="bg-agenda-blue text-white">
                      {paciente.nome.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-medium text-agenda-blue-dark">{paciente.nome}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{paciente.email}</p>
                  <p className="text-sm text-muted-foreground">{paciente.telefone}</p>
                  <div className="flex items-center gap-1 mt-2 text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3 text-agenda-blue" />
                    <span>{formatarDataNascimento(paciente.dataNascimento)}</span>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onEdit(paciente)}
                      className="flex items-center gap-1 border-agenda-blue text-agenda-blue hover:bg-agenda-blue-light hover:text-agenda-blue-dark"
                    >
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => onDelete(paciente.id)}
                      className="flex items-center gap-1"
                    >
                      Excluir
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </>
  )
}
