"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ImageUpload } from "@/components/image-upload"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { X, Eye, EyeOff } from "lucide-react"
import { useEmailService } from "@/components/email-service"
import { toast } from "@/components/ui/use-toast"

interface TerapeutaFormProps {
  terapeuta: any
  especialidades: string[]
  onSave: (terapeuta: any) => void
}

export function TerapeutaForm({ terapeuta, especialidades = [], onSave }: TerapeutaFormProps) {
  // Garantir que todas as propriedades sejam inicializadas corretamente
  const [formData, setFormData] = useState({
    id: terapeuta?.id || `new-${Date.now()}`,
    nome: terapeuta?.nome || "",
    email: terapeuta?.email || "",
    foto: terapeuta?.foto || "",
    role: terapeuta?.role || "funcionario",
    especialidades: terapeuta?.especialidades || [],
    horarioInicio: terapeuta?.horarioInicio || "08:00",
    horarioFim: terapeuta?.horarioFim || "18:00",
    senha: terapeuta?.senha || "",
  })
  const [enviandoEmail, setEnviandoEmail] = useState(false)
  const [selectedEspecialidade, setSelectedEspecialidade] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [todasEspecialidades, setTodasEspecialidades] = useState<string[]>(especialidades)
  const emailService = useEmailService()
  // Adicionar estados para armazenar os erros de cada campo
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const isNewTerapeuta = formData.id.startsWith("new-")

  // Carregar especialidades do localStorage
  useEffect(() => {
    try {
      const storedEspecialidades = localStorage.getItem("especialidades")
      if (storedEspecialidades) {
        setTodasEspecialidades(JSON.parse(storedEspecialidades))
      }
    } catch (error) {
      console.error("Erro ao carregar especialidades do localStorage:", error)
    }
  }, [])

  const handleChange = (field: string, value: any) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  const handleAddEspecialidade = () => {
    if (!selectedEspecialidade || formData.especialidades.includes(selectedEspecialidade)) return

    setFormData({
      ...formData,
      especialidades: [...formData.especialidades, selectedEspecialidade],
    })
    setSelectedEspecialidade("")
  }

  const handleRemoveEspecialidade = (esp: string) => {
    setFormData({
      ...formData,
      especialidades: formData.especialidades.filter((e) => e !== esp),
    })
  }

  // Modificar a função handleSubmit para incluir validação completa
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Resetar erros anteriores
    setErrors({})

    // Validar todos os campos
    const newErrors: Record<string, string> = {}

    // Validar nome
    if (!formData.nome.trim()) {
      newErrors.nome = "O nome é obrigatório"
    } else if (formData.nome.trim().length < 3) {
      newErrors.nome = "O nome deve ter pelo menos 3 caracteres"
    }

    // Validar email
    if (!formData.email) {
      newErrors.email = "O email é obrigatório"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Digite um email válido"
    }

    // Validar senha para novos terapeutas
    if (formData.id.startsWith("new-")) {
      if (!formData.senha) {
        newErrors.senha = "A senha é obrigatória para novos terapeutas"
      } else if (formData.senha.length < 6) {
        newErrors.senha = "A senha deve ter pelo menos 6 caracteres"
      }
    }

    // Validar especialidades
    if (formData.especialidades.length === 0) {
      newErrors.especialidades = "Selecione pelo menos uma especialidade"
    }

    // Se houver erros, exibi-los e interromper o envio
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setIsSubmitting(true)

    // Se for um novo terapeuta, enviar email
    if (formData.id.startsWith("new-")) {
      setEnviandoEmail(true)

      try {
        // Simular envio de email
        const enviado = await emailService.sendInvite(formData.email, formData.nome)

        if (enviado) {
          // Salvar terapeuta
          onSave(formData)

          // Mostrar confirmação adicional
          toast({
            title: "Terapeuta cadastrado com sucesso",
            description: `${formData.nome} foi adicionado e um email de convite foi enviado para ${formData.email}`,
          })
        } else {
          throw new Error("Falha ao enviar email")
        }
      } catch (error) {
        console.error("Erro ao enviar email:", error)
        toast({
          variant: "destructive",
          title: "Erro ao enviar convite",
          description:
            "Não foi possível enviar o email de convite. O terapeuta foi cadastrado, mas precisará ser convidado novamente.",
        })

        // Mesmo com erro no email, salvar o terapeuta
        onSave(formData)
      } finally {
        setEnviandoEmail(false)
        setIsSubmitting(false)
      }
    } else {
      onSave(formData)
      setIsSubmitting(false)
    }
  }

  // Filtrar especialidades que já foram selecionadas
  const especialidadesDisponiveis = todasEspecialidades.filter((esp) => !formData.especialidades.includes(esp))

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex flex-col items-center mb-4">
        <ImageUpload
          currentImage={formData.foto}
          onImageChange={(url) => handleChange("foto", url)}
          name={formData.nome}
        />
        <p className="text-xs text-muted-foreground mt-2">Clique na imagem para alterar</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="nome">Nome</Label>
        <Input id="nome" value={formData.nome} onChange={(e) => handleChange("nome", e.target.value)} required />
        {errors.nome && <p className="text-sm text-destructive mt-1">{errors.nome}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => handleChange("email", e.target.value)}
          required
        />
        {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="senha">Senha</Label>
        <div className="relative">
          <Input
            id="senha"
            type={showPassword ? "text" : "password"}
            value={formData.senha}
            onChange={(e) => handleChange("senha", e.target.value)}
            placeholder="Digite a senha do usuário"
            required={formData.id.startsWith("new-")}
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="absolute right-0 top-0 h-full"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
        </div>
        {errors.senha && <p className="text-sm text-destructive mt-1">{errors.senha}</p>}
        <p className="text-xs text-muted-foreground">
          {formData.id.startsWith("new-")
            ? "Defina uma senha inicial para o usuário"
            : "Deixe em branco para manter a senha atual"}
        </p>
      </div>

      <div className="space-y-2">
        <Label>Especialidades</Label>
        <div className="flex gap-2">
          <Select value={selectedEspecialidade} onValueChange={setSelectedEspecialidade}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Selecione uma especialidade" />
            </SelectTrigger>
            <SelectContent>
              {especialidadesDisponiveis.map((esp) => (
                <SelectItem key={esp} value={esp}>
                  {esp}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button type="button" onClick={handleAddEspecialidade} disabled={!selectedEspecialidade}>
            Adicionar
          </Button>
        </div>

        {formData.especialidades.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.especialidades.map((esp) => (
              <Badge key={esp} variant="secondary" className="flex items-center gap-1 p-1">
                {esp}
                <button
                  type="button"
                  onClick={() => handleRemoveEspecialidade(esp)}
                  className="ml-1 rounded-full hover:bg-muted"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
        {errors.especialidades && <p className="text-sm text-destructive mt-1">{errors.especialidades}</p>}
      </div>

      <div className="space-y-2">
        <Label>Perfil de Acesso</Label>
        <RadioGroup
          value={formData.role}
          onValueChange={(value) => handleChange("role", value)}
          className="flex space-x-4"
        >
          <div className="flex items-center space-x-2 border rounded-md p-2 hover:bg-muted/20">
            <RadioGroupItem value="admin" id="admin" />
            <Label htmlFor="admin" className="cursor-pointer">
              Administrador
            </Label>
          </div>
          <div className="flex items-center space-x-2 border rounded-md p-2 hover:bg-muted/20">
            <RadioGroupItem value="funcionario" id="funcionario" />
            <Label htmlFor="funcionario" className="cursor-pointer">
              Funcionário
            </Label>
          </div>
        </RadioGroup>
      </div>

      <div className="pt-4 flex justify-end">
        <Button type="submit" disabled={isSubmitting} className="w-full">
          {isSubmitting ? "Salvando..." : isNewTerapeuta ? "Criar" : "Salvar alterações"}
        </Button>
      </div>
    </form>
  )
}
