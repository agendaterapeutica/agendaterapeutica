"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Copy, Save } from "lucide-react"

interface Horario {
  diaSemana: string
  horaInicio: string
  horaFim: string
}

const diasDaSemana = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

const HorariosForm = () => {
  const [horarios, setHorarios] = useState<Horario[]>(
    diasDaSemana.map((dia) => ({ diaSemana: dia, horaInicio: "", horaFim: "" })),
  )

  const handleInputChange = (index: number, field: string, value: string) => {
    const newHorarios = [...horarios]
    newHorarios[index][field] = value
    setHorarios(newHorarios)
  }

  const handleAplicarParaTodos = () => {
    const primeiroHorario = horarios[0]
    const novosHorarios = diasDaSemana.map((dia) => ({
      diaSemana: dia,
      horaInicio: primeiroHorario.horaInicio,
      horaFim: primeiroHorario.horaFim,
    }))
    setHorarios(novosHorarios)
  }

  const handleSalvarHorarios = () => {
    // Lógica para salvar horários
    console.log("Horários salvos:", horarios)
    // Aqui você pode implementar a lógica para salvar no localStorage ou enviar para uma API
  }

  return (
    <div>
      <Table>
        <TableCaption>Defina os horários de funcionamento.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">Dia da Semana</TableHead>
            <TableHead>Hora de Início</TableHead>
            <TableHead>Hora de Fim</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {horarios.map((horario, index) => (
            <TableRow key={index}>
              <TableCell>{horario.diaSemana}</TableCell>
              <TableCell>
                <Input
                  type="time"
                  value={horario.horaInicio}
                  onChange={(e) => handleInputChange(index, "horaInicio", e.target.value)}
                />
              </TableCell>
              <TableCell>
                <Input
                  type="time"
                  value={horario.horaFim}
                  onChange={(e) => handleInputChange(index, "horaFim", e.target.value)}
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {/* Botões em um container flexível com melhor responsividade */}
      <div className="flex flex-wrap justify-center gap-2 mt-4">
        <Button variant="outline" size="sm" onClick={handleAplicarParaTodos} className="text-xs">
          <Copy className="h-3 w-3 mr-1" />
          Aplicar para todos
        </Button>

        <Button variant="default" size="sm" onClick={handleSalvarHorarios} className="text-xs">
          <Save className="h-3 w-3 mr-1" />
          Salvar Horários
        </Button>
      </div>
    </div>
  )
}

export default HorariosForm
