"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Camera, X } from "lucide-react"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"

interface ImageUploadProps {
  currentImage: string
  onImageChange: (imageUrl: string) => void
  name?: string
  className?: string
}

export function ImageUpload({ currentImage, onImageChange, name = "", className = "" }: ImageUploadProps) {
  const [previewUrl, setPreviewUrl] = useState<string>(currentImage)
  const [isHovering, setIsHovering] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Simular o upload convertendo para base64
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]

    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      if (event.target?.result) {
        const imageUrl = event.target.result.toString()
        setPreviewUrl(imageUrl)
        onImageChange(imageUrl)
      }
    }
    reader.readAsDataURL(file)
  }

  const handleCaptureClick = () => {
    fileInputRef.current?.click()
  }

  const handleRemoveImage = () => {
    setPreviewUrl("")
    onImageChange("")
    if (fileInputRef.current) fileInputRef.current.value = ""
  }

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className="relative" onMouseEnter={() => setIsHovering(true)} onMouseLeave={() => setIsHovering(false)}>
        <Avatar className="w-32 h-32">
          <AvatarImage src={previewUrl} alt={name} />
          <AvatarFallback className="text-2xl font-bold bg-primary text-primary-foreground">
            {name?.substring(0, 2).toUpperCase() || "?"}
          </AvatarFallback>
        </Avatar>

        {isHovering && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full">
            <div className="flex gap-1">
              <Button type="button" variant="secondary" size="sm" onClick={handleCaptureClick} className="h-8 w-8 p-0">
                <Camera className="h-4 w-4" />
              </Button>
              <Button type="button" variant="destructive" size="sm" onClick={handleRemoveImage} className="h-8 w-8 p-0">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
      <Input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
    </div>
  )
}
