"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Users, UserCircle, Tag, User, Settings, Search } from "lucide-react"
import { useEffect, useState } from "react"

interface SidebarProps {
  isMobile?: boolean
  onNavItemClick?: () => void
}

export function Sidebar({ isMobile = false, onNavItemClick }: SidebarProps) {
  const pathname = usePathname()
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    // Verificar se o usuário é admin
    try {
      const userRole = sessionStorage.getItem("userRole")
      setIsAdmin(userRole === "admin")
    } catch (error) {
      console.error("Erro ao verificar papel do usuário:", error)
    }
  }, [])

  const navItems = [
    {
      name: "Agendamento",
      href: "/agenda",
      icon: Calendar,
      allowedRoles: ["admin", "funcionario"],
    },
    {
      name: "Cadastro de Horários",
      href: "/agenda/horarios",
      icon: Clock,
      allowedRoles: ["admin"],
    },
    {
      name: "Cadastro de Terapeutas",
      href: "/agenda/terapeutas",
      icon: UserCircle,
      allowedRoles: ["admin"],
    },
    {
      name: "Cadastro de Pacientes",
      href: "/agenda/pacientes/cadastro",
      icon: User,
      allowedRoles: ["admin"],
    },
    {
      name: "Pacientes",
      href: "/agenda/pacientes",
      icon: Users,
      allowedRoles: ["admin", "funcionario"],
    },
    {
      name: "Cadastro de Especialidades",
      href: "/agenda/especialidades",
      icon: Tag,
      allowedRoles: ["admin"],
    },
    {
      name: "Consultas",
      href: "/agenda/consultas",
      icon: Search,
      allowedRoles: ["admin"], // Removido "funcionario" para que apenas admin veja esta opção
    },
    {
      name: "Configurações",
      href: "/agenda/configuracoes",
      icon: Settings,
      allowedRoles: ["admin"],
    },
  ]

  const filteredNavItems = navItems.filter((item) => isAdmin || item.allowedRoles.includes("funcionario"))

  return (
    <div
      className={cn("flex h-full w-[240px] flex-col border-r bg-background", isMobile ? "w-full" : "hidden md:flex")}
    >
      <div className="flex-1 overflow-auto py-2">
        <nav className="grid items-start px-2 text-sm font-medium">
          {filteredNavItems.map((item) => {
            const isActive = pathname === item.href

            return (
              <Link key={item.href} href={item.href} onClick={onNavItemClick}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={cn(
                    "flex w-full items-center justify-start gap-3 px-3",
                    isActive ? "bg-secondary" : "transparent",
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.name}
                </Button>
              </Link>
            )
          })}
        </nav>
      </div>
    </div>
  )
}
