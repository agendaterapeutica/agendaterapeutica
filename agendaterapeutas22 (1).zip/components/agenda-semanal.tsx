"use client"

import type React from "react"

import { useState, useEffect, useCallback, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { AgendamentoForm } from "@/components/agendamento-form"
import { mockAgendamentos, mockPacientes } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import {
  Trash2,
  Users,
  User,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Clock,
  FileDown,
  Info,
  X,
  Edit,
  Star,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { PrintButton } from "@/components/print-button"
import * as XLSX from "xlsx"

interface AgendaSemanalProps {
  terapeutaId?: string
  pacienteId?: string
  readOnly?: boolean
}

const diasSemana = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

// Lista completa de todos os horários possíveis
const horariosDisponiveis = [
  "00:00",
  "01:00",
  "02:00",
  "03:00",
  "04:00",
  "05:00",
  "06:00",
  "07:00",
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
  "22:00",
  "23:00",
]

export function AgendaSemanal({ terapeutaId, pacienteId, readOnly = false }: AgendaSemanalProps) {
  const [agendamentos, setAgendamentos] = useState<any[]>([])
  const [terapeutas, setTerapeutas] = useState<any[]>([])
  const [pacientes, setPacientes] = useState<any[]>([])
  const [selectedAgendamento, setSelectedAgendamento] = useState<any | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false)
  const [isLimparAgendaDialogOpen, setIsLimparAgendaDialogOpen] = useState(false)
  const [currentDayIndex, setCurrentDayIndex] = useState(0)
  const [viewMode, setViewMode] = useState<"day" | "week">("week")
  const [isLoading, setIsLoading] = useState(false)
  const [agendamentoToDelete, setAgendamentoToDelete] = useState<any | null>(null)
  const [conflitosAtuais, setConflitosAtuais] = useState<any[]>([])
  const [horariosExibidos, setHorariosExibidos] = useState<string[]>([])
  const { toast } = useToast()

  // Listener para eventos de foco em célula
  useEffect(() => {
    const handleFocarCelula = (event: CustomEvent) => {
      const { dia, horario, paciente, apenasDestaque } = event.detail

      // Exibir apenas o dia específico se estiver no modo semana
      if (viewMode === "week") {
        const diaIndex = diasSemana.indexOf(dia)
        if (diaIndex >= 0) {
          setCurrentDayIndex(diaIndex)
          setViewMode("day")
        }
      }

      // Aguardar o DOM ser atualizado
      setTimeout(() => {
        // Focalizar na célula específica
        const celula = document.querySelector(`td[data-dia="${dia}"][data-horario="${horario}"]`)

        if (celula) {
          celula.scrollIntoView({ behavior: "smooth", block: "center" })

          // Adicionar efeito de destaque temporário
          celula.classList.add("highlight-cell")
          setTimeout(() => {
            celula.classList.remove("highlight-cell")

            // Simular clique para abrir o formulário de agendamento apenas se não for modo somente leitura
            // e se não for solicitado apenas destaque (apenasDestaque = true)
            if (!readOnly && !apenasDestaque) {
              // Clicar na célula
              ;(celula as HTMLElement).click()

              // Aguardar o diálogo abrir
              setTimeout(() => {
                // Se um paciente foi especificado, selecioná-lo
                if (paciente) {
                  const pacienteSelect = document.querySelector('select[id="paciente"]') as HTMLSelectElement
                  if (pacienteSelect) {
                    pacienteSelect.value = paciente

                    // Disparar evento de mudança para atualizar o estado
                    const event = new Event("change", { bubbles: true })
                    pacienteSelect.dispatchEvent(event)
                  }
                }
              }, 100)
            }
          }, 2000)
        }
      }, 100)
    }

    // Registrar o listener
    window.addEventListener("focar-celula", handleFocarCelula as EventListener)

    // Limpar o listener
    return () => {
      window.removeEventListener("focar-celula", handleFocarCelula as EventListener)
    }
  }, [viewMode, diasSemana, readOnly])

  // Ref para o link de download
  const downloadLinkRef = useRef<HTMLAnchorElement | null>(null)
  // Ref para a tabela de impressão
  const printTableRef = useRef<HTMLDivElement>(null)
  // Ref para a célula com conflito
  const conflictCellRef = useRef<HTMLTableCellElement | null>(null)
  // Ref para a célula do horário atual
  const currentTimeRef = useRef<HTMLTableCellElement | null>(null)
  // Ref para controlar se os dados já foram carregados
  const dataLoadedRef = useRef(false)

  // Função para carregar dados
  const carregarDados = useCallback(() => {
    setIsLoading(true)
    try {
      // Carregar terapeutas
      const storedTerapeutas = localStorage.getItem("terapeutas")
      if (storedTerapeutas) {
        setTerapeutas(JSON.parse(storedTerapeutas))
      }

      // Carregar pacientes
      const storedPacientes = localStorage.getItem("pacientes")
      if (storedPacientes) {
        setPacientes(JSON.parse(storedPacientes))
      } else {
        setPacientes(mockPacientes)
      }

      // Carregar agendamentos
      const storedAgendamentos = localStorage.getItem("agendamentos")
      if (storedAgendamentos) {
        setAgendamentos(JSON.parse(storedAgendamentos))
      } else {
        // Se não houver dados no localStorage, salvar os dados iniciais
        setAgendamentos(mockAgendamentos)
        localStorage.setItem("agendamentos", JSON.stringify(mockAgendamentos))
      }
    } catch (error) {
      console.error("Erro ao carregar dados do localStorage:", error)
      setAgendamentos(mockAgendamentos)
      setPacientes(mockPacientes)
    } finally {
      setIsLoading(false)
      dataLoadedRef.current = true
    }
  }, [])

  // Carregar dados iniciais - modificado para evitar o erro flushSync
  useEffect(() => {
    if (!dataLoadedRef.current) {
      carregarDados()
    }
  }, [carregarDados])

  // Atualizar quando o terapeuta mudar
  useEffect(() => {
    if (terapeutaId && dataLoadedRef.current) {
      // Usar setTimeout para evitar o erro flushSync
      const timer = setTimeout(() => {
        carregarDados()
      }, 0)
      return () => clearTimeout(timer)
    }
  }, [terapeutaId, carregarDados])

  // Criar elemento de link para download uma vez
  useEffect(() => {
    if (!downloadLinkRef.current) {
      const link = document.createElement("a")
      link.style.display = "none"
      document.body.appendChild(link)
      downloadLinkRef.current = link

      // Cleanup quando o componente for desmontado
      return () => {
        if (downloadLinkRef.current) {
          document.body.removeChild(downloadLinkRef.current)
        }
      }
    }
  }, [])

  // Adicionar listeners para eventos de atualização
  useEffect(() => {
    // Listener para mudanças no localStorage
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "agendamentos" || e.key === "pacientes" || e.key === "terapeutas") {
        // Usar setTimeout para evitar o erro flushSync
        setTimeout(() => {
          carregarDados()
        }, 0)
      }
    }

    // Listener para eventos personalizados
    const handleAgendamentoAlterado = () => {
      // Usar setTimeout para evitar o erro flushSync
      setTimeout(() => {
        carregarDados()
      }, 0)
    }

    // Registrar os listeners
    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("agendamento-alterado", handleAgendamentoAlterado)

    // Limpar os listeners quando o componente for desmontado
    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("agendamento-alterado", handleAgendamentoAlterado)
    }
  }, [carregarDados])

  const terapeuta = terapeutas.find((t) => t.id === terapeutaId)

  // Filtrar agendamentos pelo terapeuta selecionado e remover referências a pacientes ou terapeutas excluídos
  const filteredAgendamentos = agendamentos.filter((a) => {
    // Verificar se o terapeuta existe
    const terapeutaExiste = terapeutas.some((t) => t.id === a.terapeutaId)
    if (!terapeutaExiste) return false

    // Verificar se o agendamento é do terapeuta selecionado
    if (a.terapeutaId !== terapeutaId) return false

    // Verificar se o paciente foi especificado
    if (pacienteId) {
      if (a.tipo === "individual" || a.tipo === "especial") {
        // Verificar se o paciente existe
        const pacienteExiste = pacientes.some((p) => p.id === a.pacienteId)
        if (!pacienteExiste) return false

        return a.pacienteId === pacienteId
      } else if (a.tipo === "grupo" && a.pacienteIds) {
        // Filtrar pacientes que não existem mais
        const pacientesValidos = a.pacienteIds.filter((id: string) => pacientes.some((p) => p.id === id))

        // Atualizar a lista de pacientes do grupo
        if (pacientesValidos.length !== a.pacienteIds.length) {
          a.pacienteIds = pacientesValidos
        }

        return pacientesValidos.includes(pacienteId)
      }
      return false
    }

    // Verificar e limpar pacientes que não existem mais
    if (a.tipo === "individual" || a.tipo === "especial") {
      const pacienteExiste = pacientes.some((p) => p.id === a.pacienteId)
      return pacienteExiste
    } else if (a.tipo === "grupo" && a.pacienteIds) {
      // Filtrar pacientes que não existem mais
      const pacientesValidos = a.pacienteIds.filter((id: string) => pacientes.some((p) => p.id === id))

      // Atualizar a lista de pacientes do grupo
      if (pacientesValidos.length !== a.pacienteIds.length) {
        a.pacienteIds = pacientesValidos
      }

      return pacientesValidos.length > 0
    }

    return true
  })

  // Dias visíveis com base no modo de visualização
  const visibleDays = viewMode === "day" ? [diasSemana[currentDayIndex]] : diasSemana

  const handlePreviousDay = () => {
    setCurrentDayIndex((prev) => (prev - 1 + diasSemana.length) % diasSemana.length)
  }

  const handleNextDay = () => {
    setCurrentDayIndex((prev) => (prev + 1) % diasSemana.length)
  }

  // Função para selecionar automaticamente o dia da semana atual
  const handleSelectCurrentDay = () => {
    const hoje = new Date()
    // getDay() retorna 0 para domingo, 1 para segunda, etc.
    // Precisamos ajustar para nosso array que começa com Segunda (0)
    let diaAtual = hoje.getDay() - 1
    if (diaAtual < 0) diaAtual = 6 // Se for domingo (0), ajustar para 6 no nosso array

    // Obter hora atual
    const horaAtual = hoje.getHours().toString().padStart(2, "0") + ":00"

    setCurrentDayIndex(diaAtual)
    setViewMode("day")

    toast({
      title: "Dia atual selecionado",
      description: `Visualizando agenda de ${diasSemana[diaAtual]}`,
    })

    // Focalizar na célula do horário atual - modificado para evitar o erro flushSync
    setTimeout(() => {
      const diaAtualStr = diasSemana[diaAtual]
      const celula = document.querySelector(`td[data-dia="${diaAtualStr}"][data-horario="${horaAtual}"]`)

      if (celula) {
        celula.scrollIntoView({ behavior: "smooth", block: "center" })

        // Adicionar efeito de destaque temporário
        celula.classList.add("highlight-cell")
        setTimeout(() => {
          celula.classList.remove("highlight-cell")
        }, 2000)
      }
    }, 100)
  }

  // Atualizar a função handleCellClick para passar os terapeutas disponíveis para o formulário
  const handleCellClick = (dia: string, horario: string) => {
    if (readOnly) return

    // Verificar se já existe agendamento neste horário
    const existingAgendamento = filteredAgendamentos.find((a) => a.dia === dia && a.horario === horario)

    if (existingAgendamento) {
      // Se for um agendamento especial, precisamos encontrar todos os agendamentos relacionados
      if (existingAgendamento.tipo === "especial" && existingAgendamento.agendamentoEspecialId) {
        // Encontrar todos os agendamentos com o mesmo agendamentoEspecialId
        const agendamentosRelacionados = agendamentos.filter(
          (a) => a.agendamentoEspecialId === existingAgendamento.agendamentoEspecialId,
        )

        // Extrair todos os terapeutaIds
        const terapeutaIds = agendamentosRelacionados.map((a) => a.terapeutaId)

        // Criar um objeto de agendamento consolidado para edição
        const agendamentoConsolidado = {
          ...existingAgendamento,
          terapeutaIds: terapeutaIds,
        }

        setSelectedAgendamento(agendamentoConsolidado)
      } else {
        setSelectedAgendamento(existingAgendamento)
      }
      setIsFormDialogOpen(true)
    } else {
      setSelectedAgendamento({
        id: `new-${Date.now()}`,
        terapeutaId,
        dia,
        horario,
        tipo: "individual",
        pacienteIds: [],
        terapeutaIds: [terapeutaId], // Inicializar com o terapeuta atual
        comentario: "",
      })
      setIsFormDialogOpen(true)
    }
  }

  const handleEditCell = (agendamento: any, e: React.MouseEvent) => {
    e.stopPropagation() // Impedir que o clique propague para a célula

    if (!agendamento) return

    setSelectedAgendamento(agendamento)
    setIsFormDialogOpen(true)
  }

  const handleDeleteCell = (agendamento: any, e: React.MouseEvent) => {
    e.stopPropagation() // Impedir que o clique propague para a célula

    if (!agendamento) return

    setAgendamentoToDelete(agendamento)
    setIsDeleteDialogOpen(true)
  }

  // Atualizar a função handleSaveAgendamento para lidar com agendamentos especiais
  const handleSaveAgendamento = (agendamento: any) => {
    // Se for um cancelamento, apenas fechar o diálogo
    if (agendamento.cancelled) {
      setIsFormDialogOpen(false)
      setConflitosAtuais([])
      return
    }

    // Verificar conflitos apenas se não for um agendamento especial
    if (agendamento.tipo !== "especial") {
      const conflitos = verificarConflitos(agendamento)

      if (conflitos.length > 0) {
        // Preparar informações de conflito de forma mais detalhada
        const conflitosDetalhados = conflitos.map((c) => {
          const terapeuta = terapeutas.find((t) => t.id === c.terapeutaId)
          const paciente = pacientes.find((p) => p.id === c.pacienteId)
          const terapeutaAtual = terapeutas.find((t) => t.id === terapeutaId)

          return {
            terapeutaId: c.terapeutaId,
            terapeutaNome: terapeuta?.nome || "Terapeuta desconhecido",
            terapeutaAtualNome: terapeutaAtual?.nome || "Terapeuta atual",
            pacienteId: c.pacienteId,
            pacienteNome: paciente?.nome || "Paciente desconhecido",
            dia: c.dia,
            horario: c.horario,
          }
        })

        // Atualizar o estado de conflitos
        setConflitosAtuais(conflitosDetalhados)

        // Não prosseguir com o salvamento se houver conflitos
        return
      } else {
        // Limpar conflitos se não houver mais
        setConflitosAtuais([])
      }
    }

    let updatedAgendamentos = [...agendamentos]

    // Se for um agendamento especial, criar um agendamento para cada terapeuta
    if (agendamento.tipo === "especial" && agendamento.terapeutaIds && agendamento.terapeutaIds.length > 0) {
      // Se for um novo agendamento
      if (agendamento.id.startsWith("new-")) {
        // Criar um ID base para todos os agendamentos relacionados
        const baseId = `agendamento-especial-${Date.now()}`

        // Criar um agendamento para cada terapeuta
        const novosAgendamentos = agendamento.terapeutaIds.map((terapeutaId: string, index: number) => {
          return {
            ...agendamento,
            id: `${baseId}-${index}`,
            terapeutaId: terapeutaId,
            // Manter o array de terapeutaIds para referência
            agendamentoEspecialId: baseId, // ID comum para todos os agendamentos do grupo especial
          }
        })

        updatedAgendamentos = [...agendamentos, ...novosAgendamentos]

        toast({
          title: "Agendamento especial criado",
          description: `Agendamento especial para ${agendamento.dia} às ${agendamento.horario} criado com sucesso para ${agendamento.terapeutaIds.length} terapeutas.`,
        })
      } else {
        // Se for edição de um agendamento especial existente
        // Primeiro, encontrar todos os agendamentos relacionados pelo agendamentoEspecialId
        const agendamentoEspecialId = agendamento.agendamentoEspecialId || agendamento.id

        // Remover todos os agendamentos relacionados
        updatedAgendamentos = agendamentos.filter(
          (a) => a.agendamentoEspecialId !== agendamentoEspecialId && a.id !== agendamentoEspecialId,
        )

        // Criar novos agendamentos para cada terapeuta
        const novosAgendamentos = agendamento.terapeutaIds.map((terapeutaId: string, index: number) => {
          return {
            ...agendamento,
            id: `${agendamentoEspecialId}-${index}`,
            terapeutaId: terapeutaId,
            agendamentoEspecialId: agendamentoEspecialId,
          }
        })

        updatedAgendamentos = [...updatedAgendamentos, ...novosAgendamentos]

        toast({
          title: "Agendamento especial atualizado",
          description: `Agendamento especial para ${agendamento.dia} às ${agendamento.horario} atualizado com sucesso.`,
        })
      }
    } else {
      // Processamento normal para outros tipos de agendamento
      // Se for um novo agendamento
      if (agendamento.id.startsWith("new-")) {
        const newAgendamento = {
          ...agendamento,
          id: `agendamento-${Date.now()}`,
        }
        updatedAgendamentos = [...agendamentos, newAgendamento]
        toast({
          title: "Agendamento criado",
          description: `Agendamento para ${agendamento.dia} às ${agendamento.horario} criado com sucesso.`,
        })
      } else {
        // Se for edição
        updatedAgendamentos = agendamentos.map((a) => (a.id === agendamento.id ? agendamento : a))
        toast({
          title: "Agendamento atualizado",
          description: `Agendamento para ${agendamento.dia} às ${agendamento.horario} atualizado com sucesso.`,
        })
      }
    }

    setAgendamentos(updatedAgendamentos)

    // Salvar no localStorage
    try {
      localStorage.setItem("agendamentos", JSON.stringify(updatedAgendamentos))

      // Disparar um evento de storage para notificar outros componentes
      window.dispatchEvent(
        new CustomEvent("agendamento-alterado", {
          detail: { action: "save", id: agendamento.id },
        }),
      )
    } catch (error) {
      console.error("Erro ao salvar agendamentos no localStorage:", error)
    }

    // Fechar o diálogo após salvar
    setIsFormDialogOpen(false)
  }

  const handleDeleteAgendamento = () => {
    if (!agendamentoToDelete) return

    let updatedAgendamentos = [...agendamentos]

    // Se for um agendamento especial, remover todos os agendamentos relacionados
    if (agendamentoToDelete.tipo === "especial" && agendamentoToDelete.agendamentoEspecialId) {
      updatedAgendamentos = agendamentos.filter(
        (a) => a.agendamentoEspecialId !== agendamentoToDelete.agendamentoEspecialId,
      )
    } else {
      // Caso contrário, remover apenas o agendamento específico
      updatedAgendamentos = agendamentos.filter((a) => a.id !== agendamentoToDelete.id)
    }

    setAgendamentos(updatedAgendamentos)

    // Salvar no localStorage
    try {
      localStorage.setItem("agendamentos", JSON.stringify(updatedAgendamentos))

      // Disparar um evento de storage para notificar outros componentes
      window.dispatchEvent(
        new CustomEvent("agendamento-alterado", {
          detail: { action: "delete", id: agendamentoToDelete.id },
        }),
      )
    } catch (error) {
      console.error("Erro ao salvar agendamentos no localStorage:", error)
    }

    // Fechar os diálogos
    setIsDeleteDialogOpen(false)
    setAgendamentoToDelete(null)

    toast({
      title: "Agendamento removido",
      description: `Agendamento para ${agendamentoToDelete.dia} às ${agendamentoToDelete.horario} removido com sucesso.`,
    })
  }

  const handleLimparAgenda = () => {
    if (!terapeutaId) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Nenhum terapeuta selecionado.",
      })
      setIsLimparAgendaDialogOpen(false)
      return
    }

    const updatedAgendamentos = agendamentos.filter((a) => a.terapeutaId !== terapeutaId)
    setAgendamentos(updatedAgendamentos)

    // Salvar no localStorage
    try {
      localStorage.setItem("agendamentos", JSON.stringify(updatedAgendamentos))

      // Disparar um evento de storage para notificar outros componentes
      window.dispatchEvent(
        new CustomEvent("agendamento-alterado", {
          detail: { action: "clear", terapeutaId },
        }),
      )
    } catch (error) {
      console.error("Erro ao salvar agendamentos no localStorage:", error)
    }

    setIsLimparAgendaDialogOpen(false)

    toast({
      title: "Agenda limpa",
      description: `Todos os agendamentos do terapeuta foram removidos com sucesso.`,
    })
  }

  const verificarConflitos = (agendamento: any) => {
    // Se for agendamento em grupo ou reunião, não há conflito
    if (agendamento.tipo !== "individual") return []

    // Verificar se o paciente já tem agendamento no mesmo horário
    return agendamentos.filter(
      (a) =>
        a.id !== agendamento.id &&
        a.tipo === "individual" &&
        a.pacienteId === agendamento.pacienteId &&
        a.dia === agendamento.dia &&
        a.horario === agendamento.horario,
    )
  }

  const getAgendamentoByHorario = useCallback(
    (dia: string, horario: string) => {
      return filteredAgendamentos.find((a) => a.dia === dia && a.horario === horario)
    },
    [filteredAgendamentos],
  )

  const getPacienteById = useCallback(
    (id: string) => {
      return pacientes.find((p) => p.id === id)
    },
    [pacientes],
  )

  // Verificar se o horário está disponível para o terapeuta no dia específico
  const isHorarioDisponivel = useCallback(
    (dia: string, horario: string) => {
      if (!terapeuta) return false

      // Se o terapeuta tem horários configurados por dia
      if (terapeuta.rangesPorDia && terapeuta.rangesPorDia[dia]) {
        const range = terapeuta.rangesPorDia[dia]

        // Verificar se o dia está ativo
        if (!range.ativo) return false

        // Verificar se o horário está dentro do range
        if (horario < range.inicio || horario > range.fim) return false

        // Verificar se o horário está bloqueado
        if (terapeuta.horariosBloqueados && terapeuta.horariosBloqueados[dia]) {
          if (terapeuta.horariosBloqueados[dia].includes(horario)) {
            return false
          }
        }

        return true
      }

      // Caso contrário, usar o horário geral
      return horario >= terapeuta.horarioInicio && horario <= terapeuta.horarioFim
    },
    [terapeuta],
  )

  // Função para obter os horários de trabalho do terapeuta
  const getHorariosTerapeuta = useCallback(() => {
    if (!terapeuta) return []

    // Verificar se o terapeuta tem configurações de horário por dia
    if (terapeuta.rangesPorDia) {
      // Obter todos os horários de início e fim dos dias ativos
      const horariosAtivos: string[] = []

      Object.entries(terapeuta.rangesPorDia).forEach(([dia, config]: [string, any]) => {
        if (config.ativo) {
          // Para cada dia ativo, adicionar todos os horários no intervalo
          for (let i = 0; i < horariosDisponiveis.length; i++) {
            const horario = horariosDisponiveis[i]
            if (horario >= config.inicio && horario <= config.fim) {
              if (!horariosAtivos.includes(horario)) {
                horariosAtivos.push(horario)
              }
            }
          }
        }
      })

      // Ordenar os horários
      return horariosAtivos.sort()
    }

    // Caso não tenha configuração por dia, usar o horário geral
    const min = terapeuta.horarioInicio || "08:00"
    const max = terapeuta.horarioFim || "18:00"

    return horariosDisponiveis.filter((horario) => horario >= min && horario <= max)
  }, [terapeuta])

  // Atualizar os horários exibidos quando o terapeuta mudar - modificado para evitar o erro flushSync
  useEffect(() => {
    if (terapeuta) {
      const horarios = getHorariosTerapeuta()
      // Usar setTimeout para evitar o erro flushSync
      setTimeout(() => {
        setHorariosExibidos(horarios)
      }, 0)
    }
  }, [getHorariosTerapeuta, terapeuta])

  // Atualizar a função renderCellContent para exibir agendamentos especiais
  const renderCellContent = (agendamento: any) => {
    if (!agendamento) return null

    // Para agendamentos individuais
    if (agendamento.tipo === "individual") {
      const paciente = getPacienteById(agendamento.pacienteId)
      if (!paciente) return null

      return (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8 avatar">
            <AvatarImage src={paciente.foto} alt={paciente.nome} />
            <AvatarFallback>{paciente.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="overflow-hidden">
            <p className="text-sm font-medium truncate flex items-center gap-1">
              <User className="h-3 w-3 text-agenda-blue" />
              {paciente.nome}
            </p>
          </div>
        </div>
      )
    }

    // Para agendamentos em grupo
    if (agendamento.tipo === "grupo") {
      const pacienteIds = agendamento.pacienteIds || []
      const count = pacienteIds.length

      return (
        <div className="flex flex-col gap-2">
          <Badge
            variant="outline"
            className="bg-agenda-green-light text-agenda-green-dark border-agenda-green self-start"
          >
            <Users className="h-3 w-3 mr-1" />
            Grupo ({count})
          </Badge>

          <div className="flex flex-col gap-1 mt-1">
            {pacienteIds.map((pid: string) => {
              const p = getPacienteById(pid)
              if (!p) return null

              return (
                <div key={pid} className="flex items-center gap-1">
                  <Avatar className="h-5 w-5 avatar">
                    <AvatarImage src={p.foto} alt={p.nome} />
                    <AvatarFallback>{p.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs truncate">{p.nome}</span>
                </div>
              )
            })}
          </div>
        </div>
      )
    }

    // Para reuniões
    if (agendamento.tipo === "reuniao") {
      return (
        <div className="flex flex-col gap-2">
          <Badge variant="outline" className="bg-agenda-purple-light text-agenda-purple-dark border-agenda-purple">
            <Calendar className="h-3 w-3 mr-1" />
            Reunião
          </Badge>

          {agendamento.comentario && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1 cursor-help">
                    <Info className="h-3 w-3" />
                    <span className="truncate">
                      {agendamento.comentario.substring(0, 20)}
                      {agendamento.comentario.length > 20 ? "..." : ""}
                    </span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs">{agendamento.comentario}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      )
    }

    // Para agendamentos especiais
    if (agendamento.tipo === "especial") {
      const paciente = getPacienteById(agendamento.pacienteId)
      if (!paciente) return null

      // Encontrar todos os agendamentos relacionados para mostrar quantos terapeutas estão envolvidos
      const agendamentosRelacionados = agendamento.agendamentoEspecialId
        ? agendamentos.filter((a) => a.agendamentoEspecialId === agendamento.agendamentoEspecialId)
        : [agendamento]

      const terapeutasCount = agendamentosRelacionados.length

      return (
        <div className="flex flex-col gap-2">
          <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-300 self-start">
            <Star className="h-3 w-3 mr-1" />
            Especial ({terapeutasCount} terapeutas)
          </Badge>

          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6 avatar">
              <AvatarImage src={paciente.foto} alt={paciente.nome} />
              <AvatarFallback>{paciente.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <span className="text-xs font-medium truncate">{paciente.nome}</span>
          </div>

          {agendamento.comentario && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1 cursor-help">
                    <Info className="h-3 w-3" />
                    <span className="truncate">
                      {agendamento.comentario.substring(0, 20)}
                      {agendamento.comentario.length > 20 ? "..." : ""}
                    </span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs">{agendamento.comentario}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      )
    }

    return null
  }

  // Função para exportar a agenda para Excel com formatação melhorada
  const exportarParaExcel = useCallback(() => {
    if (!terapeuta) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Nenhum terapeuta selecionado.",
      })
      return
    }

    // Preparar os dados para exportação
    const dados = []

    // Adicionar cabeçalho com informações do terapeuta
    dados.push([`Agenda de ${terapeuta.nome}`])
    dados.push([`Especialidades: ${terapeuta.especialidades?.join(", ") || "Não informadas"}`])
    dados.push([`Horário de trabalho: ${terapeuta.horarioInicio || "08:00"} às ${terapeuta.horarioFim || "18:00"}`])
    dados.push([]) // Linha em branco

    // Adicionar cabeçalho da tabela
    const cabecalho = ["Horário", ...diasSemana] // Sempre exportar todos os dias da semana
    dados.push(cabecalho)

    // Criar estilos para as células
    const estiloIndividual = { fill: { fgColor: { rgb: "E6F0FF" } } } // Azul claro
    const estiloGrupo = { fill: { fgColor: { rgb: "E6F7EF" } } } // Verde claro
    const estiloReuniao = { fill: { fgColor: { rgb: "F0E7FF" } } } // Roxo claro
    const estiloEspecial = { fill: { fgColor: { rgb: "FFF8E1" } } } // Âmbar claro
    const estiloIndisponivel = { fill: { fgColor: { rgb: "FFEEEE" } } } // Vermelho claro
    const estiloHeader = {
      font: { bold: true, sz: 14 },
      alignment: { horizontal: "center" },
    }
    const estiloSubHeader = {
      font: { italic: true, sz: 12 },
      alignment: { horizontal: "center" },
    }
    const estiloTextoIndisponivel = {
      font: { color: { rgb: "FF0000" } }, // Texto vermelho
      alignment: { horizontal: "center" },
    }

    // Mapeamento de estilos por célula
    const estilosCelulas: Record<string, any> = {}

    // Adicionar dados
    for (let rowIndex = 0; rowIndex < horariosExibidos.length; rowIndex++) {
      const horario = horariosExibidos[rowIndex]
      const linha = [horario]

      for (let colIndex = 0; colIndex < diasSemana.length; colIndex++) {
        const dia = diasSemana[colIndex]
        const agendamento = getAgendamentoByHorario(dia, horario)
        const cellRef = XLSX.utils.encode_cell({ r: rowIndex + 5, c: colIndex + 1 }) // +5 para pular as linhas de cabeçalho
        const disponivel = isHorarioDisponivel(dia, horario)

        if (!disponivel) {
          // Horário indisponível
          linha.push("Indisponível")
          estilosCelulas[cellRef] = { ...estiloIndisponivel, ...estiloTextoIndisponivel }
        } else if (agendamento) {
          if (agendamento.tipo === "individual") {
            const paciente = getPacienteById(agendamento.pacienteId)
            linha.push(paciente ? `${paciente.nome} (Individual)` : "Paciente não encontrado")
            estilosCelulas[cellRef] = estiloIndividual
          } else if (agendamento.tipo === "grupo") {
            const pacienteNomes = agendamento.pacienteIds
              .map((id: string) => {
                const p = getPacienteById(id)
                return p ? p.nome : "Paciente não encontrado"
              })
              .filter(Boolean)
              .join(", ")
            linha.push(`Grupo: ${pacienteNomes}`)
            estilosCelulas[cellRef] = estiloGrupo
          } else if (agendamento.tipo === "reuniao") {
            linha.push(`Reunião${agendamento.comentario ? `: ${agendamento.comentario}` : ""}`)
            estilosCelulas[cellRef] = estiloReuniao
          } else if (agendamento.tipo === "especial") {
            const paciente = getPacienteById(agendamento.pacienteId)
            linha.push(`Especial: ${paciente ? paciente.nome : "Paciente não encontrado"}`)
            estilosCelulas[cellRef] = estiloEspecial
          } else {
            linha.push("")
          }
        } else {
          // Horário disponível mas sem agendamento - deixar em branco conforme solicitado
          linha.push("")
        }
      }

      dados.push(linha)
    }

    // Criar planilha
    const ws = XLSX.utils.aoa_to_sheet(dados)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Agenda")

    // Configurar largura das colunas
    const wscols = [
      { wch: 10 }, // Horário
      ...diasSemana.map(() => ({ wch: 30 })), // Dias da semana
    ]
    ws["!cols"] = wscols

    // Aplicar estilos às células
    for (const [cellRef, estilo] of Object.entries(estilosCelulas)) {
      if (!ws[cellRef]) continue
      ws[cellRef].s = estilo
    }

    // Aplicar estilos ao cabeçalho
    ws["A1"].s = estiloHeader
    ws["A2"].s = estiloSubHeader
    ws["A3"].s = estiloSubHeader

    // Mesclar células para o título e subtítulos
    ws["!merges"] = [
      { s: { r: 0, c: 0 }, e: { r: 0, c: diasSemana.length } },
      { s: { r: 1, c: 0 }, e: { r: 1, c: diasSemana.length } },
      { s: { r: 2, c: 0 }, e: { r: 2, c: diasSemana.length } },
    ]

    // Gerar o arquivo Excel como um blob
    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([wbout], { type: "application/octet-stream" })

    // Criar URL para o blob
    const url = URL.createObjectURL(blob)

    // Usar o link de referência para download
    if (downloadLinkRef.current) {
      downloadLinkRef.current.href = url
      downloadLinkRef.current.download = `Agenda_${terapeuta.nome}.xlsx`
      downloadLinkRef.current.click()

      // Limpar URL após o download
      URL.revokeObjectURL(url)
    }

    toast({
      title: "Agenda exportada",
      description: "A agenda foi exportada com sucesso com formatação.",
    })
  }, [terapeuta, horariosExibidos, toast, getAgendamentoByHorario, getPacienteById, diasSemana, isHorarioDisponivel])

  // Remover ou modificar a função renderPrintHeader para não exibir as informações do terapeuta
  const renderPrintHeader = () => {
    // Retornar null para não exibir o cabeçalho na impressão
    return null
  }

  // Adicionar função para verificar se é o horário atual
  const isCurrentTimeSlot = useCallback((dia: string, horario: string) => {
    const hoje = new Date()
    const diaSemanaAtual = hoje.getDay() // 0 = Domingo, 1 = Segunda, ...

    // Converter para o formato do nosso array (Segunda = 0, Terça = 1, ...)
    const diaIndex = diaSemanaAtual === 0 ? 6 : diaSemanaAtual - 1
    const diaAtual = diasSemana[diaIndex]

    // Obter hora atual
    const horaAtual = hoje.getHours()
    const minutoAtual = hoje.getMinutes()

    // Converter horario (string) para horas e minutos
    const [horaSlot, minutoSlot] = horario.split(":").map(Number)

    // Verificar se é o dia atual e se a hora atual está dentro do slot
    return dia === diaAtual && horaAtual === horaSlot && minutoAtual >= 0 && minutoAtual < 60
  }, [])

  return (
    <>
      {renderPrintHeader()}
      <Card className="print-container">
        <CardHeader className="no-print">
          <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
            <CardTitle className="text-agenda-blue-dark">Agenda</CardTitle>
            <div className="flex flex-wrap items-center gap-2 no-print">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" onClick={handleSelectCurrentDay}>
                      <Clock className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Selecionar dia atual</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <Select value={viewMode} onValueChange={(value: "day" | "week") => setViewMode(value)}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Visualização" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">Diária</SelectItem>
                  <SelectItem value="week">Semanal</SelectItem>
                </SelectContent>
              </Select>

              {viewMode === "day" && (
                <div className="flex items-center gap-1">
                  <Button variant="outline" size="icon" onClick={handlePreviousDay}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="w-24 text-center">{diasSemana[currentDayIndex]}</span>
                  <Button variant="outline" size="icon" onClick={handleNextDay}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0 md:p-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="flex flex-col items-center gap-2">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-agenda-blue border-t-transparent"></div>
                <p className="text-muted-foreground">Carregando agenda...</p>
              </div>
            </div>
          ) : (
            /* Tabela responsiva com rolagem horizontal */
            <div className="overflow-x-auto w-full" ref={printTableRef}>
              <table
                className={`w-full border-collapse print-table ${viewMode === "day" ? "print-day-view" : "print-week-view"}`}
              >
                <thead>
                  <tr>
                    <th className="border p-2 bg-muted sticky left-0 z-10">Horário</th>
                    {/* Na impressão, sempre mostrar todos os dias da semana */}
                    {(viewMode === "week" ? visibleDays : diasSemana).map((dia) => (
                      <th
                        key={dia}
                        className={`border p-2 bg-muted min-w-[150px] ${viewMode === "day" && dia !== visibleDays[0] ? "hidden print:table-cell" : ""}`}
                      >
                        {dia}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {horariosExibidos.map((horario) => (
                    <tr key={horario}>
                      <td className="border p-2 font-medium sticky left-0 bg-background z-10">{horario}</td>
                      {/* Na impressão, sempre mostrar todos os dias da semana */}
                      {(viewMode === "week" ? visibleDays : diasSemana).map((dia) => {
                        const agendamento = getAgendamentoByHorario(dia, horario)
                        let bgColor = ""
                        let printClass = ""

                        if (agendamento) {
                          if (agendamento.tipo === "individual") {
                            bgColor = "bg-agenda-blue-light"
                            printClass = "print-bg-blue"
                          } else if (agendamento.tipo === "grupo") {
                            bgColor = "bg-agenda-green-light"
                            printClass = "print-bg-green"
                          } else if (agendamento.tipo === "reuniao") {
                            bgColor = "bg-agenda-purple-light"
                            printClass = "print-bg-purple"
                          } else if (agendamento.tipo === "especial") {
                            bgColor = "bg-amber-100"
                            printClass = "print-bg-amber"
                          }
                        }

                        // Verificar se o horário está disponível para o terapeuta
                        const disponivel = isHorarioDisponivel(dia, horario)
                        const isCurrent = isCurrentTimeSlot(dia, horario)
                        const cellClass = disponivel
                          ? `${!readOnly ? "cursor-pointer hover:bg-muted/50" : ""} ${bgColor} ${printClass} ${isCurrent ? "cell-current-time" : ""}`
                          : "bg-gray-100 text-gray-400"

                        return (
                          <td
                            key={`${dia}-${horario}`}
                            className={`border p-2 h-16 relative cell-container ${cellClass} ${
                              isCurrentTimeSlot(dia, horario) ? "cell-current-time" : ""
                            } ${viewMode === "day" && dia !== visibleDays[0] ? "hidden print:table-cell" : ""}`}
                            onClick={() => disponivel && handleCellClick(dia, horario)}
                            data-dia={dia}
                            data-horario={horario}
                          >
                            {disponivel ? (
                              <>
                                {renderCellContent(agendamento)}
                                {/* Botões de editar e excluir agendamento */}
                                {!readOnly && agendamento && (
                                  <>
                                    <button
                                      className="cell-edit-button no-print"
                                      onClick={(e) => handleEditCell(agendamento, e)}
                                      aria-label="Editar agendamento"
                                    >
                                      <Edit className="h-4 w-4 text-blue-500" />
                                    </button>
                                    <button
                                      className="cell-delete-button no-print"
                                      onClick={(e) => handleDeleteCell(agendamento, e)}
                                      aria-label="Excluir agendamento"
                                    >
                                      <X className="h-4 w-4 text-red-500" />
                                    </button>
                                  </>
                                )}
                              </>
                            ) : (
                              <div className="text-xs text-center text-red-500">Indisponível</div>
                            )}
                          </td>
                        )
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col gap-4 pt-6">
          <div className="flex justify-center items-center gap-2 sm:gap-8 text-sm flex-wrap">
            <div className="flex items-center gap-1 sm:gap-2">
              <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-agenda-blue-light"></div>
              <span>Individual</span>
            </div>
            <div className="flex items-center gap-1 sm:gap-2">
              <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-agenda-green-light"></div>
              <span>Grupo</span>
            </div>
            <div className="flex items-center gap-1 sm:gap-2">
              <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-agenda-purple-light"></div>
              <span>Reunião</span>
            </div>
            <div className="flex items-center gap-1 sm:gap-2">
              <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-amber-100"></div>
              <span>Especial</span>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-2 no-print">
            {!readOnly && (
              <Button
                variant="outline"
                size="sm"
                className="text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground no-print"
                onClick={() => setIsLimparAgendaDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Limpar Agenda
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-2 no-print"
              onClick={exportarParaExcel}
            >
              <FileDown className="h-4 w-4" />
              Exportar para Excel
            </Button>

            <PrintButton className="ml-2" />
          </div>
        </CardFooter>
      </Card>

      {/* Atualizar o diálogo de formulário de agendamento para passar os terapeutas disponíveis */}
      <Dialog
        open={isFormDialogOpen}
        onOpenChange={(open) => {
          // Se estiver fechando o diálogo
          if (!open) {
            // Se houver conflitos e não for um cancelamento explícito, manter aberto
            if (conflitosAtuais.length > 0 && !selectedAgendamento?.cancelled) {
              return
            }

            // Limpar conflitos ao fechar
            setConflitosAtuais([])
          }

          setIsFormDialogOpen(open)

          // Recarregar dados quando o diálogo for fechado - modificado para evitar o erro flushSync
          if (!open) {
            setTimeout(() => carregarDados(), 0)
          }
        }}
      >
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedAgendamento?.id && !selectedAgendamento.id.startsWith("new-")
                ? "Editar Agendamento"
                : "Novo Agendamento"}
            </DialogTitle>
          </DialogHeader>
          {selectedAgendamento && (
            <AgendamentoForm
              agendamento={selectedAgendamento}
              onSave={(agendamentoData) => {
                // Se for um cancelamento, apenas fechar o diálogo
                if (agendamentoData.cancelled) {
                  setIsFormDialogOpen(false)
                  setConflitosAtuais([])
                  return
                }

                // Caso contrário, processar normalmente
                handleSaveAgendamento(agendamentoData)
              }}
              readOnly={readOnly}
              conflitos={conflitosAtuais}
              terapeutasDisponiveis={terapeutas} // Passar todos os terapeutas disponíveis
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmação de exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este agendamento? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteAgendamento}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Diálogo de confirmação para limpar agenda */}
      <AlertDialog open={isLimparAgendaDialogOpen} onOpenChange={setIsLimparAgendaDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Limpar agenda</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja remover todos os agendamentos deste terapeuta? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleLimparAgenda}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Limpar Tudo
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
