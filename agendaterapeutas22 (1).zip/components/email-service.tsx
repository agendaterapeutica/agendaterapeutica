"use client"

import { useToast } from "@/components/ui/use-toast"

interface EmailProps {
  to: string
  subject: string
  body: string
}

export const useEmailService = () => {
  const { toast } = useToast()

  const sendEmail = (emailProps: EmailProps) => {
    return new Promise<boolean>((resolve) => {
      // Simular atraso de envio de email
      setTimeout(() => {
        console.log("Email enviado:", emailProps)

        // Mostrar notificação mais detalhada
        toast({
          title: "Email enviado com sucesso",
          description: `Um convite foi enviado para ${emailProps.to}. Verifique a caixa de entrada e spam.`,
          duration: 5000,
        })

        // Simular envio real para fins de demonstração
        try {
          // Em um ambiente real, aqui seria a chamada para uma API de envio de email
          // Armazenar no localStorage para simular o envio
          const emailsEnviados = JSON.parse(localStorage.getItem("emailsEnviados") || "[]")
          emailsEnviados.push({
            ...emailProps,
            timestamp: new Date().toISOString(),
          })
          localStorage.setItem("emailsEnviados", JSON.stringify(emailsEnviados))
        } catch (error) {
          console.error("Erro ao registrar email:", error)
        }

        resolve(true)
      }, 1500)
    })
  }

  const sendInvite = async (email: string, nome: string) => {
    // Criar um corpo de email mais detalhado
    const body = `
      Olá ${nome},
      
      Você foi convidado para acessar o sistema de agendamento como terapeuta.
      
      Use o link abaixo para criar sua senha e acessar o sistema:
      https://agenda-terapeutas.vercel.app/ativar-conta?email=${encodeURIComponent(email)}
      
      Este link expira em 48 horas.
      
      Atenciosamente,
      Equipe de Agendamento
    `

    return sendEmail({
      to: email,
      subject: "Convite para acesso ao sistema de agendamento",
      body: body,
    })
  }

  return {
    sendEmail,
    sendInvite,
  }
}
