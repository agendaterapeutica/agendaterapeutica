"use client"

import { LoginForm } from "@/components/login-form"
import Image from "next/image"
import { useEffect, useState } from "react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* Banner lateral / Imagem */}
      <div className="hidden md:block w-1/2 bg-gradient-to-br from-blue-600 to-purple-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20 z-10" />
        <div className="absolute inset-0 flex items-center justify-center z-20">
          <div className="text-white text-center px-8">{/* Nome da empresa será exibido dinamicamente abaixo */}</div>
        </div>
        {/* Imagem institucional */}
        <LogoInstitucional />
      </div>

      {/* Formulário de login */}
      <div className="flex flex-col items-center justify-center w-full md:w-1/2 px-4 py-10 bg-gradient-to-b from-blue-50 to-white">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-primary">Acesso ao Sistema</h1>
            <p className="mt-2 text-muted-foreground">Faça login para acessar o sistema de agendamento</p>
          </div>
          <LoginForm />
        </div>
      </div>
    </div>
  )
}

// Componente para exibir a logo institucional
function LogoInstitucional() {
  const [logoUrl, setLogoUrl] = useState<string | null>(null)
  const [nomeEmpresa, setNomeEmpresa] = useState<string>("") // Estado para o nome da empresa

  useEffect(() => {
    try {
      // Carregar logo
      const savedLogo = localStorage.getItem("logoInstitucional")
      if (savedLogo) {
        setLogoUrl(savedLogo)
      }

      // Carregar nome da empresa
      const savedNomeEmpresa = localStorage.getItem("nomeEmpresa")
      if (savedNomeEmpresa) {
        setNomeEmpresa(savedNomeEmpresa)
      }
    } catch (error) {
      console.error("Erro ao carregar logo institucional:", error)
    }
  }, [])

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center">
      {/* Nome da empresa acima do logo */}
      {nomeEmpresa && <h1 className="text-white text-3xl font-bold mb-6 z-20 text-center px-8">{nomeEmpresa}</h1>}

      {logoUrl ? (
        <img
          src={logoUrl || "/placeholder.svg"}
          alt="Logo institucional"
          className="max-w-[80%] max-h-[60%] object-contain z-10 opacity-90"
        />
      ) : (
        <>
          <div className="absolute bottom-0 right-0 opacity-20">
            <Image
              src="/placeholder.svg?height=400&width=400"
              alt="Terapeutas"
              width={400}
              height={400}
              className="object-cover"
            />
          </div>
          <div className="absolute top-0 left-0 opacity-20">
            <Image
              src="/placeholder.svg?height=300&width=300"
              alt="Calendário"
              width={300}
              height={300}
              className="object-cover"
            />
          </div>
        </>
      )}
    </div>
  )
}
