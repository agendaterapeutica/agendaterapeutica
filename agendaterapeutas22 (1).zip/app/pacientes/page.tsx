"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { AgendaSemanal } from "@/components/agenda-semanal"
import { PacienteForm } from "@/components/paciente-form"
import { PacientesList } from "@/components/pacientes-list"
import { mockPacientes } from "@/lib/mock-data"
import { useToast } from "@/components/ui/use-toast"
import { Plus, Search } from "lucide-react"

export default function PacientesPage() {
  const [pacientes, setPacientes] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPaciente, setSelectedPaciente] = useState<any | null>(null)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  // Carregar pacientes do localStorage
  useEffect(() => {
    setIsLoading(true)
    try {
      const storedPacientes = localStorage.getItem("pacientes")
      if (storedPacientes) {
        setPacientes(JSON.parse(storedPacientes))
      } else {
        // Se não houver dados no localStorage, usar dados mock
        setPacientes(mockPacientes)
        localStorage.setItem("pacientes", JSON.stringify(mockPacientes))
      }
    } catch (error) {
      console.error("Erro ao carregar pacientes:", error)
      setPacientes(mockPacientes)
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Filtrar pacientes com base no termo de pesquisa
  const filteredPacientes = pacientes.filter(
    (paciente) =>
      paciente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      paciente.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      paciente.telefone.includes(searchTerm),
  )

  const handleAddPaciente = () => {
    setSelectedPaciente(null)
    setIsFormOpen(true)
  }

  const handleEditPaciente = (paciente: any) => {
    setSelectedPaciente(paciente)
    setIsFormOpen(true)
  }

  const handleSavePaciente = (pacienteData: any) => {
    let updatedPacientes

    if (pacienteData.id) {
      // Editar paciente existente
      updatedPacientes = pacientes.map((p) => (p.id === pacienteData.id ? pacienteData : p))
      toast({
        title: "Paciente atualizado",
        description: `Os dados de ${pacienteData.nome} foram atualizados com sucesso.`,
      })
    } else {
      // Adicionar novo paciente
      const newPaciente = {
        ...pacienteData,
        id: `paciente-${Date.now()}`,
      }
      updatedPacientes = [...pacientes, newPaciente]
      toast({
        title: "Paciente adicionado",
        description: `${pacienteData.nome} foi adicionado com sucesso.`,
      })
    }

    setPacientes(updatedPacientes)
    localStorage.setItem("pacientes", JSON.stringify(updatedPacientes))
    setIsFormOpen(false)

    // Disparar evento para notificar outros componentes
    window.dispatchEvent(new Event("pacientes-updated"))
  }

  const handleDeletePaciente = (pacienteId: string) => {
    const pacienteToDelete = pacientes.find((p) => p.id === pacienteId)
    if (!pacienteToDelete) return

    const updatedPacientes = pacientes.filter((p) => p.id !== pacienteId)
    setPacientes(updatedPacientes)
    localStorage.setItem("pacientes", JSON.stringify(updatedPacientes))

    toast({
      title: "Paciente removido",
      description: `${pacienteToDelete.nome} foi removido com sucesso.`,
    })

    // Disparar evento para notificar outros componentes
    window.dispatchEvent(new Event("pacientes-updated"))
  }

  return (
    <div className="container mx-auto p-4">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle>Pacientes</CardTitle>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar paciente..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button onClick={handleAddPaciente}>
                <Plus className="h-4 w-4 mr-2" />
                Novo Paciente
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="lista">
            <TabsList className="mb-4">
              <TabsTrigger value="lista">Lista de Pacientes</TabsTrigger>
              <TabsTrigger value="agenda">Agenda do Paciente</TabsTrigger>
            </TabsList>
            <TabsContent value="lista">
              <PacientesList
                pacientes={filteredPacientes}
                isLoading={isLoading}
                onEdit={handleEditPaciente}
                onDelete={handleDeletePaciente}
              />
            </TabsContent>
            <TabsContent value="agenda">
              {selectedPaciente ? (
                <AgendaSemanal pacienteId={selectedPaciente.id} readOnly />
              ) : (
                <div className="text-center p-8 text-muted-foreground">
                  Selecione um paciente para visualizar sua agenda
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {isFormOpen && (
        <PacienteForm paciente={selectedPaciente} onSave={handleSavePaciente} onCancel={() => setIsFormOpen(false)} />
      )}
    </div>
  )
}
