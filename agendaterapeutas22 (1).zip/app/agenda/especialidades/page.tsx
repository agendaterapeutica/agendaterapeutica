"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Pencil, Trash2 } from "lucide-react"
import { mockEspecialidades } from "@/lib/mock-data"

export default function EspecialidadesPage() {
  const [especialidades, setEspecialidades] = useState<string[]>([])
  const [novaEspecialidade, setNovaEspecialidade] = useState("")
  const [editandoIndex, setEditandoIndex] = useState<number | null>(null)
  const [especialidadeParaExcluir, setEspecialidadeParaExcluir] = useState<string | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const { toast } = useToast()

  // Carregar especialidades do localStorage
  useEffect(() => {
    try {
      const storedEspecialidades = localStorage.getItem("especialidades")
      if (storedEspecialidades) {
        setEspecialidades(JSON.parse(storedEspecialidades))
      } else {
        setEspecialidades(mockEspecialidades)
        localStorage.setItem("especialidades", JSON.stringify(mockEspecialidades))
      }
    } catch (error) {
      console.error("Erro ao carregar especialidades do localStorage:", error)
      setEspecialidades(mockEspecialidades)
    }
  }, [])

  const handleAddEspecialidade = () => {
    if (!novaEspecialidade.trim()) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "O nome da especialidade não pode estar vazio.",
      })
      return
    }

    if (especialidades.includes(novaEspecialidade)) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Esta especialidade já existe.",
      })
      return
    }

    if (editandoIndex !== null) {
      // Editando especialidade existente
      const novasEspecialidades = [...especialidades]
      novasEspecialidades[editandoIndex] = novaEspecialidade
      setEspecialidades(novasEspecialidades)
      setEditandoIndex(null)

      // Salvar no localStorage
      try {
        localStorage.setItem("especialidades", JSON.stringify(novasEspecialidades))
      } catch (error) {
        console.error("Erro ao salvar especialidades no localStorage:", error)
      }

      toast({
        title: "Especialidade atualizada",
        description: `A especialidade foi atualizada com sucesso.`,
      })
    } else {
      // Adicionando nova especialidade
      const novasEspecialidades = [...especialidades, novaEspecialidade]
      setEspecialidades(novasEspecialidades)

      // Salvar no localStorage
      try {
        localStorage.setItem("especialidades", JSON.stringify(novasEspecialidades))
      } catch (error) {
        console.error("Erro ao salvar especialidades no localStorage:", error)
      }

      toast({
        title: "Especialidade adicionada",
        description: `${novaEspecialidade} foi adicionada com sucesso.`,
      })
    }

    setNovaEspecialidade("")
  }

  const handleEditEspecialidade = (index: number) => {
    setNovaEspecialidade(especialidades[index])
    setEditandoIndex(index)
  }

  const handleDeleteEspecialidade = (especialidade: string) => {
    setEspecialidadeParaExcluir(especialidade)
    setIsDeleteDialogOpen(true)
  }

  const confirmDeleteEspecialidade = () => {
    if (!especialidadeParaExcluir) return

    const novasEspecialidades = especialidades.filter((e) => e !== especialidadeParaExcluir)
    setEspecialidades(novasEspecialidades)

    // Salvar no localStorage
    try {
      localStorage.setItem("especialidades", JSON.stringify(novasEspecialidades))
    } catch (error) {
      console.error("Erro ao salvar especialidades no localStorage:", error)
    }

    setIsDeleteDialogOpen(false)

    toast({
      title: "Especialidade removida",
      description: `${especialidadeParaExcluir} foi removida com sucesso.`,
    })
  }

  return (
    <>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Cadastro de Especialidades</h2>
          <p className="text-muted-foreground">Gerencie as especialidades dos terapeutas</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Adicionar Especialidade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                value={novaEspecialidade}
                onChange={(e) => setNovaEspecialidade(e.target.value)}
                placeholder="Nome da especialidade"
                className="flex-1"
              />
              <Button onClick={handleAddEspecialidade}>{editandoIndex !== null ? "Atualizar" : "Adicionar"}</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Especialidades</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {especialidades.length === 0 ? (
                <p className="text-muted-foreground">Nenhuma especialidade cadastrada.</p>
              ) : (
                especialidades.map((especialidade, index) => (
                  <div key={index} className="flex items-center justify-between rounded-lg border p-3">
                    <span>{especialidade}</span>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" onClick={() => handleEditEspecialidade(index)}>
                        <Pencil className="h-4 w-4" />
                        <span className="sr-only">Editar</span>
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDeleteEspecialidade(especialidade)}>
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Excluir</span>
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Diálogo de confirmação de exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta especialidade? Esta ação pode afetar os terapeutas que possuem esta
              especialidade.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteEspecialidade}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
