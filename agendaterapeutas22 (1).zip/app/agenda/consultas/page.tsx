"use client"

import type React from "react"

import { useState, useEffect, useCallback, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { UserCheck, Info, AlertCircle, Plus, Minus } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { mockPacientes, mockTerapeutas, mockEspecialidades } from "@/lib/mock-data"
import { useRouter } from "next/navigation"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

const diasSemana = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

export default function ConsultasPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("disponibilidade")

  // Estados para a consulta de disponibilidade
  const [pacientes, setPacientes] = useState<any[]>([])
  const [terapeutas, setTerapeutas] = useState<any[]>([])
  const [especialidades, setEspecialidades] = useState<string[]>([])
  const [agendamentos, setAgendamentos] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Estados para o filtro de consulta de disponibilidade
  const [selectedPaciente, setSelectedPaciente] = useState<string>("")
  const [selectedDia, setSelectedDia] = useState<string>("Segunda")
  const [selectedHorario, setSelectedHorario] = useState<string>("09:00")
  const [terapeutasDisponiveis, setTerapeutasDisponiveis] = useState<any[]>([])
  const [filtroEspecialidade, setFiltroEspecialidade] = useState<string>("")
  const [consultaRealizada, setConsultaRealizada] = useState(false)

  // Estados para o agendamento automático
  const [pacienteAutoAgendamento, setPacienteAutoAgendamento] = useState<string>("")
  const [diasSelecionados, setDiasSelecionados] = useState<string[]>([])
  const [horariosPreferidos, setHorariosPreferidos] = useState<string[]>([])
  const [especialidadesNecessarias, setEspecialidadesNecessarias] = useState<string[]>([])
  const [horasPorEspecialidade, setHorasPorEspecialidade] = useState<{ [key: string]: number }>({})
  const [horasDisponivelPaciente, setHorasDisponivelPaciente] = useState<number>(0)
  const [agendamentosSugeridos, setAgendamentosSugeridos] = useState<any[]>([])
  const [autoAgendamentoRealizado, setAutoAgendamentoRealizado] = useState(false)
  const [horariosDisponiveisList, setHorariosDisponiveisList] = useState<string[]>([])

  // Novos estados para melhorias no agendamento automático
  const [isProcessingAgendamento, setIsProcessingAgendamento] = useState(false)
  const [progressoAgendamento, setProgressoAgendamento] = useState(0)
  const [prioridadeTerapeuta, setPrioridadeTerapeuta] = useState<"experiencia" | "disponibilidade" | "balanceado">(
    "balanceado",
  )
  const [considerarDistancia, setConsiderarDistancia] = useState(true)
  const [maximizarDiasConsecutivos, setMaximizarDiasConsecutivos] = useState(true)
  const [agendamentosSelecionados, setAgendamentosSelecionados] = useState<string[]>([])
  const [filtroVisualizacao, setFiltroVisualizacao] = useState<"todos" | "dia" | "especialidade">("todos")
  const [evitarEspecialidadesConsecutivas, setEvitarEspecialidadesConsecutivas] = useState(true)

  // Estado para o modal de erro de agendamento
  const [showErrorModal, setShowErrorModal] = useState(false)
  const [errorModalMessage, setErrorModalMessage] = useState("")

  // Função para verificar se um horário está disponível para um terapeuta
  const verificarDisponibilidadeTerapeuta = useCallback(
    (terapeuta: any, dia: string, horario: string, especialidade: string) => {
      // Verificar se o terapeuta tem horários configurados por dia
      if (terapeuta.rangesPorDia && terapeuta.rangesPorDia[dia]) {
        const range = terapeuta.rangesPorDia[dia]

        // Verificar se o dia está ativo
        if (!range.ativo) return false

        // Verificar se o horário está dentro do range
        if (horario < range.inicio || horario > range.fim) return false

        // Verificar se o horário está bloqueado
        if (terapeuta.horariosBloqueados && terapeuta.horariosBloqueados[dia]) {
          if (terapeuta.horariosBloqueados[dia].includes(horario)) {
            return false
          }
        }
      } else {
        // Caso não tenha configuração específica, verificar horário geral
        if (horario < terapeuta.horarioInicio || horario > terapeuta.horarioFim) {
          return false
        }
      }

      // Verificar se já tem agendamento neste horário
      const temAgendamento = agendamentos.some(
        (agendamento) =>
          agendamento.terapeutaId === terapeuta.id && agendamento.dia === dia && agendamento.horario === horario,
      )

      // Check if we need to avoid consecutive appointments with the same specialty
      if (evitarEspecialidadesConsecutivas) {
        // Get the previous hour
        const [horaAtual, minutoAtual] = horario.split(":").map(Number)
        let horaAnterior = horaAtual - 1
        if (horaAnterior < 0) horaAnterior = 23
        const horarioAnterior = `${horaAnterior.toString().padStart(2, "0")}:${minutoAtual.toString().padStart(2, "0")}`

        // Check if there's an appointment in the previous hour with the same specialty
        const agendamentoAnterior = agendamentos.find(
          (a) => a.dia === dia && a.horario === horarioAnterior && a.terapeutaId === terapeuta.id,
        )

        if (agendamentoAnterior && agendamentoAnterior.especialidade === especialidade) {
          return false
        }

        // Get the next hour
        let horaPosterior = horaAtual + 1
        if (horaPosterior > 23) horaPosterior = 0
        const horarioPosterior = `${horaPosterior.toString().padStart(2, "0")}:${minutoAtual.toString().padStart(2, "0")}`

        // Check if there's an appointment in the next hour with the same specialty
        const agendamentoPosterior = agendamentos.find(
          (a) => a.dia === dia && a.horario === horarioPosterior && a.terapeutaId === terapeuta.id,
        )

        if (agendamentoPosterior && agendamentoPosterior.especialidade === especialidade) {
          return false
        }
      }

      return !temAgendamento
    },
    [agendamentos, evitarEspecialidadesConsecutivas],
  )

  // Vamos adicionar uma função auxiliar para verificar a disponibilidade do terapeuta
  // Adicione esta função logo após a função verificarDisponibilidadeTerapeuta existente

  // Função para verificar se um terapeuta está disponível em um horário específico (versão simplificada)
  const verificarDisponibilidadeTerapeutaSimples = useCallback(
    (terapeuta: any, dia: string, horario: string) => {
      // Verificar se o terapeuta tem horários configurados por dia
      if (terapeuta.rangesPorDia && terapeuta.rangesPorDia[dia]) {
        const range = terapeuta.rangesPorDia[dia]

        // Verificar se o dia está ativo
        if (!range.ativo) {
          return { disponivel: false, motivo: `O terapeuta não atende às ${dia}s` }
        }

        // Verificar se o horário está dentro do range
        if (horario < range.inicio || horario > range.fim) {
          return {
            disponivel: false,
            motivo: `O horário selecionado está fora do período de atendimento do terapeuta (${range.inicio} - ${range.fim})`,
          }
        }

        // Verificar se o horário está bloqueado
        if (terapeuta.horariosBloqueados && terapeuta.horariosBloqueados[dia]) {
          if (terapeuta.horariosBloqueados[dia].includes(horario)) {
            return { disponivel: false, motivo: "Este horário está bloqueado na agenda do terapeuta" }
          }
        }
      } else {
        // Caso não tenha configuração específica, verificar horário geral
        if (horario < terapeuta.horarioInicio || horario > terapeuta.horarioFim) {
          return {
            disponivel: false,
            motivo: `O horário selecionado está fora do período de atendimento do terapeuta (${terapeuta.horarioInicio} - ${terapeuta.horarioFim})`,
          }
        }
      }

      // Verificar se já tem agendamento neste horário
      const temAgendamento = agendamentos.some(
        (agendamento) =>
          agendamento.terapeutaId === terapeuta.id && agendamento.dia === dia && agendamento.horario === horario,
      )

      if (temAgendamento) {
        return { disponivel: false, motivo: "O terapeuta já possui um agendamento neste horário" }
      }

      return { disponivel: true, motivo: "" }
    },
    [agendamentos],
  )

  // Função para verificar se um paciente está disponível em um horário
  const verificarDisponibilidadePaciente = useCallback(
    (pacienteId: string, dia: string, horario: string) => {
      // Verificar se o paciente já tem agendamento neste horário
      return !agendamentos.some(
        (agendamento) =>
          (agendamento.pacienteId === pacienteId ||
            (agendamento.pacienteIds && agendamento.pacienteIds.includes(pacienteId))) &&
          agendamento.dia === dia &&
          agendamento.horario === horario,
      )
    },
    [agendamentos],
  )

  // Função para calcular a pontuação de um terapeuta para uma especialidade
  const calcularPontuacaoTerapeuta = useCallback(
    (terapeuta: any, especialidade: string) => {
      // Verificar se o terapeuta tem a especialidade
      if (!terapeuta.especialidades || !terapeuta.especialidades.includes(especialidade)) {
        return 0
      }

      // Base score
      let pontuacao = 10

      // Bônus por experiência (simulado pelo ID - em um sistema real seria baseado em anos de experiência)
      // Quanto menor o ID, mais "experiente" o terapeuta é considerado
      const idNumber = Number.parseInt(terapeuta.id.replace(/\D/g, ""))
      const experienciaBonus = Math.max(0, 5 - (idNumber % 5)) // 0-5 pontos de bônus

      // Bônus por disponibilidade (quantidade de dias disponíveis)
      let diasDisponiveisCount = 0
      if (terapeuta.rangesPorDia) {
        diasDisponiveisCount = Object.values(terapeuta.rangesPorDia).filter((range: any) => range.ativo).length
      }
      const disponibilidadeBonus = Math.min(5, diasDisponiveisCount)

      // Aplicar pesos conforme a prioridade selecionada
      switch (prioridadeTerapeuta) {
        case "experiencia":
          pontuacao += experienciaBonus * 3 + disponibilidadeBonus
          break
        case "disponibilidade":
          pontuacao += experienciaBonus + disponibilidadeBonus * 3
          break
        case "balanceado":
        default:
          pontuacao += experienciaBonus * 2 + disponibilidadeBonus * 2
          break
      }

      return pontuacao
    },
    [prioridadeTerapeuta],
  )

  // Função melhorada para realizar agendamento automático
  const realizarAgendamentoAutomatico = useCallback(() => {
    if (
      !pacienteAutoAgendamento ||
      diasSelecionados.length === 0 ||
      especialidadesNecessarias.length === 0 ||
      horasDisponivelPaciente <= 0
    ) {
      toast({
        variant: "destructive",
        title: "Informações incompletas",
        description:
          "Preencha todos os campos obrigatórios para realizar o agendamento automático, incluindo as horas disponíveis do paciente.",
      })
      return
    }

    setIsProcessingAgendamento(true)
    setProgressoAgendamento(0)

    // Usar setTimeout para não bloquear a UI
    setTimeout(() => {
      try {
        const sugestoes: any[] = []
        let horasAgendadasTotal = 0
        const horasMaximas = horasDisponivelPaciente

        // Verificar se o paciente existe
        const paciente = pacientes.find((p) => p.id === pacienteAutoAgendamento)
        if (!paciente) {
          throw new Error("Paciente não encontrado")
        }

        // Calcular o total de progresso para a barra de progresso
        setProgressoAgendamento(10)

        // Preparar estrutura para controlar horas agendadas por especialidade
        const horasAgendadasPorEspecialidade: Record<string, number> = {}
        especialidadesNecessarias.forEach((esp) => {
          horasAgendadasPorEspecialidade[esp] = 0
        })

        // Estrutura para armazenar os slots disponíveis por dia e horário
        type SlotDisponivel = {
          dia: string
          horario: string
          terapeutas: Array<{
            terapeuta: any
            especialidade: string
            pontuacao: number
          }>
        }

        const slotsDisponiveis: SlotDisponivel[] = []

        // Para cada dia e horário, encontrar terapeutas disponíveis para cada especialidade
        diasSelecionados.forEach((dia) => {
          const horariosAtendimento = horariosPreferidos.length > 0 ? horariosPreferidos : horariosDisponiveisList

          horariosAtendimento.forEach((horario) => {
            // Verificar se o paciente está disponível neste horário
            if (!verificarDisponibilidadePaciente(pacienteAutoAgendamento, dia, horario)) {
              return
            }

            const terapeutasDisponiveis: Array<{
              terapeuta: any
              especialidade: string
              pontuacao: number
            }> = []

            // Para cada especialidade, encontrar terapeutas disponíveis
            especialidadesNecessarias.forEach((especialidade) => {
              // Encontrar terapeutas com esta especialidade
              const terapeutasComEspecialidade = terapeutas
                .filter((terapeuta) => terapeuta.especialidades && terapeuta.especialidades.includes(especialidade))
                .map((terapeuta) => ({
                  terapeuta,
                  especialidade,
                  pontuacao: calcularPontuacaoTerapeuta(terapeuta, especialidade),
                }))
                .filter((item) => verificarDisponibilidadeTerapeuta(item.terapeuta, dia, horario, especialidade))
                .sort((a, b) => b.pontuacao - a.pontuacao)

              // Adicionar o melhor terapeuta para esta especialidade
              if (terapeutasComEspecialidade.length > 0) {
                terapeutasDisponiveis.push(terapeutasComEspecialidade[0])
              }
            })

            // Se houver terapeutas disponíveis para alguma especialidade neste slot
            if (terapeutasDisponiveis.length > 0) {
              slotsDisponiveis.push({
                dia,
                horario,
                terapeutas: terapeutasDisponiveis,
              })
            }
          })
        })

        setProgressoAgendamento(30)

        // Ordenar slots por dia da semana (se maximizarDiasConsecutivos estiver ativado)
        if (maximizarDiasConsecutivos) {
          slotsDisponiveis.sort((a, b) => {
            const indexA = diasSemana.indexOf(a.dia)
            const indexB = diasSemana.indexOf(b.dia)
            return indexA - indexB
          })
        }

        // Ordenar slots por horário dentro de cada dia
        slotsDisponiveis.sort((a, b) => {
          if (a.dia === b.dia) {
            return a.horario.localeCompare(b.horario)
          }
          return 0
        })

        setProgressoAgendamento(50)

        // Mapa para rastrear a última especialidade agendada por dia
        const ultimaEspecialidadePorDia: Record<string, { especialidade: string; horario: string }> = {}

        // Mapa para rastrear a última especialidade agendada globalmente
        let ultimaEspecialidadeGlobal: string | null = null
        let ultimoDiaAgendado: string | null = null

        // Função para verificar se uma especialidade pode ser agendada neste slot
        const podeAgendarEspecialidade = (dia: string, horario: string, especialidade: string): boolean => {
          // Se não estamos evitando especialidades consecutivas, sempre pode agendar
          if (!evitarEspecialidadesConsecutivas) return true

          // Verificar se é a mesma especialidade do último agendamento no mesmo dia
          if (ultimaEspecialidadePorDia[dia]) {
            const ultima = ultimaEspecialidadePorDia[dia]

            // Verificar se é o horário consecutivo
            const [horaUltima, minutoUltima] = ultima.horario.split(":").map(Number)
            const [horaAtual, minutoAtual] = horario.split(":").map(Number)

            // Se for o horário consecutivo (1 hora depois) e mesma especialidade, não permitir
            if (
              (horaUltima + 1) % 24 === horaAtual &&
              minutoUltima === minutoAtual &&
              ultima.especialidade === especialidade
            ) {
              return false
            }
          }

          // Se for o mesmo dia que o último agendamento global e mesma especialidade, tentar evitar
          if (
            ultimaEspecialidadeGlobal === especialidade &&
            ultimoDiaAgendado === dia &&
            especialidadesNecessarias.length > 1 // Só evitar se houver mais de uma especialidade
          ) {
            // Verificar se há outras especialidades disponíveis neste slot
            const outrasEspecialidades = slotsDisponiveis
              .find((s) => s.dia === dia && s.horario === horario)
              ?.terapeutas.filter((t) => t.especialidade !== especialidade)

            // Se houver outras especialidades disponíveis, evitar esta
            if (outrasEspecialidades && outrasEspecialidades.length > 0) {
              return false
            }
          }

          return true
        }

        // Agora, distribuir as especialidades pelos slots disponíveis
        let slotIndex = 0
        let todasEspecialidadesAtendidas = false

        // Continuar até que todas as especialidades tenham suas horas atendidas ou não haja mais slots
        while (
          !todasEspecialidadesAtendidas &&
          slotIndex < slotsDisponiveis.length &&
          horasAgendadasTotal < horasMaximas
        ) {
          const slot = slotsDisponiveis[slotIndex]
          let agendouNesseSlot = false

          // Ordenar especialidades por prioridade (menos horas agendadas primeiro)
          const especialidadesPriorizadas = [...especialidadesNecessarias].sort((a, b) => {
            const horasAgendadasA = horasAgendadasPorEspecialidade[a] || 0
            const horasAgendadasB = horasAgendadasPorEspecialidade[b] || 0
            const horasNecessariasA = horasPorEspecialidade[a] || 1
            const horasNecessariasB = horasPorEspecialidade[b] || 1

            // Calcular a proporção de horas agendadas vs. necessárias
            const proporcaoA = horasAgendadasA / horasNecessariasA
            const proporcaoB = horasAgendadasB / horasNecessariasB

            return proporcaoA - proporcaoB // Menor proporção primeiro
          })

          // Tentar agendar uma especialidade neste slot
          for (const especialidade of especialidadesPriorizadas) {
            // Verificar se já atingiu o número de horas necessárias para esta especialidade
            const horasNecessarias = horasPorEspecialidade[especialidade] || 1
            if (horasAgendadasPorEspecialidade[especialidade] >= horasNecessarias) {
              continue
            }

            // Verificar se pode agendar esta especialidade neste slot
            if (!podeAgendarEspecialidade(slot.dia, slot.horario, especialidade)) {
              continue
            }

            // Encontrar um terapeuta disponível para esta especialidade
            const terapeutaDisponivel = slot.terapeutas.find((t) => t.especialidade === especialidade)
            if (!terapeutaDisponivel) {
              continue
            }

            // Verificar se já existe sugestão para este horário
            const jaSugerido = sugestoes.some(
              (sugestao) => sugestao.dia === slot.dia && sugestao.horario === slot.horario,
            )

            if (jaSugerido) {
              continue
            }

            // Criar sugestão de agendamento
            sugestoes.push({
              id: `sugestao-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              pacienteId: pacienteAutoAgendamento,
              terapeutaId: terapeutaDisponivel.terapeuta.id,
              dia: slot.dia,
              horario: slot.horario,
              especialidade,
              nomeTerapeuta: terapeutaDisponivel.terapeuta.nome,
              fotoTerapeuta: terapeutaDisponivel.terapeuta.foto,
              pontuacaoTerapeuta: terapeutaDisponivel.pontuacao,
              tipo: "individual",
            })

            // Atualizar contadores
            horasAgendadasPorEspecialidade[especialidade]++
            horasAgendadasTotal++
            agendouNesseSlot = true

            // Atualizar última especialidade agendada
            ultimaEspecialidadePorDia[slot.dia] = {
              especialidade,
              horario: slot.horario,
            }
            ultimaEspecialidadeGlobal = especialidade
            ultimoDiaAgendado = slot.dia

            // Sair do loop de especialidades para este slot
            break
          }

          // Avançar para o próximo slot
          slotIndex++

          // Verificar se todas as especialidades têm suas horas atendidas
          todasEspecialidadesAtendidas = especialidadesNecessarias.every(
            (esp) => horasAgendadasPorEspecialidade[esp] >= (horasPorEspecialidade[esp] || 1),
          )

          // Atualizar progresso
          const percentualConcluido = Math.min(80, 50 + Math.floor((horasAgendadasTotal / horasMaximas) * 30))
          setProgressoAgendamento(percentualConcluido)
        }

        setProgressoAgendamento(90)

        // Ordenar sugestões por dia e horário para melhor visualização
        sugestoes.sort((a, b) => {
          const diaComparison = diasSemana.indexOf(a.dia) - diasSemana.indexOf(b.dia)
          if (diaComparison !== 0) return diaComparison
          return a.horario.localeCompare(b.horario)
        })

        setProgressoAgendamento(90)

        // Inicializar todos os agendamentos como selecionados
        setAgendamentosSelecionados(sugestoes.map((s) => s.id))

        setAgendamentosSugeridos(sugestoes)
        setAutoAgendamentoRealizado(true)

        // Verificar se alguma especialidade não teve todas as horas atendidas
        const especialidadesIncompletas = especialidadesNecessarias.filter(
          (esp) => horasAgendadasPorEspecialidade[esp] < (horasPorEspecialidade[esp] || 1),
        )

        if (especialidadesIncompletas.length > 0) {
          toast({
            variant: "warning",
            title: "Agendamento parcial",
            description: `Não foi possível agendar todas as horas necessárias para: ${especialidadesIncompletas.join(", ")}.`,
          })
        }

        if (sugestoes.length === 0) {
          toast({
            variant: "destructive",
            title: "Nenhum agendamento sugerido",
            description: "Não foi possível encontrar horários disponíveis para as especialidades selecionadas.",
          })
        } else {
          toast({
            title: "Sugestões de agendamento geradas",
            description: `Foram geradas ${sugestoes.length} sugestões de agendamento.`,
          })
        }
      } catch (error) {
        console.error("Erro ao realizar agendamento automático:", error)
        toast({
          variant: "destructive",
          title: "Erro no agendamento automático",
          description: "Ocorreu um erro ao gerar as sugestões de agendamento.",
        })
      } finally {
        setIsProcessingAgendamento(false)
        setProgressoAgendamento(100)
      }
    }, 100)
  }, [
    pacienteAutoAgendamento,
    diasSelecionados,
    especialidadesNecessarias,
    horasPorEspecialidade,
    horasDisponivelPaciente,
    horariosPreferidos,
    terapeutas,
    agendamentos,
    horariosDisponiveisList,
    pacientes,
    toast,
    calcularPontuacaoTerapeuta,
    verificarDisponibilidadePaciente,
    verificarDisponibilidadeTerapeuta,
    maximizarDiasConsecutivos,
    evitarEspecialidadesConsecutivas,
  ])

  // Atualizar horas por especialidade
  const atualizarHorasPorEspecialidade = (especialidade: string, horas: number) => {
    setHorasPorEspecialidade((prev) => ({
      ...prev,
      [especialidade]: horas,
    }))
  }

  // Função para incrementar horas de uma especialidade
  const incrementarHoras = (especialidade: string, e: React.MouseEvent) => {
    e.stopPropagation() // Impedir propagação do evento para o card
    const currentValue = horasPorEspecialidade[especialidade] || 1
    if (currentValue < 20) {
      atualizarHorasPorEspecialidade(especialidade, currentValue + 1)
    }
  }

  // Função para decrementar horas de uma especialidade
  const decrementarHoras = (especialidade: string, e: React.MouseEvent) => {
    e.stopPropagation() // Impedir propagação do evento para o card
    const currentValue = horasPorEspecialidade[especialidade] || 1
    if (currentValue > 1) {
      atualizarHorasPorEspecialidade(especialidade, currentValue - 1)
    }
  }

  // Função para selecionar/desselecionar uma especialidade
  const toggleEspecialidade = (especialidade: string) => {
    if (especialidadesNecessarias.includes(especialidade)) {
      setEspecialidadesNecessarias((prev) => prev.filter((e) => e !== especialidade))
      // Remover das horas por especialidade
      const novasHoras = { ...horasPorEspecialidade }
      delete novasHoras[especialidade]
      setHorasPorEspecialidade(novasHoras)
    } else {
      setEspecialidadesNecessarias((prev) => [...prev, especialidade])
      // Inicializar com 1 hora
      atualizarHorasPorEspecialidade(especialidade, 1)
    }
  }

  // Confirmar agendamentos sugeridos
  const confirmarAgendamentos = useCallback(() => {
    if (agendamentosSugeridos.length === 0 || agendamentosSelecionados.length === 0) {
      toast({
        variant: "destructive",
        title: "Nenhum agendamento para confirmar",
        description: "Não há sugestões de agendamento selecionadas para confirmar.",
      })
      return
    }

    try {
      // Obter agendamentos existentes
      const agendamentosExistentes = localStorage.getItem("agendamentos")
        ? JSON.parse(localStorage.getItem("agendamentos") || "[]")
        : []

      // Filtrar apenas os agendamentos selecionados
      const agendamentosFiltrados = agendamentosSugeridos.filter((sugestao) =>
        agendamentosSelecionados.includes(sugestao.id),
      )

      // Preparar novos agendamentos
      const novosAgendamentos = agendamentosFiltrados.map((sugestao) => ({
        id: `agendamento-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        pacienteId: sugestao.pacienteId,
        terapeutaId: sugestao.terapeutaId,
        dia: sugestao.dia,
        horario: sugestao.horario,
        tipo: "individual",
        especialidade: sugestao.especialidade, // Adicionar especialidade para referência
      }))

      // Combinar agendamentos existentes com novos
      const todosAgendamentos = [...agendamentosExistentes, ...novosAgendamentos]

      // Salvar no localStorage
      localStorage.setItem("agendamentos", JSON.stringify(todosAgendamentos))

      // Atualizar estado
      setAgendamentos(todosAgendamentos)

      // Limpar sugestões
      setAgendamentosSugeridos([])
      setAgendamentosSelecionados([])
      setAutoAgendamentoRealizado(false)

      toast({
        title: "Agendamentos confirmados",
        description: `${novosAgendamentos.length} agendamentos foram confirmados com sucesso.`,
      })

      // Disparar evento para notificar outros componentes
      window.dispatchEvent(
        new CustomEvent("agendamento-alterado", {
          detail: { action: "multiple-create" },
        }),
      )

      // Redirecionar para a página de agendamento com o terapeuta do primeiro agendamento
      if (novosAgendamentos.length > 0) {
        router.push(
          `/agenda?terapeuta=${novosAgendamentos[0].terapeutaId}&dia=${novosAgendamentos[0].dia}&horario=${novosAgendamentos[0].horario}&paciente=${novosAgendamentos[0].pacienteId}`,
        )
      }
    } catch (error) {
      console.error("Erro ao confirmar agendamentos:", error)
      toast({
        variant: "destructive",
        title: "Erro ao confirmar agendamentos",
        description: "Ocorreu um erro ao salvar os agendamentos sugeridos.",
      })
    }
  }, [agendamentosSugeridos, agendamentosSelecionados, toast, router])

  // Função para alternar a seleção de um agendamento
  const toggleAgendamentoSelecionado = (id: string) => {
    setAgendamentosSelecionados((prev) => {
      if (prev.includes(id)) {
        return prev.filter((item) => item !== id)
      } else {
        return [...prev, id]
      }
    })
  }

  // Função para selecionar/desselecionar todos os agendamentos
  const toggleSelecionarTodos = () => {
    if (agendamentosSelecionados.length === agendamentosSugeridos.length) {
      setAgendamentosSelecionados([])
    } else {
      setAgendamentosSelecionados(agendamentosSugeridos.map((s) => s.id))
    }
  }

  // Filtrar agendamentos sugeridos com base no filtro de visualização
  const agendamentosFiltrados = useMemo(() => {
    if (filtroVisualizacao === "todos") {
      return agendamentosSugeridos
    } else if (filtroVisualizacao === "dia") {
      // Agrupar por dia
      const agendamentosPorDia: Record<string, any[]> = {}
      diasSemana.forEach((dia) => {
        agendamentosPorDia[dia] = agendamentosSugeridos.filter((a) => a.dia === dia)
      })

      // Retornar apenas os dias com agendamentos
      return Object.entries(agendamentosPorDia)
        .filter(([_, agendamentos]) => agendamentos.length > 0)
        .flatMap(([_, agendamentos]) => agendamentos)
    } else if (filtroVisualizacao === "especialidade") {
      // Agrupar por especialidade
      const agendamentosPorEspecialidade: Record<string, any[]> = {}
      especialidadesNecessarias.forEach((esp) => {
        agendamentosPorEspecialidade[esp] = agendamentosSugeridos.filter((a) => a.especialidade === esp)
      })

      // Retornar apenas as especialidades com agendamentos
      return Object.entries(agendamentosPorEspecialidade)
        .filter(([_, agendamentos]) => agendamentos.length > 0)
        .flatMap(([_, agendamentos]) => agendamentos)
    }

    return agendamentosSugeridos
  }, [agendamentosSugeridos, filtroVisualizacao, diasSemana, especialidadesNecessarias])

  // Carregar dados iniciais
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)

        // Carregar pacientes
        const storedPacientes = localStorage.getItem("pacientes")
        if (storedPacientes) {
          setPacientes(JSON.parse(storedPacientes))
        } else {
          setPacientes(mockPacientes)
        }

        // Carregar terapeutas
        const storedTerapeutas = localStorage.getItem("terapeutas")
        if (storedTerapeutas) {
          setTerapeutas(JSON.parse(storedTerapeutas))
        } else {
          setTerapeutas(mockTerapeutas)
        }

        // Carregar especialidades com mecanismo de retry
        const loadEspecialidades = () => {
          const storedEspecialidades = localStorage.getItem("especialidades")
          if (storedEspecialidades) {
            try {
              const parsedEspecialidades = JSON.parse(storedEspecialidades)
              if (Array.isArray(parsedEspecialidades) && parsedEspecialidades.length > 0) {
                setEspecialidades(parsedEspecialidades)
                return true
              }
            } catch (e) {
              console.error("Erro ao processar especialidades:", e)
            }
          }
          return false
        }

        // Tentar carregar especialidades
        if (!loadEspecialidades()) {
          // Se falhar, tentar novamente após um breve atraso
          setTimeout(() => {
            if (!loadEspecialidades() && mockEspecialidades) {
              // Se ainda falhar, usar dados mockados
              setEspecialidades(mockEspecialidades)
            }
          }, 500)
        }

        // Carregar agendamentos
        const storedAgendamentos = localStorage.getItem("agendamentos")
        if (storedAgendamentos) {
          setAgendamentos(JSON.parse(storedAgendamentos))
        } else {
          setAgendamentos([])
        }

        // Carregar horários disponíveis da clínica
        const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
        const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

        // Gerar lista de horários entre início e fim
        const horarios = generateHorarios(clinicaHorarioInicio, clinicaHorarioFim)
        setHorariosDisponiveisList(horarios)

        // Definir horário padrão se estiver na lista
        if (horarios.length > 0) {
          setSelectedHorario(horarios[0])
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        toast({
          variant: "destructive",
          title: "Erro ao carregar dados",
          description: "Não foi possível carregar os dados necessários.",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [toast])

  // Função para gerar horários entre início e fim
  const generateHorarios = (inicio: string, fim: string) => {
    const horarios: string[] = []
    const [horaInicio, minutoInicio] = inicio.split(":").map(Number)
    const [horaFim, minutoFim] = fim.split(":").map(Number)

    let hora = horaInicio
    const minuto = minutoInicio

    // Loop para gerar horários
    while (hora < horaFim || (hora === horaFim && minuto <= minutoFim)) {
      horarios.push(`${hora.toString().padStart(2, "0")}:${minuto.toString().padStart(2, "0")}`)

      // Avançar 1 hora
      hora += 1

      // Ajustar se passar de 23h
      if (hora > 23) {
        hora = 0
      }
    }

    return horarios
  }

  // Verificar disponibilidade de terapeutas
  const verificarDisponibilidade = useCallback(() => {
    if (!selectedDia || !selectedHorario) {
      toast({
        variant: "destructive",
        title: "Seleção incompleta",
        description: "Selecione o dia e horário para verificar a disponibilidade.",
      })
      return
    }

    setIsLoading(true)

    try {
      // Filtrar terapeutas que estão disponíveis no dia e horário selecionados
      const terapeutasDisponiveis = terapeutas.filter((terapeuta) => {
        // Verificar se o terapeuta tem horários configurados por dia
        if (terapeuta.rangesPorDia && terapeuta.rangesPorDia[selectedDia]) {
          const range = terapeuta.rangesPorDia[selectedDia]

          // Verificar se o dia está ativo
          if (!range.ativo) return false

          // Verificar se o horário está dentro do range
          if (selectedHorario < range.inicio || selectedHorario > range.fim) return false

          // Verificar se o horário está bloqueado
          if (terapeuta.horariosBloqueados && terapeuta.horariosBloqueados[selectedDia]) {
            if (terapeuta.horariosBloqueados[selectedDia].includes(selectedHorario)) {
              return false
            }
          }

          // Verificar se já tem agendamento neste horário
          const temAgendamento = agendamentos.some(
            (agendamento) =>
              agendamento.terapeutaId === terapeuta.id &&
              agendamento.dia === selectedDia &&
              agendamento.horario === selectedHorario,
          )

          return !temAgendamento
        }

        // Caso não tenha configuração específica, verificar horário geral
        const tempoDisponivel = terapeuta.horarioInicio <= selectedHorario && terapeuta.horarioFim >= selectedHorario

        // Verificar se já tem agendamento neste horário
        const temAgendamento = agendamentos.some(
          (agendamento) =>
            agendamento.terapeutaId === terapeuta.id &&
            agendamento.dia === selectedDia &&
            agendamento.horario === selectedHorario,
        )

        return tempoDisponivel && !temAgendamento
      })

      // Se houver filtro de especialidade, aplicar
      let terapeutasFiltrados = terapeutasDisponiveis
      if (filtroEspecialidade && filtroEspecialidade !== "todas") {
        terapeutasFiltrados = terapeutasDisponiveis.filter(
          (terapeuta) => terapeuta.especialidades && terapeuta.especialidades.includes(filtroEspecialidade),
        )
      }

      setTerapeutasDisponiveis(terapeutasFiltrados)
      setConsultaRealizada(true)

      if (terapeutasFiltrados.length === 0) {
        toast({
          title: "Nenhum terapeuta disponível",
          description: "Não há terapeutas disponíveis para o dia e horário selecionados.",
          variant: "destructive",
        })
      } else {
        toast({
          title: "Consulta realizada com sucesso",
          description: `Foram encontrados ${terapeutasFiltrados.length} terapeutas disponíveis.`,
        })
      }
    } catch (error) {
      console.error("Erro ao verificar disponibilidade:", error)
      toast({
        variant: "destructive",
        title: "Erro na consulta",
        description: "Ocorreu um erro ao verificar a disponibilidade dos terapeutas.",
      })
    } finally {
      setIsLoading(false)
    }
  }, [selectedDia, selectedHorario, terapeutas, agendamentos, filtroEspecialidade, toast])

  // Função para criar agendamento diretamente e redirecionar para a agenda
  const criarAgendamento = useCallback(
    (terapeutaId: string) => {
      if (!selectedPaciente || selectedPaciente === "todos") {
        toast({
          variant: "destructive",
          title: "Paciente não selecionado",
          description: "Selecione um paciente para agendar a consulta.",
        })
        return
      }

      try {
        // Verificar se o terapeuta existe
        const terapeuta = terapeutas.find((t) => t.id === terapeutaId)
        if (!terapeuta) {
          toast({
            variant: "destructive",
            title: "Terapeuta não encontrado",
            description: "O terapeuta selecionado não está mais disponível.",
          })
          return
        }

        // Verificar se o paciente existe
        const paciente = pacientes.find((p) => p.id === selectedPaciente)
        if (!paciente) {
          toast({
            variant: "destructive",
            title: "Paciente não encontrado",
            description: "O paciente selecionado não está mais disponível.",
          })
          return
        }

        // Verificar se o paciente já tem agendamento neste horário
        const pacienteTemAgendamento = agendamentos.some(
          (agendamento) =>
            (agendamento.pacienteId === selectedPaciente ||
              (agendamento.pacienteIds && agendamento.pacienteIds.includes(selectedPaciente))) &&
            agendamento.dia === selectedDia &&
            agendamento.horario === selectedHorario,
        )

        if (pacienteTemAgendamento) {
          // Exibir o modal de erro
          setErrorModalMessage(
            `O paciente ${paciente.nome} já possui atendimento neste horário (${selectedDia} às ${selectedHorario}).`,
          )
          setShowErrorModal(true)

          // Também exibir o toast para consistência
          toast({
            variant: "destructive",
            title: "Não foi possível gerar o agendamento",
            description: `O paciente ${paciente.nome} já possui atendimento neste horário (${selectedDia} às ${selectedHorario}).`,
          })
          return
        }

        // Verificar se o terapeuta ainda está disponível neste horário
        const disponibilidade = verificarDisponibilidadeTerapeutaSimples(terapeuta, selectedDia, selectedHorario)
        if (!disponibilidade.disponivel) {
          toast({
            variant: "destructive",
            title: "Terapeuta indisponível",
            description: disponibilidade.motivo,
          })
          return
        }

        // Verificar se o horário está dentro do horário de funcionamento da clínica
        const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
        const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

        if (selectedHorario < clinicaHorarioInicio || selectedHorario > clinicaHorarioFim) {
          toast({
            variant: "destructive",
            title: "Horário fora do expediente",
            description: `A clínica funciona das ${clinicaHorarioInicio} às ${clinicaHorarioFim}.`,
          })
          return
        }

        // Obter agendamentos existentes
        const agendamentosExistentes = localStorage.getItem("agendamentos")
          ? JSON.parse(localStorage.getItem("agendamentos") || "[]")
          : []

        // Criar novo agendamento
        const novoAgendamento = {
          id: `agendamento-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          pacienteId: selectedPaciente,
          terapeutaId: terapeutaId,
          dia: selectedDia,
          horario: selectedHorario,
          tipo: "individual",
        }

        // Adicionar novo agendamento à lista
        const todosAgendamentos = [...agendamentosExistentes, novoAgendamento]

        // Salvar no localStorage
        localStorage.setItem("agendamentos", JSON.stringify(todosAgendamentos))

        // Atualizar estado
        setAgendamentos(todosAgendamentos)

        toast({
          title: "Agendamento criado com sucesso",
          description: `Consulta agendada para ${paciente.nome} com ${terapeuta.nome} em ${selectedDia} às ${selectedHorario}.`,
        })

        // Disparar evento para notificar outros componentes
        window.dispatchEvent(
          new CustomEvent("agendamento-alterado", {
            detail: { action: "create", id: novoAgendamento.id },
          }),
        )

        // Redirecionar para a página de agendamento com o terapeuta selecionado e informações adicionais
        router.push(
          `/agenda?terapeuta=${terapeutaId}&dia=${selectedDia}&horario=${selectedHorario}&paciente=${selectedPaciente}`,
        )
      } catch (error) {
        console.error("Erro ao criar agendamento:", error)
        toast({
          variant: "destructive",
          title: "Erro ao criar agendamento",
          description: "Ocorreu um erro inesperado ao tentar criar o agendamento. Tente novamente.",
        })
      }
    },
    [
      selectedPaciente,
      selectedDia,
      selectedHorario,
      agendamentos,
      toast,
      router,
      pacientes,
      terapeutas,
      verificarDisponibilidadeTerapeutaSimples,
    ],
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Consultas</h2>
          <p className="text-muted-foreground">Consulte disponibilidade e realize agendamentos automáticos</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="disponibilidade">Disponibilidade</TabsTrigger>
          <TabsTrigger value="agendamentoAutomatico">Agendamento Inteligente</TabsTrigger>
        </TabsList>

        {/* Consulta de Disponibilidade */}
        <TabsContent value="disponibilidade" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Consultar Disponibilidade de Terapeutas</CardTitle>
              <CardDescription>
                Selecione um dia e horário para verificar quais terapeutas estão disponíveis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="paciente">Paciente</Label>
                  <Select value={selectedPaciente} onValueChange={setSelectedPaciente}>
                    <SelectTrigger id="paciente">
                      <SelectValue placeholder="Selecione um paciente" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos os pacientes</SelectItem>
                      {pacientes.map((paciente) => (
                        <SelectItem key={paciente.id} value={paciente.id}>
                          {paciente.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dia">Dia da Semana</Label>
                  <Select value={selectedDia} onValueChange={setSelectedDia}>
                    <SelectTrigger id="dia">
                      <SelectValue placeholder="Selecione o dia" />
                    </SelectTrigger>
                    <SelectContent>
                      {diasSemana.map((dia) => (
                        <SelectItem key={dia} value={dia}>
                          {dia}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="horario">Horário</Label>
                  <Select value={selectedHorario} onValueChange={setSelectedHorario}>
                    <SelectTrigger id="horario">
                      <SelectValue placeholder="Selecione o horário" />
                    </SelectTrigger>
                    <SelectContent>
                      {horariosDisponiveisList.map((horario) => (
                        <SelectItem key={horario} value={horario}>
                          {horario}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="especialidade">Filtrar por Especialidade (opcional)</Label>
                <Select value={filtroEspecialidade} onValueChange={setFiltroEspecialidade}>
                  <SelectTrigger id="especialidade">
                    <SelectValue placeholder="Selecione uma especialidade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todas as especialidades</SelectItem>
                    {especialidades.map((especialidade) => (
                      <SelectItem key={especialidade} value={especialidade}>
                        {especialidade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={verificarDisponibilidade}
                disabled={isLoading}
                className="bg-agenda-blue hover:bg-agenda-blue-dark"
              >
                {isLoading ? "Consultando..." : "Consultar Disponibilidade"}
              </Button>
            </CardFooter>
          </Card>

          {consultaRealizada && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserCheck className="h-5 w-5 text-agenda-blue" />
                  Terapeutas Disponíveis
                </CardTitle>
                <CardDescription>
                  {terapeutasDisponiveis.length > 0
                    ? `${terapeutasDisponiveis.length} terapeutas disponíveis para ${selectedDia} às ${selectedHorario}`
                    : `Nenhum terapeuta disponível para ${selectedDia} às ${selectedHorario}`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {terapeutasDisponiveis.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {terapeutasDisponiveis.map((terapeuta) => (
                      <div key={terapeuta.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-12 w-12 border-2 border-agenda-blue-light">
                            <AvatarImage src={terapeuta.foto || "/placeholder.svg"} alt={terapeuta.nome} />
                            <AvatarFallback className="bg-agenda-blue text-white">
                              {terapeuta.nome.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-medium">{terapeuta.nome}</h3>
                            <p className="text-sm text-muted-foreground">{terapeuta.email}</p>
                          </div>
                        </div>

                        <div className="mt-3">
                          <p className="text-sm font-medium mb-1">Especialidades:</p>
                          <div className="flex flex-wrap gap-1">
                            {terapeuta.especialidades?.map((esp: string) => (
                              <Badge key={esp} variant="outline" className="bg-agenda-blue-light text-agenda-blue-dark">
                                {esp}
                              </Badge>
                            )) || (
                              <span className="text-sm text-muted-foreground">Nenhuma especialidade cadastrada</span>
                            )}
                          </div>
                        </div>

                        <div className="mt-2">
                          <p className="text-sm font-medium mb-1">Horário de atendimento:</p>
                          <p className="text-sm text-muted-foreground">
                            {terapeuta.rangesPorDia && terapeuta.rangesPorDia[selectedDia]
                              ? `${terapeuta.rangesPorDia[selectedDia].inicio} - ${terapeuta.rangesPorDia[selectedDia].fim}`
                              : `${terapeuta.horarioInicio} - ${terapeuta.horarioFim}`}
                          </p>
                        </div>

                        <div className="mt-3 pt-3 border-t">
                          <Button
                            variant="outline"
                            className="w-full border-agenda-blue text-agenda-blue hover:bg-agenda-blue-light"
                            onClick={() => criarAgendamento(terapeuta.id)}
                            disabled={!selectedPaciente || selectedPaciente === "todos"}
                          >
                            {!selectedPaciente || selectedPaciente === "todos"
                              ? "Selecione um paciente"
                              : "Agendar Consulta"}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-8 border rounded-lg bg-muted/20">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-lg font-medium">Nenhum terapeuta disponível</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Não há terapeutas disponíveis para {selectedDia} às {selectedHorario}
                      {filtroEspecialidade &&
                        filtroEspecialidade !== "todas" &&
                        ` com especialidade em ${filtroEspecialidade}`}
                      .
                    </p>
                    <p className="text-sm text-muted-foreground mt-3">
                      Tente selecionar outro horário ou dia da semana.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Agendamento Automático */}
        <TabsContent value="agendamentoAutomatico" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Agendamento Inteligente</CardTitle>
              <CardDescription>
                Configure os parâmetros para o sistema sugerir horários de atendimento automaticamente
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="paciente-auto">Paciente</Label>
                  <Select value={pacienteAutoAgendamento} onValueChange={setPacienteAutoAgendamento}>
                    <SelectTrigger id="paciente-auto">
                      <SelectValue placeholder="Selecione um paciente" />
                    </SelectTrigger>
                    <SelectContent>
                      {pacientes.map((paciente) => (
                        <SelectItem key={paciente.id} value={paciente.id}>
                          {paciente.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="horas-disponiveis">Horas Disponíveis do Paciente</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="horas-disponiveis"
                      type="number"
                      min="1"
                      max="20"
                      value={horasDisponivelPaciente || ""}
                      onChange={(e) => setHorasDisponivelPaciente(Number(e.target.value))}
                      placeholder="Quantidade de horas"
                      className="max-w-[200px]"
                    />
                    <span className="text-sm text-muted-foreground">horas por semana</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Informe quantas horas o paciente tem disponíveis para atendimento
                  </p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Dias Disponíveis</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 mt-1">
                    {diasSemana.map((dia) => (
                      <div key={dia} className="flex items-center space-x-2">
                        <Checkbox
                          id={`dia-${dia}`}
                          checked={diasSelecionados.includes(dia)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setDiasSelecionados((prev) => [...prev, dia])
                            } else {
                              setDiasSelecionados((prev) => prev.filter((d) => d !== dia))
                            }
                          }}
                        />
                        <Label htmlFor={`dia-${dia}`} className="cursor-pointer">
                          {dia}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Horários Preferidos (opcional)</Label>
                  <p className="text-sm text-muted-foreground mb-2">
                    Se nenhum horário for selecionado, o sistema considerará todos os horários disponíveis.
                  </p>
                  <ScrollArea className="h-40 border rounded-md p-2">
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                      {horariosDisponiveisList.map((horario) => (
                        <div key={horario} className="flex items-center space-x-2">
                          <Checkbox
                            id={`horario-${horario}`}
                            checked={horariosPreferidos.includes(horario)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setHorariosPreferidos((prev) => [...prev, horario])
                              } else {
                                setHorariosPreferidos((prev) => prev.filter((h) => h !== horario))
                              }
                            }}
                          />
                          <Label htmlFor={`horario-${horario}`} className="cursor-pointer">
                            {horario}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Especialidades Necessárias</Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEspecialidadesNecessarias([])
                        setHorasPorEspecialidade({})
                      }}
                      disabled={especialidadesNecessarias.length === 0}
                    >
                      Limpar seleção
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {especialidades.map((especialidade) => (
                      <div
                        key={especialidade}
                        className={`border rounded-lg p-3 transition-colors ${
                          especialidadesNecessarias.includes(especialidade)
                            ? "bg-agenda-blue-light border-agenda-blue"
                            : "hover:bg-muted/20"
                        }`}
                        onClick={() => toggleEspecialidade(especialidade)}
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-medium">{especialidade}</span>
                          {especialidadesNecessarias.includes(especialidade) && (
                            <Badge variant="outline" className="bg-agenda-blue text-white">
                              Selecionada
                            </Badge>
                          )}
                        </div>

                        {especialidadesNecessarias.includes(especialidade) && (
                          <div className="mt-3 pt-2 border-t">
                            <div className="flex items-center gap-2">
                              <Label htmlFor={`horas-${especialidade}`} className="whitespace-nowrap">
                                Horas:
                              </Label>
                              <div className="flex items-center h-10 border rounded-md overflow-hidden">
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-full w-10 rounded-none border-r"
                                  onClick={(e) => decrementarHoras(especialidade, e)}
                                  disabled={(horasPorEspecialidade[especialidade] || 1) <= 1}
                                >
                                  <span className="sr-only">Diminuir</span>
                                  <Minus className="h-4 w-4" />
                                </Button>
                                <div className="flex items-center justify-center min-w-[40px] px-2 text-center">
                                  <span className="font-medium">{horasPorEspecialidade[especialidade] || 1}</span>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-full w-10 rounded-none border-l"
                                  onClick={(e) => incrementarHoras(especialidade, e)}
                                  disabled={(horasPorEspecialidade[especialidade] || 1) >= 20}
                                >
                                  <span className="sr-only">Aumentar</span>
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {(horasPorEspecialidade[especialidade] || 1) === 1 ? "hora" : "horas"}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Configurações avançadas */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-medium">Configurações Avançadas</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <Info className="h-4 w-4" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-80">
                        <div className="space-y-2">
                          <h4 className="font-medium">Sobre as configurações avançadas</h4>
                          <p className="text-sm text-muted-foreground">
                            Estas configurações permitem ajustar como o sistema prioriza terapeutas e organiza os
                            agendamentos.
                          </p>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-4 rounded-md border p-4">
                    <div className="space-y-2">
                      <Label>Prioridade na seleção de terapeutas</Label>
                      <RadioGroup
                        value={prioridadeTerapeuta}
                        onValueChange={(value: "experiencia" | "disponibilidade" | "balanceado") =>
                          setPrioridadeTerapeuta(value)
                        }
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="experiencia" id="experiencia" />
                          <Label htmlFor="experiencia">Priorizar por experiência</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="disponibilidade" id="disponibilidade" />
                          <Label htmlFor="disponibilidade">Priorizar por disponibilidade</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="balanceado" id="balanceado" />
                          <Label htmlFor="balanceado">Balanceado (recomendado)</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="maximizar-dias-consecutivos"
                          checked={maximizarDiasConsecutivos}
                          onCheckedChange={(checked) => setMaximizarDiasConsecutivos(!!checked)}
                        />
                        <Label htmlFor="maximizar-dias-consecutivos">Maximizar dias consecutivos</Label>
                      </div>
                      <p className="text-xs text-muted-foreground ml-6">
                        Tenta agendar consultas em dias consecutivos quando possível
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="evitar-especialidades-consecutivas"
                          checked={evitarEspecialidadesConsecutivas}
                          onCheckedChange={(checked) => setEvitarEspecialidadesConsecutivas(!!checked)}
                        />
                        <Label htmlFor="evitar-especialidades-consecutivas">Evitar especialidades consecutivas</Label>
                      </div>
                      <p className="text-xs text-muted-foreground ml-6">
                        Evita agendar a mesma especialidade em horários consecutivos
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="considerar-distancia"
                          checked={considerarDistancia}
                          onCheckedChange={(checked) => setConsiderarDistancia(!!checked)}
                        />
                        <Label htmlFor="considerar-distancia">Considerar distância entre terapeutas</Label>
                      </div>
                      <p className="text-xs text-muted-foreground ml-6">
                        Tenta minimizar a distância entre salas de atendimento consecutivas
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab("disponibilidade")}>
                Voltar
              </Button>
              <Button
                onClick={realizarAgendamentoAutomatico}
                disabled={isProcessingAgendamento}
                className="bg-agenda-blue hover:bg-agenda-blue-dark"
              >
                {isProcessingAgendamento ? "Processando..." : "Gerar Sugestões de Agendamento"}
              </Button>
            </CardFooter>
          </Card>

          {autoAgendamentoRealizado && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserCheck className="h-5 w-5 text-agenda-blue" />
                  Sugestões de Agendamento
                </CardTitle>
                <CardDescription>
                  {agendamentosSugeridos.length > 0
                    ? `${agendamentosSugeridos.length} sugestões de agendamento para ${
                        pacientes.find((p) => p.id === pacienteAutoAgendamento)?.nome || "o paciente"
                      }`
                    : "Nenhuma sugestão de agendamento encontrada"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {agendamentosSugeridos.length > 0 ? (
                  <div className="space-y-4">
                    <div className="flex flex-wrap gap-2 justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="selecionar-todos"
                          checked={agendamentosSelecionados.length === agendamentosSugeridos.length}
                          onCheckedChange={toggleSelecionarTodos}
                        />
                        <Label htmlFor="selecionar-todos">Selecionar todos</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Label htmlFor="filtro-visualizacao" className="text-sm">
                          Visualizar por:
                        </Label>
                        <Select
                          value={filtroVisualizacao}
                          onValueChange={(value: "todos" | "dia" | "especialidade") => setFiltroVisualizacao(value)}
                        >
                          <SelectTrigger id="filtro-visualizacao" className="h-8 w-[140px]">
                            <SelectValue placeholder="Visualização" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="todos">Todos</SelectItem>
                            <SelectItem value="dia">Por dia</SelectItem>
                            <SelectItem value="especialidade">Por especialidade</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3">
                      {filtroVisualizacao === "dia" && (
                        <div className="space-y-4">
                          {diasSemana
                            .filter((dia) => agendamentosSugeridos.some((a) => a.dia === dia))
                            .map((dia) => (
                              <div key={dia} className="space-y-2">
                                <h3 className="font-medium text-lg">{dia}</h3>
                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                  {agendamentosSugeridos
                                    .filter((a) => a.dia === dia)
                                    .map((agendamento) => (
                                      <div
                                        key={agendamento.id}
                                        className={`border rounded-lg p-3 transition-colors ${
                                          agendamentosSelecionados.includes(agendamento.id)
                                            ? "bg-agenda-blue-light border-agenda-blue"
                                            : ""
                                        }`}
                                      >
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-2">
                                            <Checkbox
                                              id={`agendamento-${agendamento.id}`}
                                              checked={agendamentosSelecionados.includes(agendamento.id)}
                                              onCheckedChange={() => toggleAgendamentoSelecionado(agendamento.id)}
                                            />
                                            <span className="font-medium">{agendamento.horario}</span>
                                          </div>
                                          <Badge variant="outline">{agendamento.especialidade}</Badge>
                                        </div>
                                        <div className="mt-2 flex items-center gap-2">
                                          <Avatar className="h-8 w-8">
                                            <AvatarImage
                                              src={agendamento.fotoTerapeuta || "/placeholder.svg"}
                                              alt={agendamento.nomeTerapeuta}
                                            />
                                            <AvatarFallback>
                                              {agendamento.nomeTerapeuta.substring(0, 2).toUpperCase()}
                                            </AvatarFallback>
                                          </Avatar>
                                          <span className="text-sm">{agendamento.nomeTerapeuta}</span>
                                        </div>
                                      </div>
                                    ))}
                                </div>
                              </div>
                            ))}
                        </div>
                      )}

                      {filtroVisualizacao === "especialidade" && (
                        <div className="space-y-4">
                          {especialidadesNecessarias
                            .filter((esp) => agendamentosSugeridos.some((a) => a.especialidade === esp))
                            .map((especialidade) => (
                              <div key={especialidade} className="space-y-2">
                                <h3 className="font-medium text-lg">{especialidade}</h3>
                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                                  {agendamentosSugeridos
                                    .filter((a) => a.especialidade === especialidade)
                                    .map((agendamento) => (
                                      <div
                                        key={agendamento.id}
                                        className={`border rounded-lg p-3 transition-colors ${
                                          agendamentosSelecionados.includes(agendamento.id)
                                            ? "bg-agenda-blue-light border-agenda-blue"
                                            : ""
                                        }`}
                                      >
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-2">
                                            <Checkbox
                                              id={`agendamento-${agendamento.id}`}
                                              checked={agendamentosSelecionados.includes(agendamento.id)}
                                              onCheckedChange={() => toggleAgendamentoSelecionado(agendamento.id)}
                                            />
                                            <span className="font-medium">{agendamento.dia}</span>
                                          </div>
                                          <span>{agendamento.horario}</span>
                                        </div>
                                        <div className="mt-2 flex items-center gap-2">
                                          <Avatar className="h-8 w-8">
                                            <AvatarImage
                                              src={agendamento.fotoTerapeuta || "/placeholder.svg"}
                                              alt={agendamento.nomeTerapeuta}
                                            />
                                            <AvatarFallback>
                                              {agendamento.nomeTerapeuta.substring(0, 2).toUpperCase()}
                                            </AvatarFallback>
                                          </Avatar>
                                          <span className="text-sm">{agendamento.nomeTerapeuta}</span>
                                        </div>
                                      </div>
                                    ))}
                                </div>
                              </div>
                            ))}
                        </div>
                      )}

                      {filtroVisualizacao === "todos" && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                          {agendamentosFiltrados.map((agendamento) => (
                            <div
                              key={agendamento.id}
                              className={`border rounded-lg p-3 transition-colors ${
                                agendamentosSelecionados.includes(agendamento.id)
                                  ? "bg-agenda-blue-light border-agenda-blue"
                                  : ""
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <Checkbox
                                    id={`agendamento-${agendamento.id}`}
                                    checked={agendamentosSelecionados.includes(agendamento.id)}
                                    onCheckedChange={() => toggleAgendamentoSelecionado(agendamento.id)}
                                  />
                                  <span className="font-medium">
                                    {agendamento.dia} - {agendamento.horario}
                                  </span>
                                </div>
                                <Badge variant="outline">{agendamento.especialidade}</Badge>
                              </div>
                              <div className="mt-2 flex items-center gap-2">
                                <Avatar className="h-8 w-8">
                                  <AvatarImage
                                    src={agendamento.fotoTerapeuta || "/placeholder.svg"}
                                    alt={agendamento.nomeTerapeuta}
                                  />
                                  <AvatarFallback>
                                    {agendamento.nomeTerapeuta.substring(0, 2).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-sm">{agendamento.nomeTerapeuta}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 border rounded-lg bg-muted/20">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-lg font-medium">Nenhuma sugestão de agendamento</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Não foi possível encontrar horários disponíveis para as especialidades selecionadas.
                    </p>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => {
                    setAgendamentosSugeridos([])
                    setAgendamentosSelecionados([])
                    setAutoAgendamentoRealizado(false)
                  }}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={confirmarAgendamentos}
                  disabled={agendamentosSelecionados.length === 0}
                  className="bg-agenda-blue hover:bg-agenda-blue-dark"
                >
                  Confirmar Agendamentos ({agendamentosSelecionados.length})
                </Button>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Modal de erro de agendamento */}
      <Dialog open={showErrorModal} onOpenChange={setShowErrorModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-destructive">Agendamento não realizado</DialogTitle>
            <DialogDescription>{errorModalMessage}</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end mt-4">
            <Button variant="outline" onClick={() => setShowErrorModal(false)}>
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
