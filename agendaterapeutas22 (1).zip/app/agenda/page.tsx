"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AgendaSemanal } from "@/components/agenda-semanal"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/components/auth-provider"
import { mockTerapeutas } from "@/lib/mock-data"
import { useSearchParams } from "next/navigation"

export default function AgendamentoPage() {
  const [selectedTerapeuta, setSelectedTerapeuta] = useState<string | null>(null)
  const [terapeutas, setTerapeutas] = useState<any[]>([])
  const [terapeutasFiltrados, setTerapeutasFiltrados] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const dataLoadedRef = useRef(false)
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { isAdmin, user } = useAuth()
  const terapeutaFromUrlProcessed = useRef(false)
  const firstLoadChecked = useRef(false)

  // Verificar se precisa de refresh na primeira carga
  useEffect(() => {
    if (firstLoadChecked.current) return
    firstLoadChecked.current = true

    const needsFirstLoadRefresh = localStorage.getItem("needsFirstLoadRefresh") === "true"
    if (needsFirstLoadRefresh) {
      // Limpar o flag
      localStorage.removeItem("needsFirstLoadRefresh")

      // Mostrar indicador de carregamento
      setIsRefreshing(true)

      // Forçar refresh completo após um pequeno delay
      setTimeout(() => {
        window.location.reload()
      }, 500)
    }
  }, [])

  // Carregar terapeutas do localStorage
  useEffect(() => {
    if (dataLoadedRef.current || isRefreshing) return

    // Se o email do usuário ainda não estiver disponível, não carregue os dados ainda
    if (!user.email) return

    const loadData = () => {
      try {
        const storedTerapeutas = localStorage.getItem("terapeutas")
        if (storedTerapeutas) {
          const todosTerapeutas = JSON.parse(storedTerapeutas)
          setTerapeutas(todosTerapeutas)

          // Verificar configuração de visibilidade
          const mostrarTodos = localStorage.getItem("mostrarTodosTerapeutas") !== "false"

          // Se for admin, mostrar todos os terapeutas independentemente da configuração
          if (isAdmin) {
            setTerapeutasFiltrados(todosTerapeutas)
          }
          // Se for funcionário, verificar a configuração
          else {
            // Se a configuração permitir mostrar todos, mostrar todos
            if (mostrarTodos) {
              setTerapeutasFiltrados(todosTerapeutas)
            }
            // Caso contrário, mostrar apenas o terapeuta logado
            else {
              const terapeutaLogado = todosTerapeutas.find((t: any) => t.email === user.email)
              setTerapeutasFiltrados(terapeutaLogado ? [terapeutaLogado] : [])

              // Se encontrou o terapeuta logado, já seleciona ele automaticamente
              if (terapeutaLogado) {
                setSelectedTerapeuta(terapeutaLogado.id)
              }
            }
          }
        }
      } catch (error) {
        console.error("Erro ao carregar terapeutas do localStorage:", error)
        setTerapeutas(mockTerapeutas)
        setTerapeutasFiltrados(isAdmin ? mockTerapeutas : [])
      } finally {
        setIsLoading(false)
        dataLoadedRef.current = true
      }
    }

    // Usar setTimeout para evitar o erro flushSync
    setTimeout(loadData, 0)
  }, [isAdmin, user.email, isRefreshing])

  // Resetar o estado quando o usuário mudar
  useEffect(() => {
    if (user.email) {
      // Resetar o flag para permitir recarregar os dados quando o usuário mudar
      dataLoadedRef.current = false
      // Forçar nova verificação
      setIsLoading(true)
    }
  }, [user.email])

  // Verificar parâmetros da URL (da página de consultas)
  useEffect(() => {
    // Verificar se já processamos o parâmetro da URL
    if (terapeutaFromUrlProcessed.current) return

    // Verificar se os dados já foram carregados
    if (!dataLoadedRef.current || terapeutasFiltrados.length === 0) return

    const terapeuta = searchParams.get("terapeuta")
    const dia = searchParams.get("dia")
    const horario = searchParams.get("horario")
    const paciente = searchParams.get("paciente")

    // Se tiver o parâmetro terapeuta na URL
    if (terapeuta) {
      // Verificar se o terapeuta está disponível para o usuário
      const terapeutaDisponivel = terapeutasFiltrados.find((t) => t.id === terapeuta)

      if (terapeutaDisponivel) {
        // Selecionar o terapeuta
        setSelectedTerapeuta(terapeuta)

        // Marcar como processado para não repetir
        terapeutaFromUrlProcessed.current = true

        // Mostrar mensagem de confirmação
        toast({
          title: "Terapeuta selecionado",
          description: `Visualizando agenda de ${terapeutaDisponivel.nome}`,
        })

        // Se tiver dia e horário, focar na célula correspondente
        if (dia && horario) {
          // Aguardar um pouco para garantir que a AgendaSemanal esteja montada
          setTimeout(() => {
            // Enviar evento personalizado para focalizar na célula correta
            // Adicionando o parâmetro apenasDestaque para evitar abrir o pop-up
            window.dispatchEvent(
              new CustomEvent("focar-celula", {
                detail: { dia, horario, paciente, apenasDestaque: true },
              }),
            )

            toast({
              title: "Agendamento realizado",
              description: `Consulta agendada para ${dia} às ${horario}.`,
            })
          }, 500)
        }
      }
    }
  }, [searchParams, terapeutasFiltrados, toast])

  // Atualizar quando a configuração de visibilidade mudar
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "mostrarTodosTerapeutas") {
        // Recarregar a página para aplicar a nova configuração
        window.location.reload()
      }
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  const handleTerapeutaChange = (value: string) => {
    setSelectedTerapeuta(value)
    toast({
      title: "Terapeuta selecionado",
      description: `Visualizando agenda de ${terapeutas.find((t) => t.id === value)?.nome}`,
    })
  }

  const terapeuta = terapeutas.find((t) => t.id === selectedTerapeuta)

  // Mostrar indicador de carregamento durante o refresh
  if (isRefreshing) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="h-16 w-16 animate-spin rounded-full border-4 border-blue-500 border-t-transparent mx-auto"></div>
          <p className="mt-4 text-lg">Carregando sistema...</p>
          <p className="text-sm text-muted-foreground">Aguarde enquanto preparamos tudo para você</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Agendamento</h2>
          <p className="text-muted-foreground">Gerencie os agendamentos dos terapeutas e pacientes</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Selecione um Terapeuta</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-16">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
            </div>
          ) : (
            <div className="grid gap-6">
              {terapeutasFiltrados.length > 1 ? (
                <Select onValueChange={handleTerapeutaChange} value={selectedTerapeuta || undefined}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecione um terapeuta" />
                  </SelectTrigger>
                  <SelectContent>
                    {terapeutasFiltrados.map((terapeuta) => (
                      <SelectItem key={terapeuta.id} value={terapeuta.id}>
                        {terapeuta.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : terapeutasFiltrados.length === 1 ? (
                <div className="text-sm text-muted-foreground">
                  Visualizando agenda do terapeuta: <span className="font-medium">{terapeutasFiltrados[0].nome}</span>
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">Nenhum terapeuta disponível para visualização.</div>
              )}

              {terapeuta && (
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={terapeuta.foto || "/placeholder.svg"} alt={terapeuta.nome} />
                    <AvatarFallback>{terapeuta.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-lg font-medium">{terapeuta.nome}</h3>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {terapeuta.especialidades &&
                        terapeuta.especialidades.map((especialidade: string) => (
                          <Badge key={especialidade} variant="secondary">
                            {especialidade}
                          </Badge>
                        ))}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      Horário de trabalho: {terapeuta.horarioInicio} às {terapeuta.horarioFim}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedTerapeuta && !isLoading && <AgendaSemanal terapeutaId={selectedTerapeuta} readOnly={!isAdmin} />}
    </div>
  )
}
