"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Download, Upload, AlertTriangle, ImageIcon, Clock, Building } from "lucide-react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Switch } from "@/components/ui/switch"

// Adicionar os horários disponíveis como constante
const horariosDisponiveis = [
  "00:00",
  "01:00",
  "02:00",
  "03:00",
  "04:00",
  "05:00",
  "06:00",
  "07:00",
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
  "22:00",
  "23:00",
]

export default function ConfiguracoesPage() {
  const [isRestoreDialogOpen, setIsRestoreDialogOpen] = useState(false)
  const [backupFile, setBackupFile] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const logoFileInputRef = useRef<HTMLInputElement>(null)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const [nomeEmpresa, setNomeEmpresa] = useState("Agenda de Terapeutas")
  const [horarioInicio, setHorarioInicio] = useState("08:00")
  const [horarioFim, setHorarioFim] = useState("18:00")
  const { toast } = useToast()

  // Carregar configurações salvas ao iniciar
  useEffect(() => {
    try {
      // Carregar logo
      const savedLogo = localStorage.getItem("logoInstitucional")
      if (savedLogo) {
        setLogoPreview(savedLogo)
      }

      // Carregar nome da empresa
      const savedNomeEmpresa = localStorage.getItem("nomeEmpresa")
      if (savedNomeEmpresa) {
        setNomeEmpresa(savedNomeEmpresa)
      }

      // Carregar horários
      const savedHorarioInicio = localStorage.getItem("clinicaHorarioInicio")
      const savedHorarioFim = localStorage.getItem("clinicaHorarioFim")

      if (savedHorarioInicio) {
        setHorarioInicio(savedHorarioInicio)
      }

      if (savedHorarioFim) {
        setHorarioFim(savedHorarioFim)
      }
    } catch (error) {
      console.error("Erro ao carregar configurações:", error)
    }
  }, [])

  // Função para selecionar arquivo de logo
  const handleSelectLogoFile = () => {
    logoFileInputRef.current?.click()
  }

  // Função para processar arquivo de logo selecionado
  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Verificar tipo de arquivo
    if (!file.type.startsWith("image/")) {
      toast({
        variant: "destructive",
        title: "Tipo de arquivo inválido",
        description: "Por favor, selecione uma imagem (JPG, PNG, etc).",
      })
      return
    }

    // Verificar tamanho do arquivo (limitar a 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: "Arquivo muito grande",
        description: "A imagem deve ter no máximo 2MB.",
      })
      return
    }

    // Converter para base64
    const reader = new FileReader()
    reader.onload = (event) => {
      if (event.target?.result) {
        const base64String = event.target.result.toString()
        setLogoPreview(base64String)

        // Salvar no localStorage
        try {
          localStorage.setItem("logoInstitucional", base64String)
          toast({
            title: "Imagem salva com sucesso",
            description: "A imagem institucional foi atualizada.",
          })
        } catch (error) {
          console.error("Erro ao salvar imagem:", error)
          toast({
            variant: "destructive",
            title: "Erro ao salvar imagem",
            description: "Não foi possível salvar a imagem. Tente uma imagem menor.",
          })
        }
      }
    }
    reader.readAsDataURL(file)
  }

  // Função para salvar nome da empresa
  const handleSaveNomeEmpresa = () => {
    try {
      localStorage.setItem("nomeEmpresa", nomeEmpresa)

      toast({
        title: "Nome da empresa salvo com sucesso",
        description: "O nome da empresa foi atualizado.",
      })
    } catch (error) {
      console.error("Erro ao salvar nome da empresa:", error)
      toast({
        variant: "destructive",
        title: "Erro ao salvar nome da empresa",
        description: "Não foi possível salvar o nome da empresa.",
      })
    }
  }

  // Função para salvar horários da clínica
  const handleSaveHorarios = () => {
    try {
      localStorage.setItem("clinicaHorarioInicio", horarioInicio)
      localStorage.setItem("clinicaHorarioFim", horarioFim)

      toast({
        title: "Horários salvos com sucesso",
        description: "Os horários de funcionamento da clínica foram atualizados.",
      })
    } catch (error) {
      console.error("Erro ao salvar horários:", error)
      toast({
        variant: "destructive",
        title: "Erro ao salvar horários",
        description: "Não foi possível salvar os horários de funcionamento.",
      })
    }
  }

  // Função para criar backup
  const handleCreateBackup = () => {
    try {
      setIsLoading(true)

      // Coletar todos os dados do localStorage
      const backupData = {
        terapeutas: JSON.parse(localStorage.getItem("terapeutas") || "[]"),
        pacientes: JSON.parse(localStorage.getItem("pacientes") || "[]"),
        agendamentos: JSON.parse(localStorage.getItem("agendamentos") || "[]"),
        especialidades: JSON.parse(localStorage.getItem("especialidades") || "[]"),
        logoInstitucional: localStorage.getItem("logoInstitucional") || null,
        nomeEmpresa: localStorage.getItem("nomeEmpresa") || "Agenda de Terapeutas",
        clinicaHorarioInicio: localStorage.getItem("clinicaHorarioInicio") || "08:00",
        clinicaHorarioFim: localStorage.getItem("clinicaHorarioFim") || "18:00",
        timestamp: new Date().toISOString(),
        version: "2.2", // Atualizar versão para incluir novas configurações
      }

      // Converter para JSON
      const backupJson = JSON.stringify(backupData, null, 2) // Formatado para legibilidade

      // Criar blob e link para download
      const blob = new Blob([backupJson], { type: "application/json" })
      const url = URL.createObjectURL(blob)

      // Criar elemento de link para download
      const a = document.createElement("a")
      a.href = url
      a.download = `backup_agenda_${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(a)
      a.click()

      // Limpar
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      toast({
        title: "Backup criado com sucesso",
        description: "O arquivo de backup foi gerado e está sendo baixado.",
      })
    } catch (error) {
      console.error("Erro ao criar backup:", error)
      toast({
        variant: "destructive",
        title: "Erro ao criar backup",
        description: "Não foi possível gerar o arquivo de backup.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Função para selecionar arquivo de backup
  const handleSelectBackupFile = () => {
    fileInputRef.current?.click()
  }

  // Função para processar arquivo selecionado
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setBackupFile(file)
      setIsRestoreDialogOpen(true)
    }
  }

  // Função para restaurar backup
  const handleRestoreBackup = async () => {
    if (!backupFile) {
      setIsRestoreDialogOpen(false)
      return
    }

    try {
      setIsLoading(true)

      // Ler o arquivo
      const fileContent = await backupFile.text()
      let backupData

      try {
        backupData = JSON.parse(fileContent)
        console.log("Backup data parsed:", backupData)
      } catch (parseError) {
        console.error("Erro ao analisar JSON:", parseError)
        throw new Error("O arquivo não contém JSON válido")
      }

      // Verificar se o arquivo tem algum formato reconhecível
      if (!backupData || typeof backupData !== "object") {
        throw new Error("Formato de arquivo inválido: não é um objeto JSON")
      }

      // Tentar restaurar dados em diferentes formatos possíveis

      // Caso 1: Formato atual - objetos diretos
      if (
        Array.isArray(backupData.terapeutas) &&
        Array.isArray(backupData.pacientes) &&
        Array.isArray(backupData.agendamentos)
      ) {
        localStorage.setItem("terapeutas", JSON.stringify(backupData.terapeutas))
        localStorage.setItem("pacientes", JSON.stringify(backupData.pacientes))
        localStorage.setItem("agendamentos", JSON.stringify(backupData.agendamentos))

        if (Array.isArray(backupData.especialidades)) {
          localStorage.setItem("especialidades", JSON.stringify(backupData.especialidades))
        }

        // Restaurar logo institucional se existir
        if (backupData.logoInstitucional) {
          localStorage.setItem("logoInstitucional", backupData.logoInstitucional)
          setLogoPreview(backupData.logoInstitucional)
        }

        // Restaurar nome da empresa se existir
        if (backupData.nomeEmpresa) {
          localStorage.setItem("nomeEmpresa", backupData.nomeEmpresa)
          setNomeEmpresa(backupData.nomeEmpresa)
        }

        // Restaurar horários da clínica se existirem
        if (backupData.clinicaHorarioInicio) {
          localStorage.setItem("clinicaHorarioInicio", backupData.clinicaHorarioInicio)
          setHorarioInicio(backupData.clinicaHorarioInicio)
        }

        if (backupData.clinicaHorarioFim) {
          localStorage.setItem("clinicaHorarioFim", backupData.clinicaHorarioFim)
          setHorarioFim(backupData.clinicaHorarioFim)
        }
      }
      // Caso 2: Formato antigo - strings JSON
      else if (
        typeof backupData.terapeutas === "string" &&
        typeof backupData.pacientes === "string" &&
        typeof backupData.agendamentos === "string"
      ) {
        localStorage.setItem("terapeutas", backupData.terapeutas)
        localStorage.setItem("pacientes", backupData.pacientes)
        localStorage.setItem("agendamentos", backupData.agendamentos)

        if (typeof backupData.especialidades === "string") {
          localStorage.setItem("especialidades", backupData.especialidades)
        }
      }
      // Caso 3: Tentar recuperar o máximo possível
      else {
        let restored = false

        // Terapeutas
        if (backupData.terapeutas) {
          try {
            const terapeutas = Array.isArray(backupData.terapeutas)
              ? backupData.terapeutas
              : JSON.parse(backupData.terapeutas)
            localStorage.setItem("terapeutas", JSON.stringify(terapeutas))
            restored = true
          } catch (e) {
            console.warn("Não foi possível restaurar terapeutas:", e)
          }
        }

        // Pacientes
        if (backupData.pacientes) {
          try {
            const pacientes = Array.isArray(backupData.pacientes)
              ? backupData.pacientes
              : JSON.parse(backupData.pacientes)
            localStorage.setItem("pacientes", JSON.stringify(pacientes))
            restored = true
          } catch (e) {
            console.warn("Não foi possível restaurar pacientes:", e)
          }
        }

        // Agendamentos
        if (backupData.agendamentos) {
          try {
            const agendamentos = Array.isArray(backupData.agendamentos)
              ? backupData.agendamentos
              : JSON.parse(backupData.agendamentos)
            localStorage.setItem("agendamentos", JSON.stringify(agendamentos))
            restored = true
          } catch (e) {
            console.warn("Não foi possível restaurar agendamentos:", e)
          }
        }

        // Especialidades
        if (backupData.especialidades) {
          try {
            const especialidades = Array.isArray(backupData.especialidades)
              ? backupData.especialidades
              : JSON.parse(backupData.especialidades)
            localStorage.setItem("especialidades", JSON.stringify(especialidades))
            restored = true
          } catch (e) {
            console.warn("Não foi possível restaurar especialidades:", e)
          }
        }

        if (!restored) {
          throw new Error("Não foi possível restaurar nenhum dado do backup")
        }
      }

      // Disparar evento para notificar outros componentes
      window.dispatchEvent(new Event("storage"))
      window.dispatchEvent(new CustomEvent("agendamento-alterado"))

      toast({
        title: "Backup restaurado com sucesso",
        description: "Os dados foram restaurados a partir do backup.",
      })
    } catch (error) {
      console.error("Erro ao restaurar backup:", error)
      toast({
        variant: "destructive",
        title: "Erro ao restaurar backup",
        description:
          error instanceof Error ? error.message : "O arquivo de backup pode estar corrompido ou em formato inválido.",
      })
    } finally {
      setIsLoading(false)
      setIsRestoreDialogOpen(false)
      setBackupFile(null)
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Configurações</h2>
        <p className="text-muted-foreground">Gerencie as configurações do sistema</p>
      </div>

      {/* Nova seção para imagem institucional */}
      <Card>
        <CardHeader>
          <CardTitle>Identidade Visual</CardTitle>
          <CardDescription>
            Configure a imagem institucional e o nome da empresa que serão exibidos na tela de login
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Imagem institucional */}
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
            <div className="w-full max-w-[300px] h-[150px] border rounded-md flex items-center justify-center overflow-hidden bg-muted/20">
              {logoPreview ? (
                <img
                  src={logoPreview || "/placeholder.svg"}
                  alt="Logo institucional"
                  className="max-w-full max-h-full object-contain"
                />
              ) : (
                <div className="flex flex-col items-center text-muted-foreground">
                  <ImageIcon className="h-10 w-10 mb-2" />
                  <span>Nenhuma imagem selecionada</span>
                </div>
              )}
            </div>
            <div className="flex flex-col gap-2 w-full">
              <p className="text-sm text-muted-foreground">
                Selecione uma imagem para ser exibida na tela de login. Recomendamos uma imagem com dimensões
                aproximadas de 600x300 pixels.
              </p>
              <Button
                onClick={handleSelectLogoFile}
                variant="outline"
                className="flex items-center gap-2 w-full sm:w-auto"
              >
                <Upload className="h-4 w-4" />
                Selecionar Imagem
              </Button>
              <input
                type="file"
                ref={logoFileInputRef}
                onChange={handleLogoFileChange}
                accept="image/*"
                className="hidden"
              />
              <p className="text-xs text-muted-foreground">Formatos aceitos: JPG, PNG, GIF. Tamanho máximo: 2MB.</p>
            </div>
          </div>

          {/* Nome da empresa */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nome-empresa" className="flex items-center gap-2">
                <Building className="h-4 w-4" />
                Nome da Empresa
              </Label>
              <Input
                id="nome-empresa"
                value={nomeEmpresa}
                onChange={(e) => setNomeEmpresa(e.target.value)}
                placeholder="Digite o nome da empresa"
                className="max-w-md"
              />
              <p className="text-xs text-muted-foreground">
                Este nome será exibido na tela de login abaixo da imagem institucional.
              </p>
            </div>
            <Button onClick={handleSaveNomeEmpresa} className="flex items-center gap-2">
              Salvar Nome da Empresa
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Nova seção para horários da clínica */}
      <Card>
        <CardHeader>
          <CardTitle>Horários de Funcionamento</CardTitle>
          <CardDescription>
            Configure os horários de funcionamento da clínica que serão aplicados a todos os terapeutas
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="horario-inicio">Horário de Início</Label>
              <Select value={horarioInicio} onValueChange={setHorarioInicio}>
                <SelectTrigger id="horario-inicio">
                  <SelectValue placeholder="Selecione o horário de início" />
                </SelectTrigger>
                <SelectContent>
                  {horariosDisponiveis.map((horario) => (
                    <SelectItem key={`inicio-${horario}`} value={horario}>
                      {horario}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="horario-fim">Horário de Término</Label>
              <Select value={horarioFim} onValueChange={setHorarioFim}>
                <SelectTrigger id="horario-fim">
                  <SelectValue placeholder="Selecione o horário de término" />
                </SelectTrigger>
                <SelectContent>
                  {horariosDisponiveis.map((horario) => (
                    <SelectItem key={`fim-${horario}`} value={horario} disabled={horario <= horarioInicio}>
                      {horario}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end">
            <Button onClick={handleSaveHorarios} className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Salvar Horários
            </Button>
          </div>
          <div className="text-sm text-muted-foreground">
            <p>Estes horários serão aplicados como padrão para todos os terapeutas no cadastro de horários.</p>
          </div>
        </CardContent>
      </Card>

      {/* Nova seção para configuração de alertas */}
      <Card>
        <CardHeader>
          <CardTitle>Configuração de Alertas</CardTitle>
          <CardDescription>
            Configure os alertas de atendimento para notificar os terapeutas antes das consultas
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="alertas-ativos">Ativar Alertas de Atendimento</Label>
              <p className="text-sm text-muted-foreground">
                Quando ativado, os terapeutas receberão alertas antes dos atendimentos
              </p>
            </div>
            <Switch
              id="alertas-ativos"
              checked={localStorage.getItem("alertasAtivos") === "true"}
              onCheckedChange={(checked) => {
                localStorage.setItem("alertasAtivos", checked.toString())
                toast({
                  title: checked ? "Alertas ativados" : "Alertas desativados",
                  description: checked
                    ? "Os terapeutas receberão alertas antes dos atendimentos."
                    : "Os alertas de atendimento foram desativados.",
                })
              }}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tempo-alerta">Tempo de Antecedência do Alerta</Label>
            <Select
              defaultValue={localStorage.getItem("tempoAlerta") || "5"}
              onValueChange={(value) => {
                localStorage.setItem("tempoAlerta", value)
                toast({
                  title: "Tempo de alerta configurado",
                  description: `Os alertas serão enviados ${value === "0" ? "no momento" : `${value} minutos antes`} do atendimento.`,
                })
              }}
            >
              <SelectTrigger id="tempo-alerta" className="w-full max-w-xs">
                <SelectValue placeholder="Selecione o tempo de antecedência" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0">No momento do atendimento</SelectItem>
                <SelectItem value="5">5 minutos antes</SelectItem>
                <SelectItem value="10">10 minutos antes</SelectItem>
                <SelectItem value="15">15 minutos antes</SelectItem>
                <SelectItem value="30">30 minutos antes</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              Defina com quanto tempo de antecedência o terapeuta receberá o alerta de atendimento
            </p>
          </div>

          <div className="pt-4 border-t">
            <div className="rounded-md bg-amber-50 p-4 border border-amber-200">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-amber-500"
                  >
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                    <line x1="12" y1="9" x2="12" y2="13"></line>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-amber-800">Informação sobre alertas</h3>
                  <div className="mt-2 text-sm text-amber-700">
                    <p>
                      Os alertas serão exibidos apenas para o terapeuta responsável pelo atendimento. O terapeuta
                      receberá uma notificação informando o nome do paciente que será atendido.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Nova seção para configuração de visibilidade de terapeutas */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Visibilidade de Terapeutas</CardTitle>
          <CardDescription>Configure quais terapeutas serão exibidos na tela de agendamento</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="mostrar-todos-terapeutas">Exibir seleção de todos terapeutas</Label>
              <p className="text-sm text-muted-foreground">
                Escolha se todos os terapeutas ou apenas o terapeuta logado será exibido na tela de agendamento
              </p>
            </div>
            <Switch
              id="mostrar-todos-terapeutas"
              checked={localStorage.getItem("mostrarTodosTerapeutas") !== "false"}
              onCheckedChange={(checked) => {
                localStorage.setItem("mostrarTodosTerapeutas", checked.toString())
                // Disparar evento de storage para notificar outras páginas
                window.dispatchEvent(new StorageEvent("storage", { key: "mostrarTodosTerapeutas" }))
                toast({
                  title: checked ? "Todos os terapeutas serão exibidos" : "Apenas o terapeuta logado será exibido",
                  description: "Esta configuração afeta apenas usuários com perfil de funcionário.",
                })
              }}
            />
          </div>

          <div className="pt-4 border-t">
            <div className="rounded-md bg-blue-50 p-4 border border-blue-200">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-blue-500"
                  >
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 16v-4"></path>
                    <path d="M12 8h.01"></path>
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-blue-800">Informação sobre visibilidade</h3>
                  <div className="mt-2 text-sm text-blue-700">
                    <p>
                      Quando a opção "Exibir seleção de todos terapeutas" estiver desativada, usuários com perfil de
                      funcionário verão apenas sua própria agenda na tela de agendamento. Administradores continuarão
                      tendo acesso a todos os terapeutas independentemente desta configuração.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Separator className="my-6" />

      <Card>
        <CardHeader>
          <CardTitle>Backup e Restauração</CardTitle>
          <CardDescription>
            Crie backups dos dados do sistema ou restaure a partir de um backup anterior
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Criar Backup</h3>
            <p className="text-sm text-muted-foreground">
              Crie um backup completo de todos os dados do sistema, incluindo terapeutas, pacientes, agendamentos e
              especialidades.
            </p>
            <Button onClick={handleCreateBackup} disabled={isLoading} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              {isLoading ? "Gerando backup..." : "Criar Backup"}
            </Button>
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-medium">Restaurar Backup</h3>
            <p className="text-sm text-muted-foreground">
              Restaure todos os dados do sistema a partir de um arquivo de backup. Esta ação substituirá todos os dados
              atuais.
            </p>
            <div className="flex items-center gap-2">
              <Button
                onClick={handleSelectBackupFile}
                disabled={isLoading}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Upload className="h-4 w-4" />
                {isLoading ? "Processando..." : "Selecionar Arquivo de Backup"}
              </Button>
              <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".json" className="hidden" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Diálogo de confirmação para restauração de backup */}
      <AlertDialog open={isRestoreDialogOpen} onOpenChange={setIsRestoreDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Confirmar restauração
            </AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação substituirá todos os dados atuais do sistema pelos dados do backup. Esta operação não pode ser
              desfeita. Deseja continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setBackupFile(null)}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleRestoreBackup}>Restaurar Backup</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
