"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { AlertaAtendimento } from "@/components/alerta-atendimento"

export default function AgendaLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Verificar autenticação
    const checkAuth = () => {
      try {
        const userRole = sessionStorage.getItem("userRole")
        const userEmail = sessionStorage.getItem("userEmail")

        if (!userRole || !userEmail) {
          router.push("/")
          return
        }

        // Garantir que os dados do usuário estejam disponíveis antes de marcar como autenticado
        setIsAuthenticated(true)
      } catch (error) {
        console.error("Erro ao verificar autenticação:", error)
        router.push("/")
      } finally {
        setIsLoading(false)
      }
    }

    // Pequeno delay para garantir que o sessionStorage esteja disponível
    const timer = setTimeout(checkAuth, 100)
    return () => clearTimeout(timer)
  }, [router])

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Carregando...</h2>
          <p className="text-muted-foreground">Verificando suas credenciais</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <AlertaAtendimento />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 overflow-auto p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
