"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar, Clock, ChevronLeft, ChevronRight, FileDown, Star, Users } from "lucide-react"
import { mockPacientes, mockAgendamentos } from "@/lib/mock-data"
import { format, parseISO } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { PrintButton } from "@/components/print-button"
import * as XLSX from "xlsx"
import { Badge } from "@/components/ui/badge"

export default function PacientesPage() {
  const [selectedPaciente, setSelectedPaciente] = useState<string | null>(null)
  const [pacientes, setPacientes] = useState<any[]>([])
  const [agendamentos, setAgendamentos] = useState<any[]>([])
  const [terapeutas, setTerapeutas] = useState<any[]>([])
  const [currentDayIndex, setCurrentDayIndex] = useState(0)
  const [viewMode, setViewMode] = useState<"day" | "week">("week")
  const [isLoading, setIsLoading] = useState(false)
  const [horariosExibidos, setHorariosExibidos] = useState<string[]>([])
  const { toast } = useToast()

  // Ref para o link de download
  const downloadLinkRef = useRef<HTMLAnchorElement | null>(null)
  // Ref para a tabela de impressão
  const printTableRef = useRef<HTMLDivElement>(null)
  // Ref para controlar se os dados já foram carregados
  const dataLoadedRef = useRef(false)

  const diasSemana = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

  // Lista completa de todos os horários possíveis
  const horariosDisponiveis = [
    "00:00",
    "01:00",
    "02:00",
    "03:00",
    "04:00",
    "05:00",
    "06:00",
    "07:00",
    "08:00",
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00",
    "16:00",
    "17:00",
    "18:00",
    "19:00",
    "20:00",
    "21:00",
    "22:00",
    "23:00",
  ]

  // Criar elemento de link para download uma vez
  useEffect(() => {
    if (!downloadLinkRef.current) {
      const link = document.createElement("a")
      link.style.display = "none"
      document.body.appendChild(link)
      downloadLinkRef.current = link

      // Cleanup quando o componente for desmontado
      return () => {
        if (downloadLinkRef.current) {
          document.body.removeChild(downloadLinkRef.current)
        }
      }
    }
  }, [])

  // Função para carregar dados
  const carregarDados = useCallback(() => {
    if (dataLoadedRef.current) return

    setIsLoading(true)

    // Usar setTimeout para evitar o erro flushSync
    setTimeout(() => {
      try {
        // Carregar pacientes
        const storedPacientes = localStorage.getItem("pacientes")
        if (storedPacientes) {
          setPacientes(JSON.parse(storedPacientes))
        } else {
          setPacientes(mockPacientes)
          localStorage.setItem("pacientes", JSON.stringify(mockPacientes))
        }

        // Carregar agendamentos
        const storedAgendamentos = localStorage.getItem("agendamentos")
        if (storedAgendamentos) {
          setAgendamentos(JSON.parse(storedAgendamentos))
        } else {
          setAgendamentos(mockAgendamentos)
          localStorage.setItem("agendamentos", JSON.stringify(mockAgendamentos))
        }

        // Carregar terapeutas
        const storedTerapeutas = localStorage.getItem("terapeutas")
        if (storedTerapeutas) {
          setTerapeutas(JSON.parse(storedTerapeutas))
        }

        // Obter horários da clínica
        const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
        const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

        // Filtrar horários com base nas configurações da clínica
        const horariosClinica = horariosDisponiveis.filter((h) => h >= clinicaHorarioInicio && h <= clinicaHorarioFim)
        setHorariosExibidos(horariosClinica)

        dataLoadedRef.current = true
      } catch (error) {
        console.error("Erro ao carregar dados do localStorage:", error)
        setPacientes(mockPacientes)
        setAgendamentos(mockAgendamentos)

        // Horários padrão em caso de erro
        setHorariosExibidos(horariosDisponiveis.filter((h) => h >= "08:00" && h <= "18:00"))
      } finally {
        setIsLoading(false)
      }
    }, 0)
  }, [])

  // Carregar dados iniciais
  useEffect(() => {
    carregarDados()
  }, [carregarDados])

  // Adicionar listeners para eventos de atualização
  useEffect(() => {
    // Listener para mudanças no localStorage
    const handleStorageChange = (e: StorageEvent) => {
      if (
        e.key === "agendamentos" ||
        e.key === "pacientes" ||
        e.key === "terapeutas" ||
        e.key === "clinicaHorarioInicio" ||
        e.key === "clinicaHorarioFim"
      ) {
        // Resetar o flag para permitir recarregar os dados
        dataLoadedRef.current = false
        carregarDados()
      }
    }

    // Listener para eventos personalizados
    const handleAgendamentoAlterado = () => {
      // Resetar o flag para permitir recarregar os dados
      dataLoadedRef.current = false
      carregarDados()
    }

    // Registrar os listeners
    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("agendamento-alterado", handleAgendamentoAlterado)

    // Limpar os listeners quando o componente for desmontado
    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("agendamento-alterado", handleAgendamentoAlterado)
    }
  }, [carregarDados])

  const handlePacienteChange = (value: string) => {
    setSelectedPaciente(value)
    toast({
      title: "Paciente selecionado",
      description: `Visualizando agenda de ${pacientes.find((p) => p.id === value)?.nome}`,
    })
  }

  const paciente = pacientes.find((p) => p.id === selectedPaciente)

  // Filtrar agendamentos para mostrar apenas aqueles com pacientes e terapeutas válidos
  const filteredAgendamentos = agendamentos.filter((a) => {
    // Verificar se o terapeuta existe
    const terapeutaExiste = terapeutas.some((t) => t.id === a.terapeutaId)
    if (!terapeutaExiste) return false

    // Verificar pacientes
    if (a.tipo === "individual") {
      // Verificar se o paciente existe
      return pacientes.some((p) => p.id === a.pacienteId)
    } else if (a.tipo === "grupo" && a.pacienteIds) {
      // Verificar se pelo menos um paciente do grupo existe
      return a.pacienteIds.some((id: string) => pacientes.some((p) => p.id === id))
    } else if (a.tipo === "especial") {
      // Verificar se o paciente existe para atendimentos especiais
      return pacientes.some((p) => p.id === a.pacienteId)
    }

    return a.tipo === "reuniao" // Reuniões não precisam de pacientes
  })

  // Função para obter todos os terapeutas de um atendimento especial
  const getTerapeutasAtendimentoEspecial = useCallback(
    (agendamento: any) => {
      if (!agendamento || !agendamento.agendamentoEspecialId) return []

      // Encontrar todos os agendamentos relacionados com o mesmo ID especial
      const agendamentosRelacionados = agendamentos.filter(
        (a) => a.agendamentoEspecialId === agendamento.agendamentoEspecialId,
      )

      // Obter os IDs dos terapeutas envolvidos
      const terapeutaIds = agendamentosRelacionados.map((a) => a.terapeutaId)

      // Obter os objetos completos dos terapeutas
      return terapeutas.filter((t) => terapeutaIds.includes(t.id))
    },
    [agendamentos, terapeutas],
  )

  // Modificar a função para exibir os terapeutas de atendimentos especiais
  const renderCellContent = (agendamento: any) => {
    if (!agendamento) return null

    // Para agendamentos individuais
    if (agendamento.tipo === "individual") {
      const terapeuta = getTerapeutaByAgendamento(agendamento)
      if (!terapeuta) return null

      return (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8 avatar">
            <AvatarImage src={terapeuta.foto} alt={terapeuta.nome} />
            <AvatarFallback className="bg-agenda-blue text-white">
              {terapeuta.nome.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="overflow-hidden">
            <p className="text-sm font-medium truncate">{terapeuta.nome}</p>
            {terapeuta.especialidades && terapeuta.especialidades.length > 0 && (
              <p className="text-xs text-muted-foreground truncate">{terapeuta.especialidades[0]}</p>
            )}
          </div>
        </div>
      )
    }

    // Para agendamentos em grupo
    if (agendamento.tipo === "grupo") {
      const terapeuta = getTerapeutaByAgendamento(agendamento)
      if (!terapeuta) return null

      return (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8 avatar">
            <AvatarImage src={terapeuta.foto} alt={terapeuta.nome} />
            <AvatarFallback className="bg-agenda-green text-white">
              {terapeuta.nome.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="overflow-hidden">
            <p className="text-sm font-medium truncate">{terapeuta.nome}</p>
            <Badge variant="outline" className="bg-agenda-green-light text-agenda-green-dark border-agenda-green mt-1">
              <Users className="h-3 w-3 mr-1" />
              Grupo
            </Badge>
          </div>
        </div>
      )
    }

    // Para reuniões
    if (agendamento.tipo === "reuniao") {
      const terapeuta = getTerapeutaByAgendamento(agendamento)
      if (!terapeuta) return null

      return (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8 avatar">
            <AvatarImage src={terapeuta.foto} alt={terapeuta.nome} />
            <AvatarFallback className="bg-agenda-purple text-white">
              {terapeuta.nome.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="overflow-hidden">
            <p className="text-sm font-medium truncate">{terapeuta.nome}</p>
            <Badge
              variant="outline"
              className="bg-agenda-purple-light text-agenda-purple-dark border-agenda-purple mt-1"
            >
              <Calendar className="h-3 w-3 mr-1" />
              Reunião
            </Badge>
          </div>
        </div>
      )
    }

    // Para agendamentos especiais - CORRIGIDO
    if (agendamento.tipo === "especial") {
      // Obter todos os terapeutas envolvidos no atendimento especial
      const terapeutasEnvolvidos = getTerapeutasAtendimentoEspecial(agendamento)

      return (
        <div className="flex flex-col gap-2">
          <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-300 self-start">
            <Star className="h-3 w-3 mr-1" />
            Atendimento Especial
          </Badge>

          <div className="flex flex-col gap-1 mt-1">
            {terapeutasEnvolvidos.length > 0 ? (
              terapeutasEnvolvidos.map((terapeuta) => (
                <div key={terapeuta.id} className="flex items-center gap-1">
                  <Avatar className="h-5 w-5 avatar">
                    <AvatarImage src={terapeuta.foto} alt={terapeuta.nome} />
                    <AvatarFallback className="bg-amber-200 text-amber-800">
                      {terapeuta.nome.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs truncate">{terapeuta.nome}</span>
                </div>
              ))
            ) : (
              // Fallback para mostrar pelo menos o terapeuta principal
              <div className="flex items-center gap-1">
                {(() => {
                  const terapeuta = getTerapeutaByAgendamento(agendamento)
                  if (!terapeuta) return <span className="text-xs">Terapeuta não encontrado</span>

                  return (
                    <>
                      <Avatar className="h-5 w-5 avatar">
                        <AvatarImage src={terapeuta.foto} alt={terapeuta.nome} />
                        <AvatarFallback className="bg-amber-200 text-amber-800">
                          {terapeuta.nome.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs truncate">{terapeuta.nome}</span>
                    </>
                  )
                })()}
              </div>
            )}
          </div>
        </div>
      )
    }

    return null
  }

  // Atualizar a função getAgendamentoByDiaHorario para incluir agendamentos especiais
  const getAgendamentoByDiaHorario = useCallback(
    (dia: string, horario: string) => {
      if (!selectedPaciente) return null

      // Primeiro, procurar por agendamentos individuais ou em grupo
      const agendamento = filteredAgendamentos.find((agendamento) => {
        if (agendamento.dia !== dia || agendamento.horario !== horario) return false

        // Verificar se o paciente está neste agendamento
        if (agendamento.tipo === "individual" && agendamento.pacienteId === selectedPaciente) {
          return true
        }

        if (
          agendamento.tipo === "grupo" &&
          agendamento.pacienteIds &&
          agendamento.pacienteIds.includes(selectedPaciente)
        ) {
          return true
        }

        // Verificar se é um agendamento especial para este paciente
        if (agendamento.tipo === "especial" && agendamento.pacienteId === selectedPaciente) {
          return true
        }

        return false
      })

      return agendamento
    },
    [selectedPaciente, filteredAgendamentos],
  )

  // Função para obter o terapeuta de um agendamento
  const getTerapeutaByAgendamento = useCallback(
    (agendamento: any) => {
      if (!agendamento) return null
      return terapeutas.find((t) => t.id === agendamento.terapeutaId)
    },
    [terapeutas],
  )

  // Dias visíveis com base no modo de visualização
  const visibleDays = viewMode === "day" ? [diasSemana[currentDayIndex]] : diasSemana

  const handlePreviousDay = () => {
    setCurrentDayIndex((prev) => (prev - 1 + diasSemana.length) % diasSemana.length)
  }

  const handleNextDay = () => {
    setCurrentDayIndex((prev) => (prev + 1) % diasSemana.length)
  }

  // Função para verificar se é o horário atual
  const isCurrentTimeSlot = useCallback(
    (dia: string, horario: string) => {
      const hoje = new Date()
      const diaSemanaAtual = hoje.getDay() // 0 = Domingo, 1 = Segunda, ...

      // Converter para o formato do nosso array (Segunda = 0, Terça = 1, ...)
      const diaIndex = diaSemanaAtual === 0 ? 6 : diaSemanaAtual - 1
      const diaAtual = diasSemana[diaIndex]

      // Obter hora atual
      const horaAtual = hoje.getHours()
      const minutoAtual = hoje.getMinutes()

      // Converter horario (string) para horas e minutos
      const [horaSlot, minutoSlot] = horario.split(":").map(Number)

      // Verificar se é o dia atual e se a hora atual está dentro do slot
      return dia === diaAtual && horaAtual === horaSlot && minutoAtual >= 0 && minutoAtual < 60
    },
    [diasSemana],
  )

  // Função para selecionar automaticamente o dia da semana atual
  const handleSelectCurrentDay = () => {
    const hoje = new Date()
    // getDay() retorna 0 para domingo, 1 para segunda, etc.
    // Precisamos ajustar para nosso array que começa com Segunda (0)
    let diaAtual = hoje.getDay() - 1
    if (diaAtual < 0) diaAtual = 6 // Se for domingo (0), ajustar para 6 no nosso array

    // Obter hora atual
    const horaAtual = hoje.getHours().toString().padStart(2, "0") + ":00"

    setCurrentDayIndex(diaAtual)
    setViewMode("day")

    toast({
      title: "Dia atual selecionado",
      description: `Visualizando agenda de ${diasSemana[diaAtual]}`,
    })

    // Focalizar na célula do horário atual
    setTimeout(() => {
      const diaAtualStr = diasSemana[diaAtual]
      const celula = document.querySelector(`td[data-dia="${diaAtualStr}"][data-horario="${horaAtual}"]`)

      if (celula) {
        celula.scrollIntoView({ behavior: "smooth", block: "center" })

        // Adicionar efeito de destaque temporário
        celula.classList.add("highlight-cell")
        setTimeout(() => {
          celula.classList.remove("highlight-cell")
        }, 2000)
      }
    }, 100)
  }

  // Função para formatar a data de nascimento
  const formatarDataNascimento = (data: string | null | undefined) => {
    if (!data) return "Não informada"
    try {
      return format(parseISO(data), "dd/MM/yyyy", { locale: ptBR })
    } catch (error) {
      console.error("Erro ao formatar data:", error, data)
      return "Data inválida"
    }
  }

  // Função para exportar a agenda para Excel com formatação melhorada
  const exportarParaExcel = useCallback(() => {
    if (!selectedPaciente) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Selecione um paciente para exportar a agenda.",
      })
      return
    }

    const pacienteSelecionado = pacientes.find((p) => p.id === selectedPaciente)
    if (!pacienteSelecionado) return

    // Preparar os dados para exportação
    const dados = []

    // Adicionar cabeçalho com informações do paciente
    dados.push([`Agenda de ${pacienteSelecionado.nome}`])
    dados.push([]) // Linha em branco

    // Adicionar cabeçalho da tabela
    const cabecalho = ["Horário", ...diasSemana] // Sempre exportar todos os dias da semana
    dados.push(cabecalho)

    // Criar estilos para as células
    const estiloIndividual = { fill: { fgColor: { rgb: "E6F0FF" } } } // Azul claro
    const estiloGrupo = { fill: { fgColor: { rgb: "E6F7EF" } } } // Verde claro
    const estiloReuniao = { fill: { fgColor: { rgb: "F0E7FF" } } } // Roxo claro
    const estiloEspecial = { fill: { fgColor: { rgb: "FFF8E1" } } } // Âmbar claro

    // Mapeamento de estilos por célula
    const estilosCelulas: Record<string, any> = {}

    // Adicionar dados
    for (let rowIndex = 0; rowIndex < horariosExibidos.length; rowIndex++) {
      const horario = horariosExibidos[rowIndex]
      const linha = [horario]

      for (let colIndex = 0; colIndex < diasSemana.length; colIndex++) {
        const dia = diasSemana[colIndex]
        const agendamento = getAgendamentoByDiaHorario(dia, horario)
        const cellRef = XLSX.utils.encode_cell({ r: rowIndex + 3, c: colIndex + 1 }) // +3 para pular as linhas de cabeçalho

        if (agendamento) {
          if (agendamento.tipo === "individual") {
            const terapeuta = getTerapeutaByAgendamento(agendamento)
            linha.push(terapeuta ? `${terapeuta.nome} (Individual)` : "")
            estilosCelulas[cellRef] = estiloIndividual
          } else if (agendamento.tipo === "grupo") {
            const terapeuta = getTerapeutaByAgendamento(agendamento)
            linha.push(terapeuta ? `${terapeuta.nome} (Grupo)` : "")
            estilosCelulas[cellRef] = estiloGrupo
          } else if (agendamento.tipo === "reuniao") {
            const terapeuta = getTerapeutaByAgendamento(agendamento)
            linha.push(
              terapeuta
                ? `${terapeuta.nome} (Reunião${agendamento.comentario ? `: ${agendamento.comentario}` : ""})`
                : "",
            )
            estilosCelulas[cellRef] = estiloReuniao
          } else if (agendamento.tipo === "especial") {
            // Obter todos os terapeutas envolvidos
            const terapeutasEnvolvidos = getTerapeutasAtendimentoEspecial(agendamento)
            const terapeutasNomes = terapeutasEnvolvidos.map((t) => t.nome).join(", ")
            linha.push(`Atendimento Especial: ${terapeutasNomes || "Terapeutas não encontrados"}`)
            estilosCelulas[cellRef] = estiloEspecial
          } else {
            linha.push("")
          }
        } else {
          linha.push("")
        }
      }

      dados.push(linha)
    }

    // Criar planilha
    const ws = XLSX.utils.aoa_to_sheet(dados)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Agenda")

    // Configurar largura das colunas
    const wscols = [
      { wch: 10 }, // Horário
      ...diasSemana.map(() => ({ wch: 30 })), // Dias da semana
    ]
    ws["!cols"] = wscols

    // Aplicar estilos às células
    for (const [cellRef, estilo] of Object.entries(estilosCelulas)) {
      if (!ws[cellRef]) continue
      ws[cellRef].s = estilo
    }

    // Mesclar células para o título
    ws["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: diasSemana.length } }]

    // Gerar o arquivo Excel como um blob
    const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([wbout], { type: "application/octet-stream" })

    // Criar URL para o blob
    const url = URL.createObjectURL(blob)

    // Usar o link de referência para download
    if (downloadLinkRef.current) {
      downloadLinkRef.current.href = url
      downloadLinkRef.current.download = `Agenda_${pacienteSelecionado.nome}.xlsx`
      downloadLinkRef.current.click()

      // Limpar URL após o download
      URL.revokeObjectURL(url)
    }

    toast({
      title: "Agenda exportada",
      description: "A agenda foi exportada com sucesso com formatação.",
    })
  }, [
    selectedPaciente,
    pacientes,
    diasSemana,
    horariosExibidos,
    toast,
    getAgendamentoByDiaHorario,
    getTerapeutaByAgendamento,
    getTerapeutasAtendimentoEspecial,
  ])

  // Adicionar função para renderizar o cabeçalho de impressão
  const renderPrintHeader = () => {
    if (!paciente) return null

    // Calcular idade se tiver data de nascimento
    let idade = "Não informada"
    if (paciente.dataNascimento) {
      try {
        const dataNasc = new Date(paciente.dataNascimento)
        const hoje = new Date()
        idade = String(Math.floor((hoje.getTime() - dataNasc.getTime()) / (365.25 * 24 * 60 * 60 * 1000)))
      } catch (error) {
        console.error("Erro ao calcular idade:", error)
      }
    }

    return (
      <div className="hidden print:flex print:flex-col print:items-center print:mb-4">
        <h1 className="text-xl font-bold mb-2">Agenda de Atendimentos</h1>
        <div className="flex items-center gap-4 mb-4">
          <Avatar className="w-16 h-16 print-avatar">
            <AvatarImage src={paciente.foto} alt={paciente.nome} />
            <AvatarFallback>{paciente.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-lg font-semibold">{paciente.nome}</h2>
            <p className="text-sm">
              <span className="font-medium">Idade:</span> {idade} anos
            </p>
            <p className="text-sm">
              <span className="font-medium">Contato:</span> {paciente.telefone}
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-agenda-blue-dark">Pacientes</h2>
          <p className="text-muted-foreground">Visualize a agenda dos pacientes</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-agenda-blue-dark">Selecione um Paciente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <Select onValueChange={handlePacienteChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Selecione um paciente" />
              </SelectTrigger>
              <SelectContent>
                {pacientes.map((paciente) => (
                  <SelectItem key={paciente.id} value={paciente.id}>
                    {paciente.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {paciente && (
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16 border-2 border-agenda-blue-light">
                  <AvatarImage src={paciente.foto} alt={paciente.nome} />
                  <AvatarFallback className="bg-agenda-blue text-white">
                    {paciente.nome.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-lg font-medium text-agenda-blue-dark">{paciente.nome}</h3>
                  <p className="text-sm text-muted-foreground">{paciente.email}</p>
                  <p className="text-sm text-muted-foreground">{paciente.telefone}</p>
                  {paciente.dataNascimento && (
                    <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3 text-agenda-blue" />
                      <span>{formatarDataNascimento(paciente.dataNascimento)}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {selectedPaciente && renderPrintHeader()}
      {selectedPaciente && (
        <Card className="print-container">
          <CardHeader>
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
              <CardTitle className="text-agenda-blue-dark">Agenda do Paciente</CardTitle>
              <div className="flex flex-wrap items-center gap-2 no-print">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="outline" size="icon" onClick={handleSelectCurrentDay}>
                        <Clock className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Selecionar dia atual</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <Select value={viewMode} onValueChange={(value: "day" | "week") => setViewMode(value)}>
                  <SelectTrigger className="w-[120px]">
                    <SelectValue placeholder="Visualização" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="day">Diária</SelectItem>
                    <SelectItem value="week">Semanal</SelectItem>
                  </SelectContent>
                </Select>

                {viewMode === "day" && (
                  <div className="flex items-center gap-1">
                    <Button variant="outline" size="icon" onClick={handlePreviousDay}>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="w-24 text-center">{diasSemana[currentDayIndex]}</span>
                    <Button variant="outline" size="icon" onClick={handleNextDay}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0 md:p-6">
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <div className="flex flex-col items-center gap-2">
                  <div className="h-8 w-8 animate-spin rounded-full border-4 border-agenda-blue border-t-transparent"></div>
                  <p className="text-muted-foreground">Carregando agenda...</p>
                </div>
              </div>
            ) : (
              /* Tabela responsiva com rolagem horizontal */
              <div className="overflow-x-auto w-full" ref={printTableRef}>
                <table
                  className={`w-full border-collapse print-table ${viewMode === "day" ? "print-day-view" : "print-week-view"}`}
                >
                  <thead>
                    <tr>
                      <th className="border p-2 bg-muted sticky left-0 z-10">Horário</th>
                      {/* Na impressão, sempre mostrar todos os dias da semana */}
                      {(viewMode === "week" ? visibleDays : diasSemana).map((dia) => (
                        <th
                          key={dia}
                          className={`border p-2 bg-muted min-w-[150px] ${viewMode === "day" && dia !== visibleDays[0] ? "hidden print:table-cell" : ""}`}
                        >
                          {dia}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {horariosExibidos.map((horario) => (
                      <tr key={horario}>
                        <td className="border p-2 font-medium sticky left-0 bg-background z-10">{horario}</td>
                        {/* Na impressão, sempre mostrar todos os dias da semana */}
                        {(viewMode === "week" ? visibleDays : diasSemana).map((dia) => {
                          const agendamento = getAgendamentoByDiaHorario(dia, horario)

                          let bgColor = ""
                          let printClass = ""

                          if (agendamento) {
                            if (agendamento.tipo === "individual") {
                              bgColor = "bg-agenda-blue-light"
                              printClass = "print-bg-blue"
                            } else if (agendamento.tipo === "grupo") {
                              bgColor = "bg-agenda-green-light"
                              printClass = "print-bg-green"
                            } else if (agendamento.tipo === "reuniao") {
                              bgColor = "bg-agenda-purple-light"
                              printClass = "print-bg-purple"
                            } else if (agendamento.tipo === "especial") {
                              bgColor = "bg-amber-100"
                              printClass = "print-bg-amber"
                            }
                          }

                          return (
                            <td
                              key={`${dia}-${horario}`}
                              className={`border p-2 h-16 ${bgColor} ${printClass} ${
                                isCurrentTimeSlot(dia, horario) ? "cell-current-time" : ""
                              } ${viewMode === "day" && dia !== visibleDays[0] ? "hidden print:table-cell" : ""}`}
                              data-dia={dia}
                              data-horario={horario}
                            >
                              {renderCellContent(agendamento)}
                            </td>
                          )
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div className="flex justify-center items-center gap-2 sm:gap-8 text-sm flex-wrap mt-4 print-legend">
              <div className="flex items-center gap-1 sm:gap-2 print-legend-item">
                <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-agenda-blue-light print-legend-color"></div>
                <span className="print-legend-text">Individual</span>
              </div>
              <div className="flex items-center gap-1 sm:gap-2 print-legend-item">
                <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-agenda-green-light print-legend-color"></div>
                <span className="print-legend-text">Grupo</span>
              </div>
              <div className="flex items-center gap-1 sm:gap-2 print-legend-item">
                <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-agenda-purple-light print-legend-color"></div>
                <span className="print-legend-text">Reunião</span>
              </div>
              <div className="flex items-center gap-1 sm:gap-2 print-legend-item">
                <div className="h-4 w-4 sm:h-6 sm:w-6 rounded-full bg-amber-100 print-legend-color"></div>
                <span className="print-legend-text">Especial</span>
              </div>
            </div>
            <div className="flex flex-col gap-4 mt-6">
              {/* Legenda removida conforme solicitado */}

              <div className="flex justify-center gap-2 no-print">
                <Button variant="outline" size="sm" className="flex items-center gap-2" onClick={exportarParaExcel}>
                  <FileDown className="h-4 w-4" />
                  Exportar para Excel
                </Button>

                <PrintButton className="ml-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
