"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { PacienteForm } from "@/components/paciente-form"
import { Plus, Pencil, Trash2, Calendar } from "lucide-react"
import { mockPacientes } from "@/lib/mock-data"
import { format, parseISO } from "date-fns"
import { ptBR } from "date-fns/locale"
import { useRouter } from "next/navigation"

export default function PacientesCadastroPage() {
  const [pacientes, setPacientes] = useState<any[]>([])
  const [agendamentos, setAgendamentos] = useState<any[]>([])
  const [selectedPaciente, setSelectedPaciente] = useState<any | null>(null)
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  // Carregar pacientes e agendamentos do localStorage
  useEffect(() => {
    try {
      // Carregar pacientes
      const storedPacientes = localStorage.getItem("pacientes")
      if (storedPacientes) {
        setPacientes(JSON.parse(storedPacientes))
      } else {
        setPacientes(mockPacientes)
        localStorage.setItem("pacientes", JSON.stringify(mockPacientes))
      }

      // Carregar agendamentos
      const storedAgendamentos = localStorage.getItem("agendamentos")
      if (storedAgendamentos) {
        setAgendamentos(JSON.parse(storedAgendamentos))
      } else {
        setAgendamentos([])
      }
    } catch (error) {
      console.error("Erro ao carregar pacientes do localStorage:", error)
      setPacientes(mockPacientes)
    }
  }, [])

  const handleAddPaciente = () => {
    setSelectedPaciente({
      id: `new-${Date.now()}`,
      nome: "",
      email: "",
      telefone: "",
      foto: "",
      dataNascimento: null,
    })
    setIsFormDialogOpen(true)
  }

  const handleEditPaciente = (paciente: any) => {
    setSelectedPaciente(paciente)
    setIsFormDialogOpen(true)
  }

  const handleDeletePaciente = (paciente: any) => {
    setSelectedPaciente(paciente)
    setIsDeleteDialogOpen(true)
  }

  const confirmDeletePaciente = () => {
    if (!selectedPaciente) return

    // 1. Remover o paciente da lista
    const updatedPacientes = pacientes.filter((p) => p.id !== selectedPaciente.id)
    setPacientes(updatedPacientes)

    // 2. Remover agendamentos individuais deste paciente
    let updatedAgendamentos = agendamentos.filter(
      (a) => !(a.tipo === "individual" && a.pacienteId === selectedPaciente.id),
    )

    // 3. Remover o paciente de agendamentos em grupo
    updatedAgendamentos = updatedAgendamentos
      .map((a) => {
        if (a.tipo === "grupo" && a.pacienteIds && a.pacienteIds.includes(selectedPaciente.id)) {
          // Remover o paciente da lista de pacientes do grupo
          const updatedPacienteIds = a.pacienteIds.filter((id: string) => id !== selectedPaciente.id)

          // Se ainda houver pacientes no grupo, atualizar o agendamento
          if (updatedPacienteIds.length > 0) {
            return { ...a, pacienteIds: updatedPacienteIds }
          } else {
            // Se não houver mais pacientes, marcar para exclusão
            return null
          }
        }
        return a
      })
      .filter(Boolean) // Remover agendamentos marcados como null

    // Salvar pacientes atualizados no localStorage
    try {
      localStorage.setItem("pacientes", JSON.stringify(updatedPacientes))
      localStorage.setItem("agendamentos", JSON.stringify(updatedAgendamentos))

      // Atualizar o estado dos agendamentos
      setAgendamentos(updatedAgendamentos)

      // Disparar um evento de storage para notificar outros componentes
      window.dispatchEvent(
        new CustomEvent("agendamento-alterado", {
          detail: { action: "delete-paciente", id: selectedPaciente.id },
        }),
      )
    } catch (error) {
      console.error("Erro ao salvar no localStorage:", error)
    }

    setIsDeleteDialogOpen(false)

    toast({
      title: "Paciente removido",
      description: `${selectedPaciente.nome} foi removido com sucesso, junto com todos os seus agendamentos.`,
    })
  }

  const handleSavePaciente = (paciente: any) => {
    let updatedPacientes: any[] = []

    // Se for um novo paciente
    if (paciente.id.startsWith("new-")) {
      const newPaciente = {
        ...paciente,
        id: `paciente-${Date.now()}`,
      }
      updatedPacientes = [...pacientes, newPaciente]
      toast({
        title: "Paciente adicionado",
        description: `${paciente.nome} foi adicionado com sucesso.`,
      })
    } else {
      // Se for edição
      updatedPacientes = pacientes.map((p) => (p.id === paciente.id ? paciente : p))
      toast({
        title: "Paciente atualizado",
        description: `${paciente.nome} foi atualizado com sucesso.`,
      })
    }

    setPacientes(updatedPacientes)

    // Salvar no localStorage
    try {
      localStorage.setItem("pacientes", JSON.stringify(updatedPacientes))

      // Disparar um evento de storage para notificar outros componentes
      window.dispatchEvent(
        new CustomEvent("agendamento-alterado", {
          detail: { action: "update-paciente", id: paciente.id },
        }),
      )
    } catch (error) {
      console.error("Erro ao salvar pacientes no localStorage:", error)
    }

    setIsFormDialogOpen(false)
  }

  // Função para formatar a data de nascimento
  const formatarDataNascimento = (data: string | null | undefined) => {
    if (!data) return "Não informada"
    try {
      return format(parseISO(data), "dd/MM/yyyy", { locale: ptBR })
    } catch (error) {
      console.error("Erro ao formatar data:", error, data)
      return "Data inválida"
    }
  }

  return (
    <>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-agenda-blue-dark">Cadastro de Pacientes</h2>
            <p className="text-muted-foreground">Gerencie os pacientes do sistema</p>
          </div>
          <Button
            onClick={handleAddPaciente}
            className="flex items-center gap-1 bg-agenda-blue hover:bg-agenda-blue-dark"
          >
            <Plus className="h-4 w-4" />
            Adicionar Paciente
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {pacientes.map((paciente) => (
            <Card key={paciente.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4 border-2 border-agenda-blue-light">
                    <AvatarImage src={paciente.foto} alt={paciente.nome} />
                    <AvatarFallback className="bg-agenda-blue text-white">
                      {paciente.nome.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-medium text-agenda-blue-dark">{paciente.nome}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{paciente.email}</p>
                  <p className="text-sm text-muted-foreground">{paciente.telefone}</p>
                  <div className="flex items-center gap-1 mt-2 text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3 text-agenda-blue" />
                    <span>{formatarDataNascimento(paciente.dataNascimento)}</span>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditPaciente(paciente)}
                      className="flex items-center gap-1 border-agenda-blue text-agenda-blue hover:bg-agenda-blue-light hover:text-agenda-blue-dark"
                    >
                      <Pencil className="h-4 w-4" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeletePaciente(paciente)}
                      className="flex items-center gap-1"
                    >
                      <Trash2 className="h-4 w-4" />
                      Excluir
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Diálogo de formulário de paciente */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-agenda-blue-dark">
              {selectedPaciente?.nome ? "Editar Paciente" : "Novo Paciente"}
            </DialogTitle>
          </DialogHeader>
          {selectedPaciente && <PacienteForm paciente={selectedPaciente} onSave={handleSavePaciente} />}
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmação de exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Ao excluir este paciente, todos os seus agendamentos serão removidos. Deseja continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeletePaciente}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
