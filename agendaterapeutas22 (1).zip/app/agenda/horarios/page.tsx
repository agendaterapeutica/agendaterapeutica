"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { mockTerapeutas } from "@/lib/mock-data"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Switch } from "@/components/ui/switch"
import { Clock, Copy, AlertCircle } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function HorariosPage() {
  const [terapeutas, setTerapeutas] = useState<any[]>([])
  const [selectedTerapeuta, setSelectedTerapeuta] = useState<string | null>(null)
  const [isApplyToAllDialogOpen, setIsApplyToAllDialogOpen] = useState(false)
  const [sourceDayForAll, setSourceDayForAll] = useState<string | null>(null)
  const { toast } = useToast()

  const diasSemana = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
  const [horariosDisponiveis, setHorariosDisponiveis] = useState([
    "07:00",
    "08:00",
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00",
    "16:00",
    "17:00",
    "18:00",
    "19:00",
    "20:00",
  ])

  // Estado para armazenar os horários por dia da semana
  const [horariosPorDia, setHorariosPorDia] = useState<Record<string, string[]>>({
    Segunda: [],
    Terça: [],
    Quarta: [],
    Quinta: [],
    Sexta: [],
    Sábado: [],
    Domingo: [],
  })

  // Estado para armazenar os horários de início e fim por dia
  const [rangesPorDia, setRangesPorDia] = useState<Record<string, { inicio: string; fim: string; ativo: boolean }>>({
    Segunda: { inicio: "08:00", fim: "18:00", ativo: true },
    Terça: { inicio: "08:00", fim: "18:00", ativo: true },
    Quarta: { inicio: "08:00", fim: "18:00", ativo: true },
    Quinta: { inicio: "08:00", fim: "18:00", ativo: true },
    Sexta: { inicio: "08:00", fim: "18:00", ativo: true },
    Sábado: { inicio: "08:00", fim: "12:00", ativo: false },
    Domingo: { inicio: "08:00", fim: "12:00", ativo: false },
  })

  // Estado para armazenar horários bloqueados por dia
  const [horariosBloqueados, setHorariosBloqueados] = useState<Record<string, string[]>>({
    Segunda: [],
    Terça: [],
    Quarta: [],
    Quinta: [],
    Sexta: [],
    Sábado: [],
    Domingo: [],
  })

  // Carregar terapeutas do localStorage
  useEffect(() => {
    try {
      const storedTerapeutas = localStorage.getItem("terapeutas")
      if (storedTerapeutas) {
        setTerapeutas(JSON.parse(storedTerapeutas))
      } else {
        setTerapeutas(mockTerapeutas)
        localStorage.setItem("terapeutas", JSON.stringify(mockTerapeutas))
      }

      // Carregar horários da clínica
      const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
      const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

      // Criar array com todos os horários disponíveis
      const todosHorarios = [
        "00:00",
        "01:00",
        "02:00",
        "03:00",
        "04:00",
        "05:00",
        "06:00",
        "07:00",
        "08:00",
        "09:00",
        "10:00",
        "11:00",
        "12:00",
        "13:00",
        "14:00",
        "15:00",
        "16:00",
        "17:00",
        "18:00",
        "19:00",
        "20:00",
        "21:00",
        "22:00",
        "23:00",
      ]

      // Filtrar horários disponíveis com base nos horários da clínica
      setHorariosDisponiveis(todosHorarios)
    } catch (error) {
      console.error("Erro ao carregar dados do localStorage:", error)
      setTerapeutas(mockTerapeutas)
    }
  }, [])

  const handleTerapeutaChange = (value: string) => {
    setSelectedTerapeuta(value)
    const terapeuta = terapeutas.find((t) => t.id === value)

    // Obter horários da clínica da configuração
    const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
    const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

    if (terapeuta) {
      // Inicializar horários disponíveis para cada dia da semana
      if (terapeuta.horariosPorDia) {
        setHorariosPorDia(terapeuta.horariosPorDia)
      } else {
        // Caso contrário, usar horários padrão
        const horarios: Record<string, string[]> = {}
        diasSemana.forEach((dia) => {
          horarios[dia] = horariosDisponiveis.filter((h) => h >= clinicaHorarioInicio && h <= clinicaHorarioFim)
        })
        setHorariosPorDia(horarios)
      }

      // Inicializar ranges por dia
      if (terapeuta.rangesPorDia) {
        setRangesPorDia(terapeuta.rangesPorDia)
      } else {
        // Caso contrário, usar ranges padrão baseados na configuração da clínica
        const ranges: Record<string, { inicio: string; fim: string; ativo: boolean }> = {}
        diasSemana.forEach((dia) => {
          ranges[dia] = {
            inicio: clinicaHorarioInicio,
            fim: clinicaHorarioFim,
            ativo: dia !== "Sábado" && dia !== "Domingo",
          }
        })
        setRangesPorDia(ranges)
      }

      // Inicializar horários bloqueados
      if (terapeuta.horariosBloqueados) {
        setHorariosBloqueados(terapeuta.horariosBloqueados)
      } else {
        const bloqueados: Record<string, string[]> = {}
        diasSemana.forEach((dia) => {
          bloqueados[dia] = []
        })
        setHorariosBloqueados(bloqueados)
      }
    }
  }

  const handleRangeChange = (dia: string, campo: "inicio" | "fim", valor: string) => {
    // Obter horários da clínica da configuração
    const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
    const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

    // Verificar se o valor está dentro dos limites configurados
    if (campo === "inicio" && valor < clinicaHorarioInicio) {
      toast({
        variant: "destructive",
        title: "Horário inválido",
        description: `O horário de início não pode ser anterior a ${clinicaHorarioInicio}.`,
      })
      return
    }

    if (campo === "fim" && valor > clinicaHorarioFim) {
      toast({
        variant: "destructive",
        title: "Horário inválido",
        description: `O horário de término não pode ser posterior a ${clinicaHorarioFim}.`,
      })
      return
    }

    setRangesPorDia((prev) => ({
      ...prev,
      [dia]: {
        ...prev[dia],
        [campo]: valor,
      },
    }))

    // Atualizar horários disponíveis com base no novo range
    atualizarHorariosDisponiveis(
      dia,
      campo === "inicio" ? valor : rangesPorDia[dia].inicio,
      campo === "fim" ? valor : rangesPorDia[dia].fim,
    )
  }

  const handleAtivoDiaChange = (dia: string, ativo: boolean) => {
    setRangesPorDia((prev) => ({
      ...prev,
      [dia]: {
        ...prev[dia],
        ativo,
      },
    }))

    // Se desativar o dia, limpar os horários disponíveis
    if (!ativo) {
      setHorariosPorDia((prev) => ({
        ...prev,
        [dia]: [],
      }))
      setHorariosBloqueados((prev) => ({
        ...prev,
        [dia]: [],
      }))
    } else {
      // Se ativar o dia, definir horários disponíveis com base no range
      atualizarHorariosDisponiveis(dia, rangesPorDia[dia].inicio, rangesPorDia[dia].fim)
    }
  }

  const atualizarHorariosDisponiveis = (dia: string, inicio: string, fim: string) => {
    const horariosFiltrados = horariosDisponiveis.filter(
      (h) => h >= inicio && h <= fim && !horariosBloqueados[dia]?.includes(h),
    )

    setHorariosPorDia((prev) => ({
      ...prev,
      [dia]: horariosFiltrados,
    }))
  }

  const toggleHorarioBloqueado = (dia: string, horario: string) => {
    setHorariosBloqueados((prev) => {
      const bloqueados = [...(prev[dia] || [])]

      if (bloqueados.includes(horario)) {
        // Remover horário bloqueado
        const novosBloqueados = bloqueados.filter((h) => h !== horario)

        // Atualizar horários disponíveis
        if (horario >= rangesPorDia[dia].inicio && horario <= rangesPorDia[dia].fim) {
          setHorariosPorDia((prevHorarios) => ({
            ...prevHorarios,
            [dia]: [...prevHorarios[dia], horario].sort(),
          }))
        }

        return {
          ...prev,
          [dia]: novosBloqueados,
        }
      } else {
        // Adicionar horário bloqueado
        const novosBloqueados = [...bloqueados, horario].sort()

        // Remover dos horários disponíveis
        setHorariosPorDia((prevHorarios) => ({
          ...prevHorarios,
          [dia]: prevHorarios[dia].filter((h) => h !== horario),
        }))

        return {
          ...prev,
          [dia]: novosBloqueados,
        }
      }
    })
  }

  const handleApplyToAll = (dia: string) => {
    setSourceDayForAll(dia)
    setIsApplyToAllDialogOpen(true)
  }

  const confirmApplyToAll = () => {
    if (!sourceDayForAll) return

    const sourceRange = rangesPorDia[sourceDayForAll]
    const sourceBloqueados = horariosBloqueados[sourceDayForAll] || []

    const newRanges = { ...rangesPorDia }
    const newBloqueados = { ...horariosBloqueados }
    const newHorarios = { ...horariosPorDia }

    diasSemana.forEach((dia) => {
      if (dia !== sourceDayForAll) {
        // Copiar configurações de range
        newRanges[dia] = { ...sourceRange }

        // Copiar horários bloqueados
        newBloqueados[dia] = [...sourceBloqueados]

        // Atualizar horários disponíveis
        if (sourceRange.ativo) {
          newHorarios[dia] = horariosDisponiveis.filter(
            (h) => h >= sourceRange.inicio && h <= sourceRange.fim && !sourceBloqueados.includes(h),
          )
        } else {
          newHorarios[dia] = []
        }
      }
    })

    setRangesPorDia(newRanges)
    setHorariosBloqueados(newBloqueados)
    setHorariosPorDia(newHorarios)

    setIsApplyToAllDialogOpen(false)

    toast({
      title: "Configuração aplicada",
      description: `A configuração de ${sourceDayForAll} foi aplicada a todos os outros dias.`,
    })
  }

  const handleSave = () => {
    if (!selectedTerapeuta) return

    // Atualizar horários do terapeuta
    const updatedTerapeutas = terapeutas.map((terapeuta) =>
      terapeuta.id === selectedTerapeuta
        ? {
            ...terapeuta,
            horariosPorDia: horariosPorDia,
            rangesPorDia: rangesPorDia,
            horariosBloqueados: horariosBloqueados,
            // Atualizar também os horários gerais com base no primeiro dia útil configurado
            horarioInicio: getEarliestHour(),
            horarioFim: getLatestHour(),
          }
        : terapeuta,
    )

    setTerapeutas(updatedTerapeutas)

    // Atualizar os dados no localStorage para sincronização
    try {
      localStorage.setItem("terapeutas", JSON.stringify(updatedTerapeutas))
    } catch (error) {
      console.error("Erro ao salvar no localStorage:", error)
    }

    toast({
      title: "Horários salvos com sucesso",
      description: "Os horários do terapeuta foram atualizados com sucesso.",
      variant: "success",
    })
  }

  // Obter o horário mais cedo configurado em qualquer dia
  const getEarliestHour = () => {
    let earliest = "23:59"

    Object.entries(rangesPorDia).forEach(([dia, range]) => {
      if (range.ativo && range.inicio < earliest) {
        earliest = range.inicio
      }
    })

    return earliest === "23:59" ? "08:00" : earliest
  }

  // Obter o horário mais tarde configurado em qualquer dia
  const getLatestHour = () => {
    let latest = "00:00"

    Object.entries(rangesPorDia).forEach(([dia, range]) => {
      if (range.ativo && range.fim > latest) {
        latest = range.fim
      }
    })

    return latest === "00:00" ? "18:00" : latest
  }

  const terapeuta = terapeutas.find((t) => t.id === selectedTerapeuta)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Cadastro de Horários</h2>
        <p className="text-muted-foreground">Configure os horários de trabalho dos terapeutas</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Selecione um Terapeuta</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <Select onValueChange={handleTerapeutaChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Selecione um terapeuta" />
              </SelectTrigger>
              <SelectContent>
                {terapeutas.map((terapeuta) => (
                  <SelectItem key={terapeuta.id} value={terapeuta.id}>
                    {terapeuta.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {terapeuta && (
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={terapeuta.foto || "/placeholder.svg"} alt={terapeuta.nome} />
                  <AvatarFallback>{terapeuta.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-lg font-medium">{terapeuta.nome}</h3>
                  {terapeuta.especialidades && terapeuta.especialidades.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {terapeuta.especialidades.map((esp: string) => (
                        <span key={esp} className="text-sm text-muted-foreground">
                          {esp}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {selectedTerapeuta && (
        <Card>
          <CardHeader>
            <CardTitle>Configurar Horários por Dia</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="Segunda" className="w-full">
              <ScrollArea className="w-full">
                <TabsList className="flex w-full mb-4 overflow-x-auto">
                  {diasSemana.map((dia) => (
                    <TabsTrigger key={dia} value={dia} className="flex-shrink-0 text-xs sm:text-sm px-2 sm:px-4">
                      {dia.substring(0, 3)}
                      <span className="hidden sm:inline">{dia.substring(3)}</span>
                    </TabsTrigger>
                  ))}
                </TabsList>
              </ScrollArea>

              {diasSemana.map((dia) => (
                <TabsContent key={dia} value={dia} className="space-y-4">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <h3 className="text-lg font-medium">{dia}</h3>
                    </div>
                    <div className="flex items-center gap-2">
                      <Label htmlFor={`ativo-${dia}`}>Dia disponível</Label>
                      <Switch
                        id={`ativo-${dia}`}
                        checked={rangesPorDia[dia]?.ativo || false}
                        onCheckedChange={(checked) => handleAtivoDiaChange(dia, checked)}
                      />
                    </div>
                  </div>

                  {rangesPorDia[dia]?.ativo && (
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1">
                          <Label>Horário de início</Label>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{rangesPorDia[dia]?.inicio}</span>
                          </div>
                        </div>
                        <Select
                          value={rangesPorDia[dia]?.inicio}
                          onValueChange={(value) => handleRangeChange(dia, "inicio", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o horário de início" />
                          </SelectTrigger>
                          <SelectContent>
                            {horariosDisponiveis.map((horario) => {
                              const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
                              const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

                              return (
                                <SelectItem
                                  key={horario}
                                  value={horario}
                                  disabled={horario < clinicaHorarioInicio || horario >= rangesPorDia[dia]?.fim}
                                >
                                  {horario}
                                </SelectItem>
                              )
                            })}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1">
                          <Label>Horário de término</Label>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{rangesPorDia[dia]?.fim}</span>
                          </div>
                        </div>
                        <Select
                          value={rangesPorDia[dia]?.fim}
                          onValueChange={(value) => handleRangeChange(dia, "fim", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o horário de término" />
                          </SelectTrigger>
                          <SelectContent>
                            {horariosDisponiveis.map((horario) => {
                              const clinicaHorarioInicio = localStorage.getItem("clinicaHorarioInicio") || "08:00"
                              const clinicaHorarioFim = localStorage.getItem("clinicaHorarioFim") || "18:00"

                              return (
                                <SelectItem
                                  key={horario}
                                  value={horario}
                                  disabled={horario <= rangesPorDia[dia]?.inicio || horario > clinicaHorarioFim}
                                >
                                  {horario}
                                </SelectItem>
                              )
                            })}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="p-4 bg-muted/20 rounded-md">
                        <div className="flex justify-between text-sm text-muted-foreground mb-2">
                          <span>Manhã</span>
                          <span>Tarde</span>
                          <span>Noite</span>
                        </div>
                        <div className="h-8 bg-gradient-to-r from-blue-100 via-blue-200 to-blue-300 rounded-md relative">
                          {horariosDisponiveis.map((horario, index) => (
                            <div
                              key={horario}
                              className="absolute h-full border-l border-blue-400/30"
                              style={{
                                left: `${(index / (horariosDisponiveis.length - 1)) * 100}%`,
                                opacity:
                                  horario === rangesPorDia[dia]?.inicio || horario === rangesPorDia[dia]?.fim ? 1 : 0.3,
                              }}
                            >
                              {(index % 3 === 0 ||
                                horario === rangesPorDia[dia]?.inicio ||
                                horario === rangesPorDia[dia]?.fim) && (
                                <span className="absolute -bottom-6 -translate-x-1/2 text-xs">{horario}</span>
                              )}
                            </div>
                          ))}
                          <div
                            className="absolute h-full bg-primary/20 border-l border-r border-primary"
                            style={{
                              left: `${(horariosDisponiveis.indexOf(rangesPorDia[dia]?.inicio) / (horariosDisponiveis.length - 1)) * 100}%`,
                              width: `${((horariosDisponiveis.indexOf(rangesPorDia[dia]?.fim) - horariosDisponiveis.indexOf(rangesPorDia[dia]?.inicio)) / (horariosDisponiveis.length - 1)) * 100}%`,
                            }}
                          />
                        </div>
                      </div>

                      <div className="space-y-2 mt-6">
                        <div className="flex justify-between items-center">
                          <Label className="flex items-center gap-2">
                            <AlertCircle className="h-4 w-4 text-amber-500" />
                            Horários indisponíveis
                          </Label>
                        </div>

                        <div className="grid grid-cols-3 xs:grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-1 sm:gap-2">
                          {horariosDisponiveis
                            .filter((h) => h >= rangesPorDia[dia].inicio && h <= rangesPorDia[dia].fim)
                            .map((horario) => {
                              const isBloqueado = horariosBloqueados[dia]?.includes(horario)

                              return (
                                <div
                                  key={horario}
                                  className={`border rounded-md p-2 flex items-center justify-between cursor-pointer hover:bg-muted/20 ${
                                    isBloqueado ? "bg-red-50 border-red-200" : ""
                                  }`}
                                  onClick={() => toggleHorarioBloqueado(dia, horario)}
                                >
                                  <span>{horario}</span>
                                  <Checkbox
                                    checked={isBloqueado}
                                    onCheckedChange={() => toggleHorarioBloqueado(dia, horario)}
                                  />
                                </div>
                              )
                            })}
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => handleApplyToAll(diasSemana[0])}
              className="flex items-center gap-1"
            >
              <Copy className="h-4 w-4" />
              Aplicar para todos
            </Button>
            <Button onClick={handleSave}>Salvar Horários</Button>
          </CardFooter>
        </Card>
      )}

      {/* Diálogo de confirmação para aplicar a todos */}
      <AlertDialog open={isApplyToAllDialogOpen} onOpenChange={setIsApplyToAllDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Aplicar configuração a todos os dias</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja aplicar a configuração de {sourceDayForAll} a todos os outros dias da semana? Isso
              substituirá todas as configurações existentes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmApplyToAll}>Aplicar a todos</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
