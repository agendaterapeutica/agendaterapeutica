"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { TerapeutaForm } from "@/components/terapeuta-form"
import { Plus, Pencil, Trash2 } from "lucide-react"
import { mockTerapeutas, mockEspecialidades } from "@/lib/mock-data"
import { useRouter } from "next/navigation"

export default function TerapeutasPage() {
  const [terapeutas, setTerapeutas] = useState<any[]>([])
  const [agendamentos, setAgendamentos] = useState<any[]>([])
  const [especialidades, setEspecialidades] = useState<string[]>([])
  const [selectedTerapeuta, setSelectedTerapeuta] = useState<any | null>(null)
  const [isFormDialogOpen, setIsFormDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  // Carregar terapeutas, agendamentos e especialidades do localStorage
  useEffect(() => {
    try {
      // Carregar terapeutas
      const storedTerapeutas = localStorage.getItem("terapeutas")
      if (storedTerapeutas) {
        setTerapeutas(JSON.parse(storedTerapeutas))
      } else {
        setTerapeutas(mockTerapeutas)
        localStorage.setItem("terapeutas", JSON.stringify(mockTerapeutas))
      }

      // Carregar agendamentos
      const storedAgendamentos = localStorage.getItem("agendamentos")
      if (storedAgendamentos) {
        setAgendamentos(JSON.parse(storedAgendamentos))
      } else {
        setAgendamentos([])
      }

      // Carregar especialidades
      const storedEspecialidades = localStorage.getItem("especialidades")
      if (storedEspecialidades) {
        setEspecialidades(JSON.parse(storedEspecialidades))
      } else {
        setEspecialidades(mockEspecialidades)
        localStorage.setItem("especialidades", JSON.stringify(mockEspecialidades))
      }
    } catch (error) {
      console.error("Erro ao carregar dados do localStorage:", error)
      setTerapeutas(mockTerapeutas)
      setEspecialidades(mockEspecialidades)
    }
  }, [])

  const handleAddTerapeuta = () => {
    setSelectedTerapeuta({
      id: `new-${Date.now()}`,
      nome: "",
      email: "",
      foto: "",
      especialidades: [],
      horarioInicio: "08:00",
      horarioFim: "18:00",
      role: "funcionario",
    })
    setIsFormDialogOpen(true)
  }

  const handleEditTerapeuta = (terapeuta: any) => {
    // Garantir que todas as propriedades necessárias existam
    setSelectedTerapeuta({
      ...terapeuta,
      especialidades: terapeuta.especialidades || [],
      role: terapeuta.role || "funcionario",
    })
    setIsFormDialogOpen(true)
  }

  const handleDeleteTerapeuta = (terapeuta: any) => {
    setSelectedTerapeuta(terapeuta)
    setIsDeleteDialogOpen(true)
  }

  const confirmDeleteTerapeuta = () => {
    if (!selectedTerapeuta) return

    // 1. Remover o terapeuta da lista
    const updatedTerapeutas = terapeutas.filter((t) => t.id !== selectedTerapeuta.id)

    // 2. Remover todos os agendamentos deste terapeuta
    const updatedAgendamentos = agendamentos.filter((a) => a.terapeutaId !== selectedTerapeuta.id)

    // 3. Salvar as alterações
    setTerapeutas(updatedTerapeutas)
    setAgendamentos(updatedAgendamentos)

    // Salvar no localStorage
    try {
      localStorage.setItem("terapeutas", JSON.stringify(updatedTerapeutas))
      localStorage.setItem("agendamentos", JSON.stringify(updatedAgendamentos))
    } catch (error) {
      console.error("Erro ao salvar no localStorage:", error)
    }

    setIsDeleteDialogOpen(false)

    toast({
      title: "Terapeuta removido",
      description: `${selectedTerapeuta.nome} foi removido com sucesso, junto com todos os seus agendamentos.`,
    })

    // Forçar uma atualização da rota para garantir que todos os componentes sejam atualizados
    setTimeout(() => {
      router.refresh()
    }, 100)
  }

  const handleSaveTerapeuta = (terapeuta: any) => {
    let updatedTerapeutas: any[] = []

    // Se for um novo terapeuta
    if (terapeuta.id.startsWith("new-")) {
      const newTerapeuta = {
        ...terapeuta,
        id: `terapeuta-${Date.now()}`,
        especialidades: terapeuta.especialidades || [],
      }
      updatedTerapeutas = [...terapeutas, newTerapeuta]
      toast({
        title: "Terapeuta adicionado",
        description: `${terapeuta.nome} foi adicionado com sucesso.`,
      })
    } else {
      // Se for edição
      updatedTerapeutas = terapeutas.map((t) =>
        t.id === terapeuta.id
          ? {
              ...terapeuta,
              especialidades: terapeuta.especialidades || [],
            }
          : t,
      )
      toast({
        title: "Terapeuta atualizado",
        description: `${terapeuta.nome} foi atualizado com sucesso.`,
      })
    }

    setTerapeutas(updatedTerapeutas)

    // Salvar no localStorage
    try {
      localStorage.setItem("terapeutas", JSON.stringify(updatedTerapeutas))
    } catch (error) {
      console.error("Erro ao salvar no localStorage:", error)
    }

    setIsFormDialogOpen(false)

    // Forçar uma atualização da rota para garantir que todos os componentes sejam atualizados
    setTimeout(() => {
      router.refresh()
    }, 100)
  }

  return (
    <>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Cadastro de Terapeutas</h2>
            <p className="text-muted-foreground">Gerencie os terapeutas do sistema</p>
          </div>
          <Button onClick={handleAddTerapeuta} className="flex items-center gap-1">
            <Plus className="h-4 w-4" />
            Adicionar Terapeuta
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {terapeutas.map((terapeuta) => (
            <Card key={terapeuta.id}>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage src={terapeuta.foto} alt={terapeuta.nome} />
                    <AvatarFallback>{terapeuta.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-medium">{terapeuta.nome}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{terapeuta.email}</p>
                  <div className="flex flex-wrap justify-center gap-2 mb-4">
                    {Array.isArray(terapeuta.especialidades) &&
                      terapeuta.especialidades.map((especialidade: string) => (
                        <Badge key={especialidade} variant="secondary">
                          {especialidade}
                        </Badge>
                      ))}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Perfil: {terapeuta.role === "admin" ? "Administrador" : "Funcionário"}
                  </p>
                  <div className="flex gap-2 mt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditTerapeuta(terapeuta)}
                      className="flex items-center gap-1"
                    >
                      <Pencil className="h-4 w-4" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteTerapeuta(terapeuta)}
                      className="flex items-center gap-1"
                    >
                      <Trash2 className="h-4 w-4" />
                      Excluir
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Diálogo de formulário de terapeuta */}
      <Dialog open={isFormDialogOpen} onOpenChange={setIsFormDialogOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedTerapeuta?.nome ? "Editar Terapeuta" : "Novo Terapeuta"}</DialogTitle>
          </DialogHeader>
          {selectedTerapeuta && (
            <TerapeutaForm terapeuta={selectedTerapeuta} especialidades={especialidades} onSave={handleSaveTerapeuta} />
          )}
        </DialogContent>
      </Dialog>

      {/* Diálogo de confirmação de exclusão */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Ao excluir este terapeuta, todos os seus agendamentos também serão apagados. Deseja continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteTerapeuta}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
