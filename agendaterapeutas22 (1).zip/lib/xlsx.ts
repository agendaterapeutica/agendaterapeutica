// Importação do pacote xlsx para exportação de dados
import * as XLSX from "xlsx"

export { XLSX }
