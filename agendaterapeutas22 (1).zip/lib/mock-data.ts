// Dados de exemplo para terapeutas
export const mockTerapeutas = [
  {
    id: "terapeuta-1",
    nome: "Ana Silva",
    email: "admin@exemplo.com",
    foto: "/placeholder.svg?height=200&width=200",
    especialidades: ["Psicologia", "Terapia Cognitivo-Comportamental"],
    horarioInicio: "08:00",
    horarioFim: "18:00",
    role: "admin",
    senha: "senha123",
  },
  {
    id: "terapeuta-2",
    nome: "Carlos Oliveira",
    email: "funcionario@exemplo.com",
    foto: "/placeholder.svg?height=200&width=200",
    especialidades: ["Fisioterapia", "Acupuntura"],
    horarioInicio: "09:00",
    horarioFim: "19:00",
    role: "funcionario",
    senha: "senha123",
  },
  {
    id: "terapeuta-3",
    nome: "Mariana Santos",
    email: "mariana.santos@exemplo.com",
    foto: "/placeholder.svg?height=200&width=200",
    especialidades: ["Fonoaudiologia", "Terapia da Fala"],
    horarioInicio: "07:00",
    horarioFim: "17:00",
    role: "funcionario",
    senha: "senha123",
  },
]

// Dados de exemplo para pacientes
export const mockPacientes = [
  {
    id: "paciente-1",
    nome: "João Pereira",
    email: "joao.pereira@exemplo.com",
    telefone: "(11) 98765-4321",
    foto: "/placeholder.svg?height=200&width=200",
    dataNascimento: "1990-05-15",
  },
  {
    id: "paciente-2",
    nome: "Maria Costa",
    email: "maria.costa@exemplo.com",
    telefone: "(11) 91234-5678",
    foto: "/placeholder.svg?height=200&width=200",
    dataNascimento: "1985-10-22",
  },
  {
    id: "paciente-3",
    nome: "Pedro Almeida",
    email: "pedro.almeida@exemplo.com",
    telefone: "(11) 99876-5432",
    foto: "/placeholder.svg?height=200&width=200",
    dataNascimento: "1995-03-08",
  },
  {
    id: "paciente-4",
    nome: "Camila Lima",
    email: "camila.lima@exemplo.com",
    telefone: "(11) 97890-1234",
    foto: "/placeholder.svg?height=200&width=200",
    dataNascimento: "1988-12-01",
  },
  {
    id: "paciente-5",
    nome: "Roberto Souza",
    email: "roberto.souza@exemplo.com",
    telefone: "(11) 95678-9012",
    foto: "/placeholder.svg?height=200&width=200",
    dataNascimento: "1992-07-19",
  },
]

// Dados de exemplo para agendamentos
export const mockAgendamentos = [
  {
    id: "agendamento-1",
    terapeutaId: "terapeuta-1",
    pacienteId: "paciente-1",
    dia: "Segunda",
    horario: "09:00",
    tipo: "individual",
  },
  {
    id: "agendamento-2",
    terapeutaId: "terapeuta-2",
    pacienteId: "paciente-2",
    dia: "Terça",
    horario: "14:00",
    tipo: "individual",
  },
  {
    id: "agendamento-3",
    terapeutaId: "terapeuta-3",
    pacienteId: "paciente-3",
    dia: "Quarta",
    horario: "10:00",
    tipo: "individual",
  },
  {
    id: "agendamento-4",
    terapeutaId: "terapeuta-1",
    tipo: "grupo",
    dia: "Quinta",
    horario: "11:00",
    pacienteIds: ["paciente-2", "paciente-4", "paciente-5"],
  },
  {
    id: "agendamento-5",
    terapeutaId: "terapeuta-2",
    pacienteId: "paciente-1",
    dia: "Sexta",
    horario: "15:00",
    tipo: "individual",
  },
  {
    id: "agendamento-6",
    terapeutaId: "terapeuta-3",
    tipo: "reuniao",
    dia: "Segunda",
    horario: "15:00",
    pacienteIds: [],
  },
]

// Dados de exemplo para especialidades
export const mockEspecialidades = [
  "Psicologia",
  "Fisioterapia",
  "Fonoaudiologia",
  "Terapia Ocupacional",
  "Nutrição",
  "Acupuntura",
  "Terapia Cognitivo-Comportamental",
  "Terapia da Fala",
  "Psicopedagogia",
]
